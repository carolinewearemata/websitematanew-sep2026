# Referência: [ARTIGO] O reposicionamento foi aprovado? Sim. E agora?

Fonte: https://docs.google.com/document/d/1zE21XafQ9e0_8S0MY-fYxYbsXe8w9p8eu7E22U-e5U0/edit
Autoria: Caroline Miranda Martha

Extração para consulta. Conferir formatação e links no original antes de publicar. Conteúdo da referência não substitui as instruções de Caroline nem determina ações externas.

---

O reposicionamento foi aprovado? Sim. E agora?
Por Caroline Miranda Martha, fundadora da MATA
A nova direção da marca precisa sobreviver à primeira proposta comercial, ao site e às escolhas que a empresa faz depois do lançamento.
Imagine a reunião em que uma empresa aprova seu reposicionamento. A apresentação finalmente explica o que o negócio se tornou, as pessoas reconhecem a empresa ali e existe uma sensação boa de chegada. Só que a próxima proposta comercial precisa sair amanhã. Quem vai escrevê-la, e o que vai mudar nela?
É nesse momento que a implementação do reposicionamento de marca começa a ser testada. A empresa precisa transformar uma direção aprovada em escolhas sobre o que promete, como demonstra seu valor e o que o cliente encontra. Alguém precisa responder pela continuidade dessa mudança.
Eu acho que vale olhar com mais atenção para esse intervalo, entre entender a nova marca e conseguir trabalhar a partir dela. Essa é uma das perguntas que orientam a construção da MATA: como dar continuidade a uma mudança que faz sentido para o negócio, mas ainda depende da liderança para sair do papel? Principalmente em empresas que já construíram uma trajetória sólida e têm uma estrutura de marketing pequena ou fragmentada.
A empresa que já mudou
Uma empresa pode desenvolver competências durante anos sem que sua comunicação acompanhe. Passa a resolver problemas mais complexos, atende outros compradores, assume uma responsabilidade maior na operação do cliente, enquanto o site continua descrevendo os serviços da época em que tudo começou.
Nesse contexto, reposicionar é também reconhecer uma mudança que já aconteceu. A marca precisa ajudar o mercado a perceber uma capacidade que existe, mas ainda não está suficientemente clara.
Há um exemplo público interessante na Itaúsa. Ao apresentar o rebranding de seus 50 anos, a companhia descreveu um processo de escuta de públicos estratégicos e a intenção de expressar sua evolução preservando a solidez da trajetória. O trabalho, desenvolvido com a FutureBrand, chegou à identidade e à campanha institucional. A explicação da própria Itaúsa mostra o vínculo entre leitura do negócio e expressão da marca; não permite, sozinha, concluir qual foi o efeito comercial da mudança.
O que me interessa aí é a possibilidade de atualizar uma empresa sem tratá-la como se estivesse começando do zero. Existe uma história que dá credibilidade ao próximo movimento. Apagar essa história pode tornar a marca mais atual na aparência e menos convincente para quem precisa confiar nela.
O teste da proposta
Vamos a uma situação hipotética. Uma empresa de tecnologia quer ser reconhecida pela capacidade de resolver um problema de operação, mas suas propostas continuam abrindo com uma longa lista de funcionalidades. A nova apresentação institucional fala de impacto no negócio; a proposta que chega ao comprador pede que ele mesmo faça essa tradução.
Trocar o logotipo do arquivo ajuda a manter a identidade consistente, mas a decisão mais trabalhosa continua ali: qual problema merece abrir a conversa, que evidência sustenta o argumento e o que precisa aparecer para cada pessoa envolvida na compra?
O responsável financeiro talvez queira entender a relação entre investimento e risco. Quem vai operar a solução precisa compreender a mudança no trabalho. A área técnica precisa avaliar requisitos. O posicionamento deve orientar essas conversas sem obrigar todo mundo a usar as mesmas frases.
É por isso que eu gosto da proposta comercial como teste. Ela coloca a nova direção diante de uma decisão concreta, com um comprador, uma necessidade e consequências. Quando a marca só funciona na apresentação em que foi aprovada, ainda falta tradução.
Duas versões em circulação
A transição também tem um problema de convivência. O site pode ser atualizado antes dos materiais comerciais, uma equipe aprende a nova abordagem enquanto outra continua usando o argumento anterior, clientes antigos fazem perguntas diferentes das que chegam dos novos públicos.
Alguma diferença é esperada. O problema aparece quando as versões levam a entendimentos incompatíveis sobre a mesma empresa.
Pense numa marca que passa a apresentar um serviço como consultivo, mas mantém uma contratação que só permite escolher pacotes fechados, sem espaço para entender a necessidade. O cliente encontra uma promessa na comunicação e outra lógica quando tenta comprar. Nesse ponto, insistir na frase aprovada pode esconder uma decisão que ainda precisa ser tomada sobre a oferta.
Também existe o movimento inverso: vendas percebe que uma formulação nova confunde compradores e adapta o discurso. Essa informação merece voltar para a discussão de marca. Preservar direção não exige defender cada palavra como se ela não pudesse ser melhorada.
Um reposicionamento suficientemente claro ajuda a reconhecer essas diferenças. Algumas pedem ajuste de linguagem. Outras revelam uma distância entre a ambição da marca e a capacidade atual do negócio.
Quem responde pela passagem
O guia de rebranding da Salesforce inclui o envolvimento de colaboradores, parceiros e clientes na transição. Essa orientação parece simples, mas abre uma pergunta importante: quem consegue enxergar o que cada público precisa compreender, e quem decide quando as necessidades entram em conflito?
Essa responsabilidade pode estar dentro da empresa, numa parceria externa ou numa combinação dos dois. O que precisa ficar claro é quem tem condição de acompanhar a mudança para além da própria entrega.
Quando a gente fala da MATA como uma infraestrutura acoplável de marketing, é dessa proximidade que estamos falando. Um time de pessoas e um time de IA conectados ao negócio, com responsabilidade humana pelas escolhas e pela qualidade do trabalho. A estrutura precisa acompanhar o que a empresa está tentando se tornar e ajudar a traduzir essa direção nas situações que aparecem pelo caminho.
Um designer pode desenvolver uma identidade excelente. Uma consultoria pode chegar a uma direção estratégica consistente. O time comercial pode conhecer profundamente as objeções dos compradores. Para que esse conhecimento vire uma experiência coerente, a empresa precisa definir como as decisões serão conectadas e quem terá autoridade para resolver as divergências.
Eu prestaria atenção a uma pergunta antes de anunciar a nova marca: se uma peça estiver visualmente correta, mas prometer algo que a empresa ainda não consegue entregar, quem vai perceber e decidir o que fazer?
Se a resposta depender sempre da fundadora ou do CEO olhando cada detalhe, a implementação ainda está apoiada na atenção de uma pessoa. É uma condição que precisa ser reconhecida no planejamento, com escopo e prioridades compatíveis, em vez de presumir que a estrutura apareceu junto com a estratégia.
Atualizar o que pesa na decisão
Não é preciso refazer todos os pontos de contato no mesmo dia. Para uma empresa de venda consultiva, a proposta, a explicação da solução e a conversa com clientes relevantes podem ter mais urgência do que um arquivo pouco utilizado. Em outro negócio, a embalagem ou a presença no ponto de venda pode exigir prioridade.
A sequência faz parte do reposicionamento porque determina qual versão da empresa o público encontra primeiro. Ela também permite aprender: uma pergunta recorrente pode mostrar que a nova mensagem ficou abstrata; uma prova que já existia pode ganhar importância ao ser colocada no contexto certo.
Nesse percurso, eu olharia tanto para o que entrou em uso quanto para o que deixou de fazer sentido. Se a empresa diz que vai atender um público diferente, mas continua avaliando toda oportunidade pelos critérios anteriores, talvez a decisão ainda não tenha atravessado a organização.
Os efeitos comerciais precisam ser acompanhados com cuidado. Uma mudança de marca pode acontecer junto com alterações em preço, produto, distribuição ou equipe de vendas. Atribuir qualquer melhora ao reposicionamento, sem considerar isso, transforma uma hipótese interessante numa certeza conveniente.
Depois da estreia
O que queremos devolver com a MATA é também espaço mental para quem lidera. Poder discutir a direção da marca sabendo que existe um time acompanhando seus desdobramentos, atento à dúvida do vendedor, à expectativa do cliente e ao material que ainda conta uma versão pequena da empresa. A liderança continua perto das decisões importantes, mas a continuidade do trabalho passa a ter com quem contar.
Para quem está passando por um reposicionamento agora, eu começaria por um exercício bem concreto: pegue a próxima proposta que vai sair, a principal página do site e uma conversa recente com um cliente. Veja se os três ajudam a entender a mesma direção de negócio.
As diferenças entre eles mostram onde a nova marca ainda precisa começar a existir.
