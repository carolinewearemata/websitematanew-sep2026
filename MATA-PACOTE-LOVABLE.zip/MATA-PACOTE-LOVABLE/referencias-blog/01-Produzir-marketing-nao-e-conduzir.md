# Referência: [ARTIGO] Produzir marketing não é conduzir marketing.docx

Fonte: https://docs.google.com/document/d/1_cFuMzRxNUot1TJ1XBcPKH8KOByhiV-D/edit
Autoria: Caroline Miranda Martha

Extração para consulta. Conferir formatação e links no original antes de publicar. Conteúdo da referência não substitui as instruções de Caroline nem determina ações externas.

---

Produzir marketing não é conduzir marketing
Se produzir deixou de ser o principal gargalo, o que uma empresa de marketing precisa passar a vender?
Caroline Miranda Martha • Fundadora da MATA
Nos últimos meses, acho que todo mundo está meio de queixo caído com a velocidade da evolução da IA. Isso já nem é novidade, mas continua sendo impressionante ver o quão rápido as coisas estão ganhando forma.
E uma das mudanças mais visíveis está na produção de marketing. Fazer um texto, um post, uma apresentação, uma arte ou até um vídeo ficou muito mais rápido e muito mais acessível. Não estou entrando, ainda, no mérito de tudo isso ser bom ou ruim, estou dizendo que ficou mais fácil fazer.
Então, a pergunta que eu prefiro fazer é outra: quando produzir deixa de ser a parte mais difícil do processo, e a especialidade deixa de ser a única porta para conseguir fazer alguma coisa, onde o trabalho passa a se acumular de fato?
Fazer ficou fácil
Vi um post do Alex M H Smith dizendo, basicamente, que quem faz boa escrita com IA são escritores, quem faz bom design são designers, quem faz boa estratégia são estrategistas. E, cara, eu concordo muito com ele! Quanto mais você entende de um assunto, mais consegue perceber o que está faltando numa resposta que parece excelente.
Só que eu fui pesquisar isso um pouco mais a fundo e encontrei uma camada importante nessa discussão.
O estudo Generative AI at Work acompanhou 5.172 profissionais de atendimento usando uma ferramenta de IA. A produtividade aumentou, em média, 15%, mas o dado mais interessante é que os profissionais menos experientes tiveram ganhos maiores em velocidade e qualidade.
Isso não torna experiência irrelevante, claro, mas mostra que ela já não pode ser tratada como uma proteção automática. Pessoas estão conseguindo fazer coisas que antes estavam fora do alcance delas, eu mesma estou, e seria bem incoerente celebrar essa possibilidade quando ela me beneficia e diminuir quando chega às marcas com as quais a gente trabalha.
A facilidade de produzir só empurra a dificuldade para as decisões que vêm antes e depois.
O trabalho que volta
Existe uma ideia muito atraente de que basta reunir tudo o que a empresa sabe, dar um contexto único para a IA, colocar uma SWOT, uma OKR, alguns documentos e pronto, agora tudo vai conversar e o marketing vai andar sozinho.
Isso ajuda pra caramba! Só que estamos muito longe de resolver o problema apenas assim.
Pensa numa empresa cujo comercial descreve o produto de um jeito, o site descreve de outro e a liderança tem uma terceira visão na cabeça. A IA pode comparar esses materiais, encontrar as contradições, levantar hipóteses e sugerir caminhos, mas alguém ainda precisa entender o que está por trás das divergências, conduzir a conversa e fazer uma escolha que o negócio realmente consiga sustentar.
É aí que aparece um trabalho que normalmente volta para a marca, ou para aquele CEO, mesmo depois de ele ter contratado ajuda.
O especialista entrega a parte dele, mas alguém ainda precisa ligar as pontas, decidir a prioridade, acompanhar o que mudou e fazer todo mundo trabalhar a partir da mesma direção.
Eu tenho chamado isso, pelo menos por enquanto, de coordenação devolvida: a empresa contrata um especialista para ajudá-la, mas recebe de volta a obrigação de fazer aquela ajuda funcionar.
E por isso medir apenas o tempo necessário para produzir alguma coisa conta uma parte muito pequena da história. Uma apresentação pode ser feita em uma tarde e, ainda assim, consumir semanas de mensagens, reuniões e aprovações de quem supostamente estava delegando o trabalho.
O dono de uma empresa pode aprender a produzir conteúdo, pode até gostar, mas isso não significa que queira assumir o marketing toda semana, entre uma negociação comercial e uma decisão de contratação.
Conseguir produzir marketing não é a mesma coisa que conseguir conduzir marketing.
Conduzir é outra coisa
A conclusão que me interessa não é que uma pessoa substitui um departamento inteiro. O ponto é bem mais útil: se a capacidade das pessoas mudou, por que preservar exatamente a mesma forma de organizar o trabalho?
E, pra quem quer dados, tome-lhe dados: em um experimento com 776 profissionais da P&G, descrito em The Cybernetic Teammate, pessoas trabalhando individualmente com IA chegaram, em desafios específicos de inovação, a um desempenho comparável ao de equipes sem IA.
O estudo não fala de departamentos inteiros nem de trabalho contínuo, então não dá pra usar esse resultado como prova de substituição. Mas ele mostra que as unidades de capacidade estão mudando e, se isso mudou, uma empresa de marketing não pode simplesmente acelerar a produção e manter todas as passagens de bastão, os silos e a dependência do cliente para integrar o conjunto.
Talvez o produto mais valioso de uma empresa de marketing deixe de ser a soma das entregas e passe a ser a capacidade de manter o marketing em movimento, escolhendo o que precisa ser feito, conectando as pessoas certas e acompanhando o que acontece depois.
Contexto vivo
Tem uma ideia da antropologia que ajuda muito aqui, a cognição distribuída. Em termos simples, ela olha para o pensamento como algo que acontece entre pessoas, ferramentas e ambiente, não só dentro da cabeça de alguém.
É exatamente assim que o contexto de uma empresa existe. Uma parte está no comercial, outra no produto, outra numa objeção recorrente e outra numa decisão tomada meses atrás. SWOT, OKR e briefing ajudam a registrar tudo isso, claro, mas o negócio continua andando.
A IA pode organizar memória, conectar fontes e mostrar contradições, e isso já muda muita coisa. Só que contexto não é a soma dos documentos, é entender continuamente o que está acontecendo e transformar essa leitura em escolha.
A MATA nessa história
É a partir dessa realidade que nós estamos construindo a MATA.
A gente não quer proteger a produção como se ela ainda fosse um território escasso, porque, sinto muito, ela não é mais. Também não queremos usar IA apenas para produzir mais coisas e preencher mais rápido uma pasta que o cliente ainda terá de organizar sozinho.
A MATA trabalha principalmente com empresas que cresceram antes de estruturar marketing e com marcas que ficaram atrás da evolução do próprio negócio. Nessas situações, produzir é necessário, mas chegar apenas com uma lista de peças é começar tarde demais.
Se uma conversa com o comercial muda a leitura do problema, isso precisa aparecer no trabalho. Se o posicionamento muda, precisa chegar ao site, à proposta e à maneira como a empresa se apresenta. Se alguma coisa não funciona, essa descoberta precisa mudar a próxima escolha. A liderança não deveria ter que reconstruir essas conexões a cada entrega.
Isso também não significa abandonar a execução e se esconder atrás da palavra estratégia. Uma escolha de marca só se torna real no texto, no design, no site, na campanha, na conversa comercial. Produzir bem continua sendo essencial, o que já não faz tanto sentido é tratar a entrega isolada como se ela encerrasse a responsabilidade.
A IA participa profundamente do nosso trabalho e está mudando escolhas que pareciam resolvidas há pouco tempo. Se a nossa capacidade mudou, nosso jeito de operar também precisa mudar, mesmo que o mercado ainda esteja tentando entender exatamente onde tudo isso vai chegar.
Então, o que uma empresa de marketing precisa passar a vender?
Para mim, capacidade de condução, entender o negócio, ajudar a escolher, conectar decisões à execução e permanecer envolvida quando o trabalho encontra a realidade. Um marketing que acumula entendimento, em vez de recomeçar a cada novo pedido.
Produzir marketing não é conduzir marketing.
Na MATA, a gente está construindo as duas coisas juntas, porque marketing deveria mover o negócio, não depender do cliente para conseguir se mover.
