# Implementação e critérios de aceite — MATA

Este documento orienta a atualização do projeto existente no Lovable. É uma especificação proposta, não um relatório de testes da futura implementação. A auditoria do site atual está no arquivo 02. A copy está no arquivo 03.

## 1. Antes de alterar o projeto

Inventariar rotas PT/EN, componentes, formulários, integrações, domínio, analytics, metadados e forma atual de publicação. Registrar a versão inicial para permitir comparação e recuperação. Aproveitar componentes adequados ao sistema visual. Não escolher uma nova stack sem necessidade identificada.

Não presumir renderização, indexabilidade ou integrações pelo nome Lovable. A documentação distingue arquiteturas conforme a geração do projeto. Inspecionar o projeto real antes de decidir como resolver cada requisito. [Documentação Lovable de SEO e AEO](https://docs.lovable.dev/features/seo-aeo).

Construir em prévia. Briefing, referências internas, notas de casos e documentos de pesquisa não são arquivos públicos do site. Apenas assets destinados à publicação entram na pasta pública.

## 2. Configurações e destinos reais

| Configuração | Valor / regra |
|---|---|
| Domínio institucional | https://wearemata.co |
| Contato por e-mail | hello@wearemata.company — observado no site atual |
| Agenda confirmada por Caroline | https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C |
| WhatsApp observado | https://wa.me/5516996071579?text=Oi%2C%20vim%20pelo%20site%20da%20MATA%20e%20quero%20falar%20com%20voc%C3%AAs. |
| LinkedIn observado | https://www.linkedin.com/company/wearemata |
| Destino do formulário | Inspecionar integração existente e validar recebimento; ainda não verificado nesta pesquisa |
| Endereço definitivo do Blog | Recomendação: /blog ou /pt/blog; alternativa blog.wearemata.co; decisão final em avaliação |
| Cases publicados | Apenas registros com evidência e conteúdo pronto; não preencher lacunas automaticamente |

O link da agenda é fornecido pela usuária. Nesta pesquisa, a ferramenta de leitura web não conseguiu inspecionar sua página. Isso não demonstra falha do endereço. A revisão da implementação deve verificar sua abertura e disponibilidade pública, sem criar uma reserva de teste sem autorização.

Usar uma configuração central para a agenda e para o Blog, evitando URLs repetidas em componentes. Não depender de variáveis secretas para um endereço público. Credenciais do destino do formulário ficam em configuração protegida no servidor.

## 3. Navegação e migração

Manter os endereços existentes onde a função é equivalente. Mapa proposto:

| Origem observada | Destino / decisão |
|---|---|
| /pt | Home nova, mesma rota |
| /pt/how-it-works | Como funciona, mesma rota |
| /pt/results | Evoluções; preservar a rota e preparar conteúdo validado |
| /pt/story | Sobre a MATA, mesma rota |
| /pt/principles | Princípios, mesma rota, acessível por Sobre e rodapé |
| /pt/contact | Contato com formulário e agenda, mesma rota |
| Novas páginas de situação | Criar URLs estáveis conforme arquivo 02; não gerar variações concorrentes |
| /en e demais rotas inglesas | Inventariar e preservar até adaptação integral; não misturar copy PT em páginas EN |
| Raiz / | Propor PT como entrada da nova versão; conferir o comportamento existente, que levou a /en nesta pesquisa. Não iniciar o novo fluxo em inglês desatualizado |

Se houver mudança de URL, registrar correspondência individual e usar redirecionamento permanente para o equivalente. Evitar redirecionar tudo para a home. Testar links antigos, navegação direta e atualização do navegador. [Orientação Google para mudanças de URL](https://developers.google.com/search/docs/crawling-indexing/site-move-with-url-changes).

Menu desktop: Como funciona; Para sua empresa; Evoluções quando houver conteúdo validado; Sobre; Blog; ação de contato. O acesso à agenda aparece na primeira dobra e na página de contato. Não comprimir sete itens mais dois botões no cabeçalho mobile. Menu mobile deve oferecer os dois caminhos de contato com rótulos completos e claros.

Não ocultar a situação prioritária em um seletor que o visitante precisa descobrir. As três entradas permanecem compreensíveis na home. Páginas de entrada funcionam diretamente, inclusive quando acessadas por pesquisa ou artigo.

## 4. Componentes e estados

| Componente | Conteúdo / comportamento | Estado sem material definitivo |
|---|---|---|
| Hero | Categoria, problema de negócio, pessoas + IA, dois contatos, acoplamento | Usar referências existentes com texto separado em HTML |
| Diagrama do acoplamento | Negócio/contexto → capacidade MATA → decisões e trabalho em uso → retorno de contexto | Representação conceitual identificada; nunca dashboard de produto inexistente |
| Entradas por situação | Estruturar marketing, reposicionar, implantar | Todas as páginas com copy própria; sem números inventados |
| Funcionamento | Responsabilidades, relação com cliente, pessoas e IA | Não exige imagem de ferramenta interna |
| Evolução | Antes, intervenção, depois, evidência e contexto | Rascunho oculto se não validado; não exibir card vazio |
| Artigo | Título, autoria, resumo, destino, data apenas real | Publicar texto revisado ou manter rascunho; sem artigo fictício |
| Contato | Formulário e agenda independentes | Agenda já definida; destino do formulário precisa de verificação |
| Fundadora | Nome e papel reais, foto se fornecida | Bloco editorial sem retrato fictício; biografia a conferir |

Acoplamento deve comunicar conexão e continuidade. Não apresentar um catálogo de módulos com preço ou contratação separada se essa não for a oferta validada. A interação é explicativa, não um configurador comercial.

## 5. Direção visual aplicada

O gradiente oficial MATA é central, conforme prioridade expressa de Caroline. Usar assets/gradientes/MATA-gradiente-oficial.png e verificar sua presença reconhecível no hero desktop e mobile. Incorporar o selo proposto MATA built in. no bloco de evidência, distinguindo relações atuais e históricas. O arquivo 07 detalha aplicações, campos e critérios; não gerar selo de certificação.

Usar as imagens fornecidas como referência de material, conexão, luz e composição. Aplicar logos oficiais dos arquivos SVG. Não extrair ou redesenhar o logotipo a partir da capa. As fontes oficiais estão no pacote com o aviso de licença disponível.

Prioridades: tipografia legível, hierarquia editorial, espaço proporcional e contraste. Prata, gelo, menta e vidro aparecem como materiais do sistema, não como efeito em cada botão. Uma cena de acoplamento expressiva na home é suficiente para estabelecer a linguagem; outras páginas usam derivações contidas.

Texto nunca incorporado à imagem como único meio de leitura. Os dois arquivos de referência têm proporções de capa; criar composição apropriada para mobile, preservando o conceito em vez de recortar cegamente o centro. Não encomendar novos assets antes de testar a composição com o material existente.

Carregar apenas fontes/pesos necessários, definir dimensões de imagens e disponibilizar formatos adequados ao navegador. Priorizar imagem principal; adiar imagens abaixo da dobra. Não usar vídeo ou WebGL como requisito para compreender a oferta. Se houver animação, ela deve degradar para uma cena estática igualmente clara.

## 6. Formulário e agenda

Formulário curto: nome, e-mail, empresa/site, situação principal e mensagem opcional. Quatro campos obrigatórios; mensagem até 1.000 caracteres. Campo empresa/site aceita o nome de uma empresa sem exigir URL. Permitir “Outro momento” na situação. Manter rótulos visíveis, não apenas placeholders.

Estados: inicial; preenchimento; erro por campo; enviando; sucesso confirmado; falha de envio com recuperação. Preservar os dados quando ocorrer falha. Evitar duplo envio enquanto a primeira solicitação está em andamento. Não usar um temporizador para simular sucesso. Não prometer prazo de resposta não confirmado.

Validar no servidor e aplicar proteção contra abuso compatível com a experiência. Enviar apenas informações necessárias ao destino aprovado. Não acrescentar inscrição de newsletter ao envio de contato. Se for adotada uma inscrição, torná-la separada e opcional. Revisar aviso de privacidade de acordo com o fluxo real de dados, sem inventar políticas.

“Agendar uma conversa” abre diretamente a URL confirmada. Recomenda-se link simples, sem incorporar um calendário pesado na home. Se abrir nova aba, indicar isso de forma acessível. Não exigir envio de formulário, login no site MATA ou etapa de qualificação para acessar horários.

Verificar abertura da agenda em janela sem sessão autenticada; conferir que se trata da agenda certa. Não inferir duração, nome do anfitrião ou disponibilidade sem leitura da própria agenda. Registrar clique não equivale a reunião agendada.

## 7. Blog: subdiretório recomendado e alternativa de subdomínio

Caroline confirmou português primeiro, publicação manual e tradução apenas depois de a versão PT estar afinada. Não construir agente de autopublicação nesta fase. Modelo mínimo dos artigos: identificador estável, título, slug, idioma, autoria, resumo, corpo, imagem e texto alternativo, rascunho/publicado, datas reais e referência à tradução quando existir. Esse modelo prepara integrações futuras sem contratar ou implementar uma plataforma extra agora.

Recomendação prática: /pt/blog e /pt/blog/slug; /en/blog e /en/blog/slug apenas quando houver conteúdo revisado em inglês. Um artigo PT sem tradução não recebe link alternativo EN fictício. Não exigir tradução para publicar ou melhorar PT.

Preparar um campo único para o endereço da publicação. Menu usa o rótulo “Blog”. A identidade deve manter reconhecimento da MATA, com uma superfície editorial adequada à leitura longa. Link de volta ao institucional no domínio editorial.

Para a opção recomendada: usar um índice real em /pt/blog e, se os artigos estiverem revisados, páginas locais completas. Se ainda não houver publicação pronta, o índice pode explicar brevemente a linha editorial e direcionar ao contato, sem cards clicáveis falsos ou promessas de data. Não apresentar arquivos de trabalho como artigos publicados.

Se for escolhido um subdomínio: escolher um endereço principal para cada artigo; atualizar cards e links; se um artigo local migrar, redirecionar sua URL ao equivalente. Não manter dois conteúdos integrais concorrentes sem plano de canonicalização. Canonical é um sinal, não uma garantia de escolha pelo buscador. [Google sobre consolidação de URLs](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls).

Metadados do artigo: título, descrição, autoria correta, data real, imagem com descrição quando informativa, URL principal e artigos relacionados relevantes. Não atribuir ao Time da MATA textos assinados por Caroline, nem o inverso. Não alterar o corpo dos três artigos por iniciativa de implementação; revisar links e formatação com os documentos originais.

## 8. Busca e mensuração

Cada página precisa de título e descrição específicos, um H1 descritivo, hierarquia de headings coerente, idioma correto, links rastreáveis, canonical consistente, imagem social e resposta adequada a erro/rota inexistente. Sitemap contém páginas públicas canônicas. Não indexar rascunhos de cases, páginas de prévia e conteúdo incompleto. Implementar hreflang apenas entre versões equivalentes efetivamente publicadas.

Dados estruturados devem representar o que é visível e verdadeiro: organização, artigos e navegação quando pertinente. Não inventar avaliações, preços ou software proprietário para preencher schema. Indexação e elegibilidade são necessárias; nenhuma implementação garante ranking ou menção em respostas de IA. O Google não exige schema especial ou arquivo exclusivo para suas funcionalidades de IA. [Google: funcionalidades de IA e seu website](https://developers.google.com/search/docs/appearance/ai-features).

Eventos propostos, respeitando a ferramenta e as escolhas de privacidade do projeto:

| Evento | Quando acontece | O que permite entender |
|---|---|---|
| contact_form_view | Formulário visualizado | Acesso ao caminho de contato |
| contact_form_start | Primeira interação significativa | Intenção de preencher |
| contact_form_submit_success | Destino confirma envio | Solicitação enviada |
| contact_form_submit_error | Envio falha | Fricção operacional |
| booking_click | Clique no link da agenda | Interesse em agendar, não reserva concluída |
| situation_click | Acesso a uma situação | Temas que geram interesse |
| case_view | Leitura de case publicado | Uso de evidência |
| blog_click | Acesso à publicação | Interesse editorial |

Parâmetros úteis: página, posição do CTA, situação escolhida por categoria e idioma. Não enviar nome, e-mail, mensagem ou conteúdo livre da empresa para analytics. Não inflar conversões contando clique, formulário e agendamento como três clientes diferentes. Se não houver integração confiável com o calendário, medir reuniões realizadas no processo comercial e manter essa limitação explícita.

## 9. Critérios de qualidade da prévia

### Compreensão e conteúdo

- Em uma primeira leitura, o visitante identifica a situação atendida e o que contrata.
- O gradiente oficial é reconhecível e a composição comunica infraestrutura incorporada.
- O selo proposto mantém logo oficial, contribuição e status verdadeiros.
- A MATA aparece como estrutura operada por pessoas e IA; nenhuma tela sugere compra de um aplicativo de autoatendimento inexistente.
- A prioridade de empresas sem marketing está visível. Reposicionamento e implantação têm caminhos distintos.
- “Acoplável” é explicado por relação, responsabilidades e visual; não depende de repetir a palavra.
- A IA tem papel concreto, responsabilidade humana e limites de alegação.
- Não há métricas, depoimentos, nomes de clientes ou escopos criados para preencher layout.
- Todas as notas editoriais e variáveis de rascunho estão fora da interface pública.

### Responsividade e acessibilidade

- Conferir 320, 375, 414, 768, 1024 e 1440 px, além de ampliação de texto e zoom.
- Nenhum transbordamento horizontal ou sobreposição de CTA, menu e texto essencial.
- Menu abre e fecha por teclado; foco é visível e retorna corretamente; Escape fecha quando aplicável.
- Inputs têm rótulos, mensagens compreensíveis e erros associados ao campo; sucesso pode ser percebido por tecnologia assistiva.
- Informação não depende apenas de cor, hover, movimento ou imagem.
- Contraste de texto comum ao menos 4,5:1; texto grande 3:1; verificar também componentes e foco conforme WCAG.
- Respeitar preferência de movimento reduzido. Animações não bloqueiam leitura ou navegação.
- Conferir ordem de leitura, headings, nomes acessíveis, alt descritivo e imagens decorativas sem ruído.

Usar [WCAG 2.2](https://www.w3.org/WAI/WCAG22/quickref/) como referência de verificação; um checklist parcial não certifica conformidade integral.

### Desempenho, integração e busca

- Rotas abrem diretamente e sobrevivem a refresh; links antigos têm destino equivalente.
- Formulário tem envio e recebimento efetivamente testados em destino controlado, com registro do resultado.
- Agenda abre publicamente no destino fornecido; nenhum teste cria reunião sem autorização.
- Blog e idioma funcionam sem links vazios, loops ou mistura de páginas.
- Metadados e conteúdo podem ser lidos no HTML/renderização adequada da rota real.
- Conferir console, rede, fontes e assets ausentes; revisar em navegador mobile real quando disponível.
- Medir desempenho da prévia e depois em produção. Como referência de experiência real: LCP até 2,5 s, INP até 200 ms e CLS até 0,1 no percentil 75. Medidas de laboratório não substituem dados de campo. [Core Web Vitals](https://web.dev/articles/vitals).

## 10. Entrega esperada do Lovable

Prévia navegável com copy real e links funcionais; relação de páginas alteradas; evidência visual desktop/mobile; registro de testes executados; pendências claramente separadas de falhas. Apresentar quais resultados são observados e quais são apenas metas.

Antes da publicação, conferir formulário, páginas públicas, identidade e condições comerciais efetivamente utilizadas. Cases podem continuar em rascunho sem bloquear o restante do site. Não chamar de pronto um formulário que apenas mostra uma mensagem de sucesso local.
