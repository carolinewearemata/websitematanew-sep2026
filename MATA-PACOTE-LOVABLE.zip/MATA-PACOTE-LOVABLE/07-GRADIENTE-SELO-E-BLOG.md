# Direção final de identidade, selo e Blog

Este complemento incorpora as últimas orientações de Caroline. Deve ser lido junto com os arquivos 02, 03 e 05. As recomendações de nome do selo e endereço do Blog são propostas para revisão; a prioridade do gradiente, a percepção de martech e as grafias das marcas foram confirmadas pela usuária.

## 1. O gradiente é uma assinatura central

O gradiente oficial da MATA precisa ser reconhecível já na primeira dobra. Não basta incluir um logotipo em gradiente e deixar o restante com aparência genérica. Ele participa da atmosfera do hero, da luz dos módulos e de momentos de conexão ao longo do site.

Arquivo mestre fornecido no pacote: **assets/gradientes/MATA-gradiente-oficial.png**, copiado da referência oficial do MATA Design System. A imagem tem transições amplas entre menta, prata, gelo e lilás acinzentado. A leitura é luminosa e material, sem faixas duras de arco-íris. As duas capas fornecidas por Caroline complementam essa referência com a lógica de acoplamento.

Token oficial de apoio, para aplicações em que CSS seja apropriado:

```css
--mata-holo: linear-gradient(120deg,
  #AEB3C7 0%, #D8DDE1 22%, #F1F2F4 43%,
  #B0E6D8 62%, #00F0A9 78%, #DEE5EB 100%);
```

O token não substitui a comparação visual com a imagem mestre: um gradiente linear aplicado mecanicamente pode produzir faixas diferentes da atmosfera do arquivo. Usar a imagem oficial diretamente ou reproduzir suas relações de cor e difusão, verificando o resultado.

| Área | Aplicação pretendida |
|---|---|
| Hero | Campo atmosférico reconhecível, com área de contraste para a mensagem e módulos acoplados |
| Funcionamento | Reflexos do gradiente nas conexões, ajudando a acompanhar o contexto e a passagem ao trabalho |
| Selo MATA | Superfície ou faixa holográfica na versão expressiva; versão funcional de alto contraste |
| Fechamento de contato | Retomada do gradiente para encerrar a experiência com identidade |
| Páginas internas | Abertura ou detalhe recorrente que preserva continuidade sem atrapalhar leitura longa |
| Blog | Identidade reconhecível na abertura e nos elementos editoriais; corpo de texto em superfície de leitura estável |

A proporção neutral-first do sistema orienta a legibilidade, mas não pode ser interpretada como licença para apagar o gradiente. Caroline explicitou sua centralidade para este website. O equilíbrio deve ser verificado na composição inteira e em mobile.

## 2. Como a martech aparece na experiência

O visual precisa comunicar uma capacidade incorporada ao negócio. Módulos têm papel e conexão; pessoas e IA fazem parte da estrutura; há fluxo de contexto, decisão, execução e aprendizado. A estética de tecnologia ganha credibilidade quando o conteúdo mostra o funcionamento.

Critérios para a primeira prévia:

- Gradiente e materiais específicos da MATA reconhecíveis, inclusive no mobile.
- Uma cena de acoplamento central, com mensagem de negócio compreensível.
- Oferta organizada por situação e responsabilidade, sem vitrine de pacotes de serviços.
- Pessoas e IA visíveis desde a home, com explicação do papel de cada uma.
- Evidência de estruturação, implantação e continuidade; o acabamento criativo aparece dentro dessa contribuição.
- Nenhuma interface de produto, número de agentes ou métrica fictícia para criar aparência de martech.

## 3. Selo: MATA como marca incorporada

Caroline quer que a presença da MATA agregue valor à marca cliente como uma infraestrutura reconhecível. A referência conceitual é a lógica de ingrediente de marca: uma empresa incorpora algo reconhecido de outra empresa e torna essa presença visível.

Na referência citada por Caroline, o selo Creapure é associado a uma qualidade específica e a parceiros verificáveis. Para a MATA, a inspiração útil é vincular uma assinatura a uma contribuição real e identificável. O briefing não importa garantias, critérios industriais ou aparência visual desse selo. [Fonte oficial: selo Creapure](https://www.creapure.com/pt/creapure/o-selo-de-qualidade-creapure/).

### Recomendação de assinatura

**MATA built in.**

Descritor: **Infraestrutura de Brand Marketing**.

Explicação pública proposta: **A assinatura da infraestrutura MATA dentro de um negócio.**

Essa formulação mantém o vínculo com “Brand marketing, built in.”, já presente na referência de Caroline. A categoria principal da empresa continua Infraestrutura de Marketing Acoplável: acoplável explica como a capacidade entra; built in expressa sua presença quando incorporada.

Alternativa integralmente em português: **MATA na estrutura.** Não usar as duas assinaturas como dois selos diferentes; escolher uma na revisão visual. A recomendação inicial é MATA built in.

### Relação ativa e contribuição histórica

| Situação comprovada | Apresentação proposta | Informação que acompanha |
|---|---|---|
| Infraestrutura MATA em operação | MATA built in. · Infraestrutura em operação | Empresa, escopo e início da relação |
| Ciclo de infraestrutura concluído | MATA built in. · Ciclo [período real] | Período encerrado, contribuição e o que permaneceu em uso quando verificável |
| Projeto específico que não correspondeu ao modelo de infraestrutura | Descrever participação real no case; não aplicar selo integral automaticamente | Tipo de contribuição e período |

Os textos de período são campos de rascunho até serem preenchidos. O selo não significa que a MATA endossa todos os produtos, toda a operação ou todo o desempenho da empresa. Ele identifica uma participação específica. Não chamar de “certificação MATA” ou “qualidade garantida” sem que exista um programa próprio que sustente isso.

### Seção no site

Etiqueta: **MATA built in.**

H2 proposto: **A infraestrutura MATA, incorporada a negócios reais.**

Texto: **Conheça onde a MATA está em operação e as estruturas que ajudou a construir. Cada história mostra o contexto, nossa participação e o que mudou.**

Cards: logo da empresa, status da relação, contribuição em uma frase e acesso ao case. Se houver apenas histórico, ajustar a frase de introdução ao conjunto efetivamente publicado. Sem logos liberados e fatos completos, manter a seção em rascunho.

Esta seção substitui o tratamento de “Marcas com as quais construímos”. Não acrescentar uma faixa de logos acima de outra faixa equivalente. Na home, ela integra o bloco de evidência e conduz a Evoluções.

### Direção de desenho do selo

Construir uma assinatura compacta usando o logotipo oficial MATA intacto e “built in.” como elemento complementar. Testar uma forma de módulo com encaixe e uma versão tipográfica mais simples. Não redesenhar letras do logo, não produzir medalha, estrela de certificação ou imitação da referência Creapure.

Versões previstas: expressiva com gradiente oficial; funcional monocromática; histórico com período legível. O logo de cada cliente permanece separado, com respiro e proporção adequada. O selo é um ativo a desenhar e revisar, não um logo oficial já existente no pacote.

No futuro, uma aplicação no site do cliente pode apontar para a página que explica a contribuição MATA. Preparar essa possibilidade sem implantar agora um portal, códigos de verificação ou qualquer programa complexo. Não inserir o selo em canais de clientes como parte desta tarefa.

### Marcas confirmadas por Caroline

**Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF.**

As grafias estão resolvidas. Continuam a completar: relação atual/histórica, escopo, período, escolha dos logos e evidências. A inclusão na lista não concede automaticamente o selo de infraestrutura; conferir a contribuição de cada relação.

## 4. Blog: recomendação após a pergunta sobre endereço

**Decisão de fase confirmada por Caroline:** site e Blog primeiro em português, publicação manual por enquanto; tradução para inglês só depois de a versão PT estar afinada. A ideia de agente publicador fica para o futuro. Não implementá-la agora. O domínio de referência continua wearemata.co; uma menção a .com na conversa não foi tratada como instrução para mudar o domínio.

Preparar artigos com idioma, autoria, estado de publicação e relação entre traduções. A possibilidade de automação depende do editor e de suas integrações; um subdomínio não é requisito intrínseco. Para a estrutura atual, a recomendação prática é **wearemata.co/pt/blog**, com /en/blog reservado conceitualmente para quando houver traduções publicáveis. Não criar páginas inglesas vazias.

Recomendação: **wearemata.co/blog**, ajustando para **/pt/blog** se a estrutura de idiomas do projeto for mantida. O endereço final ainda não foi confirmado por Caroline. A intenção original de domínio separado passou a ser uma alternativa em avaliação.

| Opção | Quando faz sentido para a MATA | Implicação |
|---|---|---|
| /blog ou /pt/blog | Conteúdo editorial faz parte da experiência institucional e comercial | Caminhos e identidade no mesmo site; definir editor e publicação adequados |
| blog.wearemata.co | Plataforma editorial separada oferece vantagem operacional importante | Integração de navegação, identidade e mensuração entre duas instalações |

blog.wearemata.co é um subdomínio de wearemata.co, não exige comprar outro domínio. O endereço visível e a ferramenta de edição são decisões diferentes: um blog em subdiretório pode ter gestão editorial própria; a viabilidade depende da hospedagem e da integração escolhidas.

Minha recomendação é sobre continuidade da experiência e manutenção. Não prometer que /blog ganha posições automaticamente. A orientação geral do Google é escolher a estrutura que funciona para o negócio e para os visitantes; a fonte abaixo é histórica e não deve ser usada para inferir regras atuais de ferramentas de verificação. [Google sobre subdomínios e subdiretórios](https://developers.google.com/search/blog/2008/01/feeling-lucky-at-pubcon).

Se a publicação precisar de nome próprio nos resultados de pesquisa, há uma diferença concreta: o Google suporta site names por domínio ou subdomínio, não por subdiretório. Isso pode favorecer uma publicação independente, mas não é uma necessidade demonstrada da MATA nesta etapa. [Documentação de nomes de site](https://developers.google.com/search/docs/appearance/site-names).

No Lovable, preparar o índice e os modelos de artigo de modo que o endereço não fique espalhado pelos componentes. Não executar uma migração de domínio por suposição. Antes de publicar, fechar o endereço, a forma de editar artigos e os links canônicos.
