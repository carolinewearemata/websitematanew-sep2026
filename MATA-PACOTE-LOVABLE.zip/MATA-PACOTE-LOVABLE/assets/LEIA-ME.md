# Assets do briefing MATA

- referencias: duas imagens fornecidas por Caroline, copiadas sem edição; direção do acoplamento.
- gradientes: imagem mestre extraída do MATA Design System, copiada sem edição; uso central na identidade do website.
- logos: versões horizontais SVG copiadas de LOGOS ATUAIS, fonte canônica do Drive MATA.
- fontes: três famílias Stack Sans e aviso de licença, copiados do Design System.

O selo MATA built in. é uma proposta a desenvolver com o logotipo oficial intacto; ainda não existe como asset aprovado neste pacote. Os logos dos clientes não foram incluídos: seleção adiada pela usuária.

Não publicar referências internas e documentos de briefing no diretório público do site. Somente os assets destinados à interface devem ser servidos pela aplicação.
