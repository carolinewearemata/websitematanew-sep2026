# Como usar o pacote do website MATA

Preparado para Caroline Miranda Martha • atualizado em 14 de setembro de 2026

## O que foi preparado

Um briefing para atualizar o projeto existente de wearemata.co no Lovable. A direção é **Infraestrutura de Marketing Acoplável**, com um time de pessoas e um time de IA, três situações de entrada, Blog explícito e dois caminhos de contato: formulário curto e agendamento.

O pacote contém estratégia, copy por página, direção visual, referências reais, instruções de execução e critérios de revisão. Não contém uma implementação nova do website.

## O que enviar ao Lovable

Descompacte MATA-PACOTE-LOVABLE.zip. Não dependa de o Lovable conseguir ler um ZIP como se fossem todos os arquivos internos.

### Primeiro envio, no projeto atual do site

1. **02-DOSSIE-ESTRATEGICO-MATA.md** — raciocínio, público, arquitetura, fontes, diagnóstico e decisões.
2. **03-COPY-E-ESTRUTURA-POR-PAGINA.md** — conteúdo proposto de cada página e componente.
3. **05-IMPLEMENTACAO-E-QA.md** — comportamento, critérios de aceite e integração.
4. **07-GRADIENTE-SELO-E-BLOG.md** — centralidade do gradiente, proposta MATA built in., marcas confirmadas e recomendação de endereço do Blog.
5. As **duas imagens da pasta assets/referencias** e **assets/gradientes/MATA-gradiente-oficial.png** — enviar como imagens para que o Lovable veja a direção do acoplamento e o gradiente obrigatório.
6. O texto de **PROMPT-INICIAL-LOVABLE.txt** — colar na conversa.

Em **Project settings → Knowledge**, colar o conteúdo de **04-CONHECIMENTO-DO-PROJETO.txt**. O arquivo tem menos de 10.000 caracteres e reúne as regras que devem permanecer. O dossiê completo fica como referência detalhada. Esse uso segue a documentação consultada de [Project knowledge](https://docs.lovable.dev/features/knowledge).

### Para implementar a identidade

Enviar os arquivos de **assets/logos** e **assets/fontes**. As fontes foram copiadas do pacote oficial da MATA, junto com o aviso de licença disponível. A equipe de implementação deve conservar e conferir as condições de uso na publicação.

Enviar **referencias-skills/MATA-DESIGN-SYSTEM.md**, **referencias-skills/DESIGN-MASTER.md** e **referencias-skills/WEB-DESIGN-MASTER.md** se o Lovable precisar aprofundar os critérios. Essas cópias são referências para o briefing, não uma instalação automática de skills nem uma atualização das versões oficiais no Drive. As principais regras já estão traduzidas para os arquivos 02 a 05.

### Para o Blog

Enviar os três arquivos de **referencias-blog** quando a etapa editorial começar. São extrações de texto dos documentos encontrados, com origem e autoria. A formatação e os hyperlinks dos originais podem não estar integralmente preservados; revisar na publicação. Os artigos não precisam virar conteúdo completo da home.

## Idiomas e publicação editorial

Decisão confirmada: novo site e Blog primeiro em português. Publicação manual por enquanto. Inglês somente depois que a versão portuguesa estiver afinada. Recomendação de endereço: /pt/blog, aproveitando os idiomas existentes; /en/blog fica previsto para conteúdo traduzido no futuro, sem páginas vazias agora. A arquitetura dos artigos pode receber automação depois; isso não exige, por si só, subdomínio.

## Ordem de trabalho recomendada

1. **Leitura do projeto:** inventariar rotas, conteúdo, componentes, integrações e publicação existentes; registrar o que será preservado.
2. **Home e sistema visual:** implementar com copy real, exemplos claramente identificados e versões desktop/mobile. Conferir se a pessoa entende o acoplamento antes de ampliar.
3. **Páginas de entrada e funcionamento:** dar autonomia às jornadas de estruturar marketing, reposicionar e implantar; conectar o contato.
4. **Sobre, princípios e Blog:** manter coerência de linguagem, autoria e navegação.
5. **Evoluções:** inserir casos reais conforme o arquivo 06; manter rascunhos fora do menu público.
6. **Contato e publicação:** conectar a agenda, testar o formulário, revisar condições comerciais, idiomas, acessibilidade e busca. Só chamar a versão de pronta depois de verificar a saída real.

Não é necessário reenviar toda a pesquisa em cada mensagem. Manter as decisões permanentes no conhecimento do projeto e referenciar o arquivo da etapa em andamento.

## O que você ainda precisará acrescentar

| Item | Por que precisa | Impede o quê? |
|---|---|---|
| Agenda | Link já fornecido por Caroline e registrado no arquivo 05 | Apenas conferir abertura pública na implementação |
| Destino e acesso ao formulário | Conferir envio e recebimento | Publicar formulário funcional |
| Endereço e editor do Blog | Recomendação atual: /blog ou /pt/blog; subdomínio é alternativa | Fechar publicação editorial e links canônicos |
| Caso(s) documentado(s) e logos selecionados | Sustentar prova e de/para | Publicar a biblioteca de evoluções |
| Condições comerciais vigentes | Fechar capacidade, prazos e direitos sem contradição | Publicar FAQs específicas |
| Foto e biografia da fundadora | Apresentação pessoal precisa | Completar bloco de fundadora |

As grafias já confirmadas são Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF. O selo recomendado é MATA built in.; sua aplicação depende da relação e do escopo de cada marca.

Você não precisa redigir outro briefing. Este pacote já define o que fazer com cada informação quando ela chegar.

## O que não é necessário enviar como material bruto

O Positioning inteiro e a tese de Produtos internos + IA foram usados para produzir a síntese. Eles contêm hipóteses, histórico e informações internas que não devem se transformar automaticamente em copy pública. O dossiê já incorpora o que orienta o website e aponta conflitos. Não colocar os documentos brutos em uma pasta pública do projeto.

## Como avaliar a primeira prévia

- Uma pessoa sem experiência em marketing entende em uma primeira leitura o que está contratando?
- Ela reconhece uma empresa com negócio relevante na linguagem do site?
- O gradiente oficial está reconhecível e central na experiência?
- O acoplamento tem significado visível, além de um efeito de vidro?
- O selo apresenta uma contribuição concreta da MATA e distingue operação atual de histórico?
- Está claro que pessoas e IA trabalham juntas e que a equipe MATA opera a tecnologia?
- As três situações levam a páginas úteis, sem parecer pacotes de agência?
- Formulário e agenda são caminhos independentes?
- Os casos dizem o que mudou e como sabemos?
- A experiência mobile preserva a compreensão e a ação?

Se a prévia estiver bonita, mas exigir uma explicação verbal sua para a pessoa entender a oferta, a hierarquia ainda precisa ser ajustada.
