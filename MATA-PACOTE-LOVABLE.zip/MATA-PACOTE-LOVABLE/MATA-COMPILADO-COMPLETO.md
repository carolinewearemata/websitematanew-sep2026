# MATA — Compilado completo para o novo website

Preparado para Caroline Miranda Martha • 14 de setembro de 2026

Pesquisa, estratégia, arquitetura, copy, direção visual e orientação para implementação no Lovable.

Este arquivo reúne o briefing completo para leitura contínua. No ZIP, os capítulos também estão separados para facilitar os envios por etapa, junto de gradiente oficial, capas, logos, fontes, skills consultadas e artigos. Não é necessário enviar simultaneamente este compilado e todas as suas cópias por capítulo.

Direção: Infraestrutura de Marketing Acoplável; pessoas + IA; gradiente MATA central; percepção de martech; assinatura proposta MATA built in.; formulário curto e agenda direta; português primeiro e inglês após refinamento; publicação manual do Blog nesta fase. Recomendação de endereço editorial: /pt/blog, ainda a confirmar.

## Documentos reunidos

1. 01-COMECE-AQUI-LOVABLE.md
2. 02-DOSSIE-ESTRATEGICO-MATA.md
3. 03-COPY-E-ESTRUTURA-POR-PAGINA.md
4. 04-CONHECIMENTO-DO-PROJETO.txt
5. 05-IMPLEMENTACAO-E-QA.md
6. 06-COLETA-DE-CASES-E-PENDENCIAS.md
7. 07-GRADIENTE-SELO-E-BLOG.md
8. PROMPT-INICIAL-LOVABLE.txt



---

Documento: 01-COMECE-AQUI-LOVABLE.md

# Como usar o pacote do website MATA

Preparado para Caroline Miranda Martha • atualizado em 14 de setembro de 2026

## O que foi preparado

Um briefing para atualizar o projeto existente de wearemata.co no Lovable. A direção é **Infraestrutura de Marketing Acoplável**, com um time de pessoas e um time de IA, três situações de entrada, Blog explícito e dois caminhos de contato: formulário curto e agendamento.

O pacote contém estratégia, copy por página, direção visual, referências reais, instruções de execução e critérios de revisão. Não contém uma implementação nova do website.

## O que enviar ao Lovable

Descompacte MATA-PACOTE-LOVABLE.zip. Não dependa de o Lovable conseguir ler um ZIP como se fossem todos os arquivos internos.

### Primeiro envio, no projeto atual do site

1. **02-DOSSIE-ESTRATEGICO-MATA.md** — raciocínio, público, arquitetura, fontes, diagnóstico e decisões.
2. **03-COPY-E-ESTRUTURA-POR-PAGINA.md** — conteúdo proposto de cada página e componente.
3. **05-IMPLEMENTACAO-E-QA.md** — comportamento, critérios de aceite e integração.
4. **07-GRADIENTE-SELO-E-BLOG.md** — centralidade do gradiente, proposta MATA built in., marcas confirmadas e recomendação de endereço do Blog.
5. As **duas imagens da pasta assets/referencias** e **assets/gradientes/MATA-gradiente-oficial.png** — enviar como imagens para que o Lovable veja a direção do acoplamento e o gradiente obrigatório.
6. O texto de **PROMPT-INICIAL-LOVABLE.txt** — colar na conversa.

Em **Project settings → Knowledge**, colar o conteúdo de **04-CONHECIMENTO-DO-PROJETO.txt**. O arquivo tem menos de 10.000 caracteres e reúne as regras que devem permanecer. O dossiê completo fica como referência detalhada. Esse uso segue a documentação consultada de [Project knowledge](https://docs.lovable.dev/features/knowledge).

### Para implementar a identidade

Enviar os arquivos de **assets/logos** e **assets/fontes**. As fontes foram copiadas do pacote oficial da MATA, junto com o aviso de licença disponível. A equipe de implementação deve conservar e conferir as condições de uso na publicação.

Enviar **referencias-skills/MATA-DESIGN-SYSTEM.md**, **referencias-skills/DESIGN-MASTER.md** e **referencias-skills/WEB-DESIGN-MASTER.md** se o Lovable precisar aprofundar os critérios. Essas cópias são referências para o briefing, não uma instalação automática de skills nem uma atualização das versões oficiais no Drive. As principais regras já estão traduzidas para os arquivos 02 a 05.

### Para o Blog

Enviar os três arquivos de **referencias-blog** quando a etapa editorial começar. São extrações de texto dos documentos encontrados, com origem e autoria. A formatação e os hyperlinks dos originais podem não estar integralmente preservados; revisar na publicação. Os artigos não precisam virar conteúdo completo da home.

## Idiomas e publicação editorial

Decisão confirmada: novo site e Blog primeiro em português. Publicação manual por enquanto. Inglês somente depois que a versão portuguesa estiver afinada. Recomendação de endereço: /pt/blog, aproveitando os idiomas existentes; /en/blog fica previsto para conteúdo traduzido no futuro, sem páginas vazias agora. A arquitetura dos artigos pode receber automação depois; isso não exige, por si só, subdomínio.

## Ordem de trabalho recomendada

1. **Leitura do projeto:** inventariar rotas, conteúdo, componentes, integrações e publicação existentes; registrar o que será preservado.
2. **Home e sistema visual:** implementar com copy real, exemplos claramente identificados e versões desktop/mobile. Conferir se a pessoa entende o acoplamento antes de ampliar.
3. **Páginas de entrada e funcionamento:** dar autonomia às jornadas de estruturar marketing, reposicionar e implantar; conectar o contato.
4. **Sobre, princípios e Blog:** manter coerência de linguagem, autoria e navegação.
5. **Evoluções:** inserir casos reais conforme o arquivo 06; manter rascunhos fora do menu público.
6. **Contato e publicação:** conectar a agenda, testar o formulário, revisar condições comerciais, idiomas, acessibilidade e busca. Só chamar a versão de pronta depois de verificar a saída real.

Não é necessário reenviar toda a pesquisa em cada mensagem. Manter as decisões permanentes no conhecimento do projeto e referenciar o arquivo da etapa em andamento.

## O que você ainda precisará acrescentar

| Item | Por que precisa | Impede o quê? |
|---|---|---|
| Agenda | Link já fornecido por Caroline e registrado no arquivo 05 | Apenas conferir abertura pública na implementação |
| Destino e acesso ao formulário | Conferir envio e recebimento | Publicar formulário funcional |
| Endereço e editor do Blog | Recomendação atual: /blog ou /pt/blog; subdomínio é alternativa | Fechar publicação editorial e links canônicos |
| Caso(s) documentado(s) e logos selecionados | Sustentar prova e de/para | Publicar a biblioteca de evoluções |
| Condições comerciais vigentes | Fechar capacidade, prazos e direitos sem contradição | Publicar FAQs específicas |
| Foto e biografia da fundadora | Apresentação pessoal precisa | Completar bloco de fundadora |

As grafias já confirmadas são Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF. O selo recomendado é MATA built in.; sua aplicação depende da relação e do escopo de cada marca.

Você não precisa redigir outro briefing. Este pacote já define o que fazer com cada informação quando ela chegar.

## O que não é necessário enviar como material bruto

O Positioning inteiro e a tese de Produtos internos + IA foram usados para produzir a síntese. Eles contêm hipóteses, histórico e informações internas que não devem se transformar automaticamente em copy pública. O dossiê já incorpora o que orienta o website e aponta conflitos. Não colocar os documentos brutos em uma pasta pública do projeto.

## Como avaliar a primeira prévia

- Uma pessoa sem experiência em marketing entende em uma primeira leitura o que está contratando?
- Ela reconhece uma empresa com negócio relevante na linguagem do site?
- O gradiente oficial está reconhecível e central na experiência?
- O acoplamento tem significado visível, além de um efeito de vidro?
- O selo apresenta uma contribuição concreta da MATA e distingue operação atual de histórico?
- Está claro que pessoas e IA trabalham juntas e que a equipe MATA opera a tecnologia?
- As três situações levam a páginas úteis, sem parecer pacotes de agência?
- Formulário e agenda são caminhos independentes?
- Os casos dizem o que mudou e como sabemos?
- A experiência mobile preserva a compreensão e a ação?

Se a prévia estiver bonita, mas exigir uma explicação verbal sua para a pessoa entender a oferta, a hierarquia ainda precisa ser ajustada.


---

Documento: 02-DOSSIE-ESTRATEGICO-MATA.md

# MATA — Direção estratégica do novo website

Preparado para Caroline Miranda Martha • 13 de setembro de 2026 • Versão de trabalho para implementação no Lovable

Este documento traduz a pesquisa em decisões de conteúdo, arquitetura e experiência. A copy proposta está no arquivo 03; as instruções de execução estão nos arquivos 01, 04 e 05. É um briefing fundamentado, não uma declaração de que o novo website já foi implementado ou testado.

## 1. A decisão central

A MATA deve ser apresentada como **Infraestrutura de Marketing Acoplável**: um time de pessoas e um time de IA que se conectam ao negócio para conduzir marketing, da escolha de prioridades à execução acompanhada.

O visitante precisa concluir: “Minha empresa pode passar a contar com uma estrutura que assume esse trabalho, entende o negócio e faz as partes funcionarem juntas.” Essa compreensão deve surgir antes de nomes de métodos, listas de competências ou explicações institucionais.

A percepção de martech virá de quatro evidências: uma infraestrutura reconhecível; tecnologia participando do trabalho; uma operação explicável; e responsabilidade humana clara. A identidade visual deve dar forma a essa proposta. O site não deve criar a expectativa de uma assinatura de software que o próprio comprador precisará configurar e operar.

### Nome da categoria e linguagem pública

| Formulação | Papel recomendado | Razão |
|---|---|---|
| Infraestrutura de Marketing Acoplável | Categoria principal em português | Torna a oferta mais acessível a quem não trabalha com marketing e preserva a lógica central do acoplamento. |
| Infraestrutura de Brand Marketing Acoplável | Definição aprofundada e contextos especializados | Explicita a centralidade da marca, mas aumenta o esforço de interpretação. |
| Brand Marketing Infrastructure | Assinatura institucional possível | Mantém o território internacional, porém não explica sozinha a característica acoplável. |
| Pluggable Brand Marketing Infrastructure | Categoria recomendada em inglês | Preserva o acoplamento na tradução. Exige revisão editorial da versão completa em inglês. |
| Brand marketing, built in. | Assinatura expressiva, conforme referência enviada | É uma síntese de marca; precisa estar acompanhada da explicação do modelo. |
| Martech | Enquadramento institucional | Útil para descrever o tipo de empresa, sem impor ao comprador um novo termo como requisito de compreensão. |

Recomendação: usar uma categoria principal consistente. Não alternar cinco definições na mesma jornada. “Brand” continua presente no conteúdo: posicionamento, percepção de valor, narrativa, coerência e implantação da marca.

### O significado de acoplável

Acoplar é conectar uma capacidade de trabalho à realidade de uma empresa que já existe. Envolve aprender o negócio, reconhecer suas relações e prioridades, combinar responsabilidades e colocar a estrutura para trabalhar nesse contexto. O visual de encaixe deve expressar essa conexão.

O acoplamento não é instantâneo: precisa de acesso às pessoas e informações relevantes. Tampouco significa tomar decisões de negócio sem a liderança. O benefício é reduzir a necessidade de a liderança reconstruir contexto, organizar cada passagem e cobrar todo próximo passo.

“Acoplável” descreve a capacidade de conexão. “Acoplada” descreve a estrutura em funcionamento. “Incorporada” pode explicar a proximidade, mas não deve substituir a palavra central em todos os pontos.

## 2. O comprador e as três situações de entrada

Há um público prioritário e uma segunda família de necessidades. Não são três públicos equivalentes.

### Prioridade 1 — Negócio relevante, marketing ainda sem estrutura

Empresa com produto ou serviço validado, clientes, operação e trajetória, mas sem ninguém de marketing ou sem uma função capaz de conduzir o conjunto. O comprador provável é fundador, CEO, sócio ou liderança comercial/operacional. São papéis de trabalho para orientar a arquitetura, não personas validadas por entrevistas nesta pesquisa.

O que pode estar acontecendo: decisões de marketing voltam para a liderança; fornecedores recebem partes do contexto; o produto só é bem explicado em uma reunião; o site não acompanha a oferta; iniciativas param quando a agenda aperta.

O que precisa ver: o que a MATA assume, quem conduzirá o trabalho, como começa, que participação continua sendo necessária, como prioridades e capacidade são combinadas e o que ficará funcionando.

### Prioridade 2A — O negócio avançou, a marca ficou para trás

Empresa cuja capacidade, portfólio, mercado ou ambição mudou. Precisa descobrir como tornar essa evolução compreensível e crível para o comprador.

O que precisa ver: leitura do negócio antes de identidade visual, preservação do que gera confiança, investigação de público e oferta, decisões de posicionamento, tradução em comunicação e plano de implantação.

### Prioridade 2B — O reposicionamento foi aprovado, mas não entrou em uso

A direção de marca pode ter sido construída pela própria empresa ou por outro parceiro. Falta conectá-la ao site, aos materiais, ao comercial, ao conteúdo e às decisões cotidianas.

O que precisa ver: a MATA pode começar pela direção existente, verificar o que ela resolve e organizar a implantação. Não presumir que será necessário refazer todo o branding para poder ajudar.

### Qualificação sem elitismo

Falar de negócio validado, necessidade recorrente, complexidade, acesso e vontade de dar continuidade. Não inventar corte mínimo de faturamento, número de colaboradores, investimento ou setor. O briefing atual não autoriza fechar a oferta exclusivamente em B2B. Usar exemplos B2B e B2B2C quando houver evidências, com filtro por situação de negócio.

Evitar “empresas sem marketing” como sinônimo de empresas atrasadas. Muitas cresceram por produto, serviço, reputação e relações comerciais. A estrutura passa a ser necessária em um novo momento.

## 3. Perguntas que o site precisa responder

| Pergunta do visitante | Resposta que o site deve oferecer | Onde |
|---|---|---|
| Isso serve para uma empresa como a minha? | Reconhecimento das três situações, com prioridade visual para a primeira | Hero e entradas da home |
| O que estou contratando? | Infraestrutura acoplável, com pessoas, IA e condução do trabalho | Home e Como funciona |
| Vou ter que gerenciar mais um fornecedor? | Responsável, prioridades, acompanhamento e participação da liderança | Demonstração e FAQ |
| É uma ferramenta que eu preciso aprender a usar? | A equipe MATA opera a tecnologia que sustenta o trabalho | Bloco humano + IA |
| O que vocês fazem de concreto? | Exemplos de decisões e desdobramentos em marca, site, comercial e conteúdo | Como funciona e páginas de entrada |
| Vocês entendem meu negócio? | Forma de investigação e evidência de trabalhos reais | Método, Sobre e casos |
| Preciso refazer minha marca? | Diagnóstico distingue direção, expressão e implementação | Reposicionamento |
| Já temos estratégia. Vocês colocam em prática? | Entrada específica para implantação | Implantar posicionamento |
| O que continua comigo? | Direção de negócio, orçamento e decisões reservadas | Responsabilidades e FAQ |
| Quanto custa e como dimensiona? | Explicação da capacidade e das condições a combinar, sem valores inventados | Como funciona e Contato |
| Por que confiar? | Casos contextualizados, pessoas identificadas e trabalho verificável | Prova e Sobre |
| Qual o próximo passo? | Conversa sobre a empresa, com contexto suficiente para começar | CTA e Contato |

## 4. O que a pesquisa mudou na proposta

### MATA Positioning

Reforça leitura profunda do negócio, iniciativa, continuidade depois da entrega, estrutura flexível e alívio de coordenação para a liderança. Também contém hipóteses, versões históricas, condições comerciais divergentes e debates internos. Não é uma especificação única pronta para ser copiada.

Aplicação: aproveitar os mecanismos que tornam a promessa compreensível; retirar do texto público afirmações absolutas e decisões antigas conflitantes. A orientação desta conversa sobre acoplamento, público e percepção de martech prevalece sobre rascunhos anteriores.

### Diagnóstico do site e Arquitetura e copy v0.1

Os dois documentos acertam ao mudar a hierarquia: situação do negócio, modelo, mecanismo, efeito e prova. A nova proposta preserva isso e faz quatro ajustes: explicita o acoplamento; diferencia implantação de reposicionamento; inclui Blog literalmente no menu; e torna a home mais seletiva, deixando o aprofundamento para rotas específicas.

Não recomendo implementar toda a home com conteúdo que muda ao selecionar uma persona. Isso dificulta comparar entradas e pode esconder informação importante. Links claros para páginas específicas tornam as alternativas legíveis e compartilháveis.

### Produtos internos + IA

O insight mais relevante é a distinção entre comprador e operador. A empresa compra capacidade de condução; a equipe MATA opera a tecnologia. O documento diferencia uso real de IA, práticas em consolidação, protótipos e propostas de produtos.

Aplicação: apresentar a participação atual de pessoas e IA e demonstrar o fluxo de trabalho. Não anunciar MATA Projects, MATA Ecosystem, MultiCA ou um Brand OS completo como produtos disponíveis sem validação operacional. Não transportar metas de piloto, cenários, custos internos ou hipóteses de margem para o site.

### Os três artigos localizados na pasta Blog e Artigos

| Artigo | Autoria indicada na fonte | Aprendizado para o website |
|---|---|---|
| Produzir marketing não é conduzir marketing | Caroline Miranda Martha | O valor está também no trabalho que antecede e sucede a produção. “Coordenação devolvida” ajuda a entender a dor, mas precisa de uma cena concreta no site. |
| Como estruturar a área de marketing quando a empresa já cresceu | Time da MATA | Organizar problema, responsabilidade e capacidade antes de contratar canais e profissionais. Autonomia depende de acesso e mandato. |
| O reposicionamento foi aprovado? Sim. E agora? | Caroline Miranda Martha | A nova marca é testada em propostas, páginas e conversas reais. Implementação é uma necessidade própria. |

A voz é próxima, observadora e capaz de explicar tensões sem simplificações falsas. A home deve ser mais curta do que os artigos; o Blog preserva o argumento desenvolvido e a autoria correta.

### Presença digital, Estratégia editorial e Mapa de demanda

Contribuem com uma ponte entre linguagem de busca e categoria própria. As páginas comerciais respondem à decisão de contratar. O blog responde a dúvidas, diagnósticos e comparações. As prioridades de busca são hipóteses de aderência ao público, não volumes medidos nesta tarefa.

## 5. Diagnóstico independente do site em produção

Site inspecionado: [wearemata.co/pt](https://wearemata.co/pt). A abertura pela raiz levou a /en nesta sessão; foi possível mudar para português. Foram lidas as seis rotas do menu em português e a home em inglês. Foram operados os sete movimentos de Como funciona, a troca de idioma e o menu mobile.

Inspeção visual: home, funcionamento, resultados e contato em desktop; home, contato e navegação em viewport de 375 × 812. É uma avaliação de conteúdo e experiência por amostragem. Não houve envio de formulários, teste de recebimento, acesso a analytics ou medição de Core Web Vitals.

| Achado | Consequência | Mudança recomendada |
|---|---|---|
| A primeira dobra diz o que a MATA é, mas não identifica o comprador nem explica pessoas + IA | O visitante precisa rolar para reconhecer a pertinência | Público, composição e ação disponíveis no início |
| “Time completo ou segunda camada” aparece logo na home e no funcionamento | Duas promessas competem com o foco comercial | Priorizar a estrutura para quem precisa assumir a função; tratar exceções em conversa |
| Posicionamento & Assets, Desdobramentos & Aplicações, Manifestações & Eventos organizam a oferta | A leitura se aproxima de uma coleção de serviços | Organizar por responsabilidade e situações de negócio |
| Blocos de dados de mercado aparecem antes da prova própria | O visitante recebe uma justificativa genérica antes de evidência da MATA | Subir um caso validado ou uma demonstração identificada |
| As formas translúcidas são recorrentes, mas não explicam relações com precisão | O visual sugere tecnologia sem mostrar o acoplamento | Dar rótulos, função e sequência ao gesto de conexão |
| A home mobile tem grande intervalo antes da mensagem e a explicação está abaixo | Usa o espaço inicial sem esclarecer o modelo | Reduzir a altura mínima do hero; texto essencial antes da imagem secundária |
| O CTA atual é longo e recebe leitura pequena no celular | A ação perde legibilidade | “Conversar sobre minha empresa” ou “Ver como funciona” |
| Como funciona abre com H2 na árvore observada | A hierarquia editorial da rota pode ser mais clara | Um H1 descritivo por rota, com movimentos em níveis subsequentes |
| O menu português mistura HOME e STORY e não tem Blog | Navegação menos direta para esse comprador e ausência da entrada editorial | Rótulos em português e Blog explícito |
| O nome acessível do botão mobile é “Toggle menu” | Há um detalhe de idioma a corrigir | “Abrir menu” / “Fechar menu”, com estado expandido |
| Resultados usa “Em apenas 7 meses” | O enquadramento envelhece e privilegia volume/velocidade | Casos com período, contexto e transformação |
| Caso de imprensa anuncia 35; detalhamento mostra 6 + 24 + 1 | O detalhamento não explica quatro inserções | Conciliar contagem, período, deduplicação e categorias |
| Caso da holding usa aproximadamente US$ 80M de ARR | O indicador precisa de definição e autorização | Verificar se se trata de receita anual ou receita recorrente anual e se pode ser publicado |
| “Tudo que a gente constrói fica na sua marca” inclui agentes e sistemas | Pode conflitar com a tese de produtos internos da MATA | Definir entregáveis da marca, registros e infraestrutura reutilizável separadamente |

O formulário e os canais diretos estão visíveis. O e-mail publicado é hello@wearemata.company; o domínio de e-mail não deve ser trocado para .co por suposição. O WhatsApp observado está documentado no pacote de implementação. A leitura desses links não comprova recebimento.

## 6. Arquitetura recomendada

### Navegação principal

**Como funciona · Para sua empresa · Evoluções · Sobre · Blog · Conversar sobre minha empresa**

“Para sua empresa” abre três links: Estruturar marketing, Reposicionar a marca, Implantar o posicionamento. No celular, uma lista expansível com os mesmos destinos. O logo retorna à home. A nova versão nasce em português; inglês só será adaptado depois de a experiência PT estar afinada, conforme decisão de Caroline. Inventariar rotas inglesas existentes sem traduzir ou anunciar equivalência agora. Nenhum seletor deve levar a uma tradução nova inexistente.

“Evoluções” entra na navegação pública quando houver ao menos um caso preparado para publicação. A estrutura da página e dos casos fica pronta em rascunho. Não mostrar uma página vazia nem inventar resultados para preencher o menu.

“MATAthinking” é o nome do pensamento e dos princípios. Fica em Sobre, no rodapé e conectado ao Blog. Não substitui o rótulo Blog que Caroline pediu explicitamente.

### Rotas

| Rota sugerida | Trabalho da página | Prioridade |
|---|---|---|
| /pt | Reconhecer situação, compreender oferta e avançar | Lançamento |
| /pt/how-it-works | Explicar acoplamento, pessoas + IA, capacidade, responsabilidade e início | Lançamento; preservar endereço existente |
| /pt/estruturar-marketing | Converter a principal situação de compra | Lançamento |
| /pt/reposicionamento | Explicar mudança de direção e sua implantação | Lançamento |
| /pt/implementar-posicionamento | Receber quem já tem estratégia aprovada | Lançamento |
| /pt/results | Biblioteca de evoluções reais | Preparar; publicar com evidência |
| /pt/results/[slug] | Um caso completo e compartilhável | Conforme documentação |
| /pt/story | Origem, fundadora, visão e modo de construir a empresa | Lançamento; rótulo Sobre |
| /pt/principles | MATAthinking e princípios operacionais | Preservar e atualizar |
| /pt/contact | Dar contexto e iniciar uma conversa | Lançamento |
| /pt/blog | Índice editorial no site; /blog se a arquitetura final dispensar prefixo de idioma | Recomendação atual de publicação; endereço final a fechar |

Manter as rotas atuais quando isso evita migrações desnecessárias. Se os slugs forem traduzidos, criar redirecionamentos individuais para seus equivalentes e atualizar links internos. Não redirecionar todas as páginas antigas para a home.

### Jornada principal

```mermaid
flowchart TD
    A[Home: reconheço meu momento] --> B[Entendo a infraestrutura acoplável]
    B --> C[Vejo pessoas e IA trabalhando]
    C --> D[Encontro prova ou exemplo identificado]
    D --> E[Converso sobre minha empresa]
    A --> F[Estruturar marketing]
    A --> G[Reposicionar a marca]
    A --> H[Implantar uma direção aprovada]
    F --> E
    G --> E
    H --> E
    I[Artigo do Blog] --> F
    I --> G
    I --> H
```

### A home em oito blocos

1. **Oferta e reconhecimento:** categoria, mensagem central, pessoas + IA, público e dois caminhos de ação.
2. **Situação de entrada:** um bloco de maior peso para estruturar marketing; dois caminhos relacionados à marca.
3. **Prova curta:** um caso validado com contexto; enquanto não existir, exemplo ilustrativo identificado de como o trabalho se conecta.
4. **Acoplamento em funcionamento:** demonstração de um problema passando por contexto, decisão, execução e revisão.
5. **Pessoas + IA:** divisão de trabalho, responsável humano e benefício para quem contrata.
6. **O que muda para a liderança:** continuidade, clareza e espaço mental, com mecanismos concretos.
7. **Pensamento e leituras:** três artigos escolhidos pelas perguntas que respondem.
8. **Conversa e dúvidas essenciais:** CTA, expectativa do próximo passo e acesso ao aprofundamento.

Não repetir um longo “Como funciona” depois de uma demonstração que já explica o ciclo. A home oferece a compreensão necessária; a rota específica responde às objeções de contratação.

## 7. Direção visual: o acoplamento como linguagem

### Referências diretamente fornecidas por Caroline

A imagem “Brand marketing, built in.” comunica uma capacidade inserida em um fluxo. A capa provisória mostra um módulo MATA ligado a estruturas vizinhas por conexões translúcidas. A segunda é a referência principal para a lógica espacial; a primeira, para síntese verbal e conexão entre matéria e tipografia.

Usar as imagens como evidência de direção. Não aplicar uma capa inteira como fundo com texto adicional por cima: isso prejudica adaptação, leitura e repetição. Construir a composição com texto real e elementos visuais separados. O logotipo aplicado no novo site deve vir dos arquivos oficiais atuais, mesmo quando uma referência incorpora uma versão anterior.

### Conceito escolhido

**A estrutura da empresa recebe uma capacidade de marketing e passa a trabalhar conectada a ela.**

No hero, uma composição assimétrica: mensagem dominante à esquerda; estrutura modular à direita ou atravessando a borda do bloco sem cobrir o texto. Um módulo MATA se conecta ao negócio. Não colocar a MATA como dona de vendas, produto e operação: as conexões representam troca de contexto, não hierarquia sobre todas as áreas.

Ao avançar, a composição se torna uma explicação: uma pergunta que vem do comercial, um ponto de decisão, um material em uso e o retorno dessa experiência. É o mesmo vocabulário formal com mais informação, em vez de diferentes efeitos a cada seção.

### Alternativas consideradas

| Conceito | Potencial | Decisão |
|---|---|---|
| Manifesto tipográfico | Força verbal e simplicidade | Usar em momentos curtos, mas não como toda a explicação de categoria |
| Infraestrutura acoplada | Une posicionamento, referências e demonstração | Direção escolhida |
| Portfólio em grande escala | Prova criativa imediata | Reservar para casos; como estrutura central favoreceria percepção de agência |

### Aplicação do Design System

Fontes consultadas: MATA Design System oficial, fundamentos, identidade, layout/componentes, direção de arte e QA; Design Master — Instrução completa; Web Design Master e referências de integração, direção e registros de superfície.

| Papel | Direção |
|---|---|
| Base | #F1F2F4 e branco, com predominância clara |
| Texto principal / ação | #171C1B; botão escuro com texto branco |
| Apoio | Prata #D8DDE1, azul-gelo #DEE5EB, menta pálida #B0E6D8 |
| Energia | #00F0A9 com parcimônia, como reflexo ou indicação de conexão |
| Verde profundo | Material do módulo conforme referência e ativo oficial; não transformar todas as seções em fundos verdes |
| Tipo | Stack Sans; Headline para impacto e Text para leitura, como proposta de aplicação dos arquivos disponíveis |
| Material | Vidro refrativo, prata/lilás e superfície fosca com sombra plausível |
| Formas | Módulos com encaixe e conexões visíveis; função antes de repetição decorativa |
| Movimento | Conectar, revelar relação e registrar uma mudança; transições funcionais de 180–260 ms |

O token de texto secundário #6F7777 precisa de contraste conferido no fundo efetivo; para informação essencial, preferir o texto principal. Não assumir que um token é acessível em qualquer combinação.

### Gradiente como assinatura obrigatória

Caroline reforçou que o gradiente é um dos elementos mais importantes do design. Ele deve ser reconhecível na primeira dobra, na atmosfera do acoplamento e em momentos de continuidade. Usar **assets/gradientes/MATA-gradiente-oficial.png**, a referência oficial do sistema, junto das duas capas. A neutralidade da interface protege a leitura; não deve apagar a assinatura cromática. O arquivo 07 define aplicações, token oficial e critérios de comparação visual.

### Tipografia e densidade

Proposta local para este site: títulos de destaque em torno de 56–80 px no desktop, adaptados ao comprimento real; 34–44 px no celular; corpo de 18 px quando possível; medidas confortáveis para leitura. São pontos de partida para inspeção, não obrigação de caber em duas linhas.

Evitar capitalização integral e espaçamento excessivo nas frases longas dos botões. A marca admite títulos grandes e cortes deliberados, mas os termos essenciais do hero, as ações e o conteúdo funcional devem permanecer legíveis.

### Um momento memorável, explicado

Demonstração proposta, explicitamente ilustrativa até ser substituída por um caso real:

1. Comercial identifica uma dúvida recorrente: o comprador não entende uma diferença importante da solução.
2. O time MATA investiga a dúvida e reúne o contexto necessário.
3. Pessoas e IA organizam materiais e alternativas; a pessoa responsável decide a resposta e os limites de aprovação.
4. A decisão chega à página, à proposta e ao conteúdo relevante.
5. O uso dos materiais gera retorno para a próxima revisão.

Mostrar uma transformação por vez. O elemento visual principal é o contexto atravessando conexões; não uma interface fictícia com números de produtividade ou agentes trabalhando sozinhos. A versão estática deve explicar a mesma sequência.

### Mobile

Texto e CTA antes da composição secundária. A imagem pode virar um recorte específico ou uma sequência vertical de dois/três estados. Não reduzir um diagrama desktop inteiro até os rótulos ficarem ilegíveis. Não exigir arrastar, passar o mouse ou assistir a uma animação para entender a oferta. Evitar hero com altura fixa que empurre a explicação para fora da primeira tela.

## 8. Como tornar AI-oriented compreensível

É importante aparecer em vários lugares, mas cada aparição deve acrescentar informação:

| Lugar | Mensagem | O que acrescenta |
|---|---|---|
| Hero | Um time de pessoas e um time de IA | Composição da infraestrutura |
| Demonstração | IA organiza contexto e prepara trabalho; pessoas conduzem decisões | Funcionamento |
| Como funciona | Responsáveis, revisão, acesso e atualização de contexto | Confiança operacional |
| Sobre | A MATA constrói seu modelo com IA participando do trabalho | Visão da empresa |
| Blog | Discussão fundamentada sobre produção, coordenação e capacidade | Profundidade de pensamento |

“AI-oriented” pode aparecer como assinatura secundária, imediatamente explicado em português. Evitar encher páginas com variações de “powered by AI”. O visitante deve saber por que a IA melhora o trabalho que está contratando.

A distinção entre software interno e produto vendido é essencial. A MATA pode desenvolver componentes e métodos reutilizáveis e usar ferramentas de terceiros. Não chamar todo uso de IA de tecnologia proprietária, nem descrever acesso a documentos como treinamento de um modelo exclusivo.

## 9. Prova: de/para das marcas

O de/para deve tornar visível uma evolução em três níveis:

1. **Percepção:** o que a comunicação permitia entender antes e o que passou a explicar.
2. **Capacidade:** o que a empresa passou a conseguir fazer em marketing.
3. **Operação:** como essa capacidade passou a ter continuidade.

Uma comparação de logos pode ser um detalhe da prova. O principal é explicar a mudança e mostrar os materiais, decisões ou efeitos que a sustentam.

### Estrutura de caso

Contexto da empresa → situação anterior → mandato da MATA → decisões → execução em uso → mudança observada → evidências → continuidade → contribuição de outros envolvidos.

Cada métrica precisa de período, definição, fonte e limite de atribuição. Diferenciar alcance de demanda, produção de uso e receita de sinais anteriores à venda. A presença de um resultado no site atual é uma fonte de alegação, não sua validação independente.

### Marcas citadas nesta conversa

Lista corrigida e confirmada por Caroline: **Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF**. As grafias estão resolvidas. Completar marca/grupo, período e escopo de cada relação. Não associar um case anônimo a uma marca por aproximação.

A autorização inicial para usar logos foi seguida da decisão de deixar esse detalhe para depois. Portanto, preparar o componente, mas manter a seleção pública em aberto. Não escrever “já trabalhamos com” para todas as marcas, pois algumas relações podem estar em curso. Caroline quer uma assinatura de infraestrutura incorporada, desenvolvida no arquivo 07. Recomendação: **MATA built in.**, descritor **Infraestrutura de Brand Marketing**. A seção passa a ser **A infraestrutura MATA, incorporada a negócios reais.** O selo distingue operação atual e ciclo histórico; projetos pontuais não recebem automaticamente o selo integral.

### O que pedir para cada caso

- Nome e grafia de exibição; relação atual ou concluída; datas.
- Situação anterior em palavras de quem viveu o problema.
- O que a MATA assumiu e o que ficou com a empresa/outros parceiros.
- Materiais anteriores e posteriores comparáveis, com contexto de uso.
- Decisões de posicionamento/marketing que explicam as diferenças.
- Evidência de uso, resultado ou mudança operacional.
- Números com denominador, janela temporal e fonte.
- Depoimento literal, nome, cargo e condições de uso.
- Logo oficial atual e materiais que podem aparecer publicamente.
- O que permanece confidencial.

O formulário completo para essa coleta está no arquivo 06. A documentação dos cases não precisa impedir a arquitetura e a primeira implementação do site.

## 10. Blog conectado à MATA: endereço em avaliação

Caroline inicialmente considerou um domínio separado e depois perguntou sobre subdomínio versus /blog. A recomendação atual é **wearemata.co/blog**, ou **/pt/blog** conforme idiomas, pela continuidade da experiência e da manutenção. O endereço final ainda não foi confirmado. O arquivo 07 compara opções; blog.wearemata.co permanece alternativa se uma plataforma editorial separada justificar. Preparar configuração única e links contextuais.

/pt/blog pode funcionar como índice definitivo dos textos disponíveis se for adotada a recomendação de subdiretório. Se os artigos ainda não forem publicados, não criar links para endereços que não existem. O Blog pode entrar em uma etapa de publicação coordenada com o site. Evitar um menu com destino quebrado ou um feed inventado.

Caso Caroline escolha uma publicação em subdomínio: Blog no cabeçalho aponta para a publicação; artigos retornam à MATA por links contextuais; identidade e autoria permanecem consistentes; cada artigo tem um endereço principal; não carregar o blog inteiro dentro de iframe.

Se houver migração de artigos já publicados, mapear cada URL antiga para a correspondente e testar os redirecionamentos. O Google recomenda mapeamento e redirecionamentos para mudanças de URL; a preferência de canonical ajuda a consolidar duplicatas, mas não garante a escolha pelo buscador. [Migrações](https://developers.google.com/search/docs/crawling-indexing/site-move-with-url-changes), [canonical](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls).

### Organização editorial inicial

Três trilhas: **Estruturar marketing**, **Marca em movimento**, **Pessoas + IA**. Começar com os três artigos disponíveis. Não criar múltiplas categorias vazias nem vinte artigos artificiais para dar volume.

| Artigo existente | Link comercial natural | Próxima leitura |
|---|---|---|
| Como estruturar a área de marketing quando a empresa já cresceu | Estruturar marketing | Produzir marketing não é conduzir marketing |
| O reposicionamento foi aprovado? Sim. E agora? | Implantar o posicionamento | Como funciona |
| Produzir marketing não é conduzir marketing | Como funciona | Guia de estruturação |

Pautas seguintes sugeridas: quando reposicionar; quem assume marketing quando tudo volta para o CEO; o que muda quando a empresa já tem uma estratégia de marca; como comparar estruturas pelo trabalho necessário. São prioridades editoriais, não conteúdo já produzido.

### Modelo de artigo

Título → resposta ou situação de abertura → autoria real → publicação/atualização reais → corpo com subtítulos → exemplos e fontes → leituras relacionadas → CTA contextual. Tempo de leitura pode ser calculado. Datas não devem ser inventadas a partir da modificação de um arquivo no Drive.

A voz de Caroline e a autoria Time da MATA precisam permanecer distintas. Não transformar o artigo institucional em texto pessoal da fundadora. As cópias de texto incluídas no pacote são referências editoriais; revisar links e formatação na publicação.

## 11. Conversão e qualificação

Objetivo principal proposto: **conversas com empresas aderentes**, não o maior volume possível de formulários. Caroline confirmou dois caminhos independentes: “Conversar sobre minha empresa”, levando a um formulário curto, e “Agendar uma conversa”, levando à agenda real. O formulário não é pré-requisito para agendar. A agenda foi fornecida por Caroline: https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C .

Campos essenciais sugeridos: nome, e-mail, empresa/site e situação principal. Campo livre: “O que precisa mudar?”. Não pedir uma anamnese completa na primeira interação. Perguntas de orçamento, acessos e prioridades podem ser aprofundadas na conversa.

O contexto escolhido na home deve chegar ao contato como informação editável. O visitante não deve preencher tudo novamente depois de selecionar uma entrada. Manter alternativas de e-mail e WhatsApp visíveis.

Não prometer diagnóstico gratuito, prazo de resposta, proposta imediata ou reunião com Caroline sem confirmação. Não informar que uma mensagem foi recebida enquanto o destino não confirmar o envio.

### Eventos úteis

`primary_cta_click`, `entry_route_click`, `contact_form_start`, `contact_form_success`, `contact_form_error`, `whatsapp_click`, `blog_outbound_click`, `case_view`.

Anexar rota, idioma, posição do CTA e situação selecionada. Evitar incluir nome, e-mail e mensagem livre nos eventos. Um clique no WhatsApp não é lead confirmado. A qualidade da conversa, o avanço comercial e a adequação da empresa devem ser acompanhados separadamente.

Medida inicial: linha de base após publicação, origem das conversas, aderência por entrada e motivos de perda. Só depois fazer testes de mensagem com uma hipótese por vez. Não prometer significância estatística ou taxas de conversão sem amostra e tráfego conhecidos.

## 12. Requisitos para o Lovable

Trabalhar no projeto existente. Inspecionar rotas, componentes, integrações, conteúdo e forma de publicação antes de alterar. O fato de ser Lovable não permite inferir a stack: sua documentação distingue projetos atuais com SSR de projetos anteriores com pré-renderização para crawlers. Verificar o projeto real. [SEO no Lovable](https://docs.lovable.dev/features/seo-aeo).

As instruções permanentes da MATA devem ficar no conhecimento deste projeto. O dossiê completo fica como referência de trabalho. O campo de Project knowledge admite até 10.000 caracteres segundo a documentação consultada; o arquivo 04 é uma síntese própria para esse uso. [Knowledge](https://docs.lovable.dev/features/knowledge).

Requisitos principais: rotas acessíveis diretamente; conteúdo textual e links rastreáveis; títulos e descrições por página; canonical e idioma coerentes; metadados sociais; imagens otimizadas com dimensões; formulário real; estados de erro/sucesso; teclado e foco; alternativa a movimento; página 404; verificação mobile.

Para busca e respostas com IA, não é necessário inventar uma camada especial de marcação. O Google mantém as bases de SEO, conteúdo útil, acesso ao texto e consistência entre marcação e conteúdo. Não há garantia de indexação ou citação em IA. [Google: AI features](https://developers.google.com/search/docs/appearance/ai-features).

## 13. Decisões firmes, recomendações e pendências

| Tema | Estado | Tratamento |
|---|---|---|
| Acoplamento como lógica verbal e visual | Confirmado por Caroline | Obrigatório |
| Um time de pessoas e um time de IA | Confirmado por Caroline | Visível desde a home |
| Percepção de martech | Confirmado por Caroline | Demonstrar composição, operação e tecnologia |
| Público principal sem marketing e negócio relevante | Confirmado por Caroline | Prioridade da narrativa |
| Reposicionamento e implantação | Confirmado por Caroline | Entradas distintas |
| Blog no menu | Confirmado por Caroline | Obrigatório |
| Endereço do Blog | Em avaliação após nova pergunta | Recomendação: /blog ou /pt/blog; subdomínio como alternativa |
| Gradiente oficial central | Confirmado por Caroline | Obrigatório no hero e na continuidade visual |
| MATA como selo de infraestrutura | Intenção confirmada; nome proposto | Desenvolver MATA built in. conforme arquivo 07 |
| Infraestrutura de Marketing Acoplável como nome principal | Recomendação deste dossiê | Usar como base para revisão |
| Formulação alternativa com Brand Marketing | Em avaliação | Manter como explicação aprofundada |
| Formato do contato | Confirmado por Caroline | Formulário curto + botão independente para agendar |
| Cases e logos | Deliberadamente pendentes | Componentes preparados; publicação com materiais válidos |
| Valores, mínimos, aviso prévio e prazos | Divergentes ou não confirmados | Não publicar números |
| Tecnologia proprietária e produtos internos específicos | Maturidade não comprovada nesta pesquisa | Não apresentar como catálogo disponível |
| Entregáveis e conhecimento na saída | Fontes com formulações conflitantes | Fechar texto comercial antes de prometer posse ampla |
| Inglês | Adiado por Caroline até PT estar afinado | Site e Blog novos primeiro em PT; inventariar legado e traduzir integralmente depois |

## 14. O que faria antes da publicação

1. Teste de compreensão com cinco pessoas próximas do público: o que a MATA é, para quem serve, o que se contrata, quem usa a tecnologia e qual seria o próximo passo. Amostra qualitativa, sem pretensão estatística.
2. Documentar ao menos um caso com de/para, mandato e evidência.
3. Validar condições comerciais, direitos sobre materiais e limites da autonomia para as FAQs.
4. Conferir o recebimento real do formulário e os links de contato com dados de teste autorizados.
5. Revisar o website implementado em desktop e mobile; uma boa especificação não substitui esse exame.

Essas etapas refinam uma proposta concreta. A primeira implementação pode avançar com os elementos disponíveis e os componentes pendentes em rascunho.

## 15. Fontes e alcance da pesquisa

Fontes internas lidas:

- [MATA — Positioning](https://docs.google.com/document/d/1s27tNF7xeywvKAVykik25c7qHVdjvlQYlpkBbNc7aRA/edit): princípios, discussões, seção website e modelo acoplável.
- [SITE — Diagnóstico vs. positioning](https://docs.google.com/document/d/1hNfGzGn37AOOpmlIUVyCMupbBSoTV7TQuovMkvWIJbc/edit).
- [SITE — Arquitetura e copy](https://docs.google.com/document/d/1MaVoJfhqI-tW7ODrGPh2ApTFzcv0cwUGWzvEQOqAYGQ/edit).
- [POSICIONAMENTO — Presença digital](https://docs.google.com/document/d/1awBnLfLyZnPx8Fcpv4kIZfdv0QzoJcUndS__zDkVeTI/edit).
- [TESE — Produtos internos + IA](https://docs.google.com/document/d/1W2-5nZgeJSKopWTxe9c90LmtPyuUYqpf/edit).
- [BLOG — Estratégia editorial](https://docs.google.com/document/d/1-pbKE-3IeJ5Ld8st9J41--HppRkrauJYoH-99xQD_G8/edit).
- [BLOG — Mapa de demanda e pautas](https://docs.google.com/document/d/1Fid78TlSCIyAmurcgeovYBucJWL2fEfnqtktdJDPOGE/edit).
- [Artigo — Produzir marketing não é conduzir marketing](https://docs.google.com/document/d/1_cFuMzRxNUot1TJ1XBcPKH8KOByhiV-D/edit).
- [Artigo — Como estruturar a área de marketing](https://docs.google.com/document/d/1JHlgb6KuTjxplUbLg2UKp6_YCXfQOKmf-qPkgRSZm0A/edit).
- [Artigo — O reposicionamento foi aprovado?](https://docs.google.com/document/d/1zE21XafQ9e0_8S0MY-fYxYbsXe8w9p8eu7E22U-e5U0/edit).
- [Design Master — Instrução completa](https://docs.google.com/document/d/1s-RKL66PNVuZWDBZhq-qsQ6Dd_Oei9mr3X7aHoGvmXg/edit).
- [Web Design Master — pacote oficial](https://drive.google.com/drive/folders/12skkvn2q0_3n__OjnpsD2V_IhB3Lp63A).
- [MATA Design System — pacote oficial](https://drive.google.com/drive/folders/1fxxhlKVSn5EoB-tVJevWP4gPJwIYHLMX).
- Duas imagens enviadas por Caroline nesta conversa, incorporadas ao pacote como referências.

Site observado: [Home](https://wearemata.co/pt), [Como funciona](https://wearemata.co/pt/how-it-works), [Resultados](https://wearemata.co/pt/results), [Sobre atual](https://wearemata.co/pt/story), [Princípios](https://wearemata.co/pt/principles), [Contato](https://wearemata.co/pt/contact).

Cobertura: a pasta SITE retornou dois documentos; a pasta Blog e Artigos retornou três artigos, dois estudos editoriais e uma pasta de assets. A busca também incluiu materiais de posicionamento e as skills oficiais. Esse é o conjunto localizado e estudado, não uma garantia de exaustividade sobre todo arquivo existente no Drive. Referências externas mencionadas nos documentos internos não foram todas reavaliadas; não são tratadas aqui como novos estudos independentes.

Não foram realizados: entrevistas com compradores, análise de tráfego, pesquisa quantitativa de palavras-chave, auditoria técnica completa, confirmação de resultados de clientes, teste de envio e implementação do site. As recomendações de estrutura e copy são síntese autoral desta pesquisa.


---

Documento: 03-COPY-E-ESTRUTURA-POR-PAGINA.md

# MATA — Copy e estrutura por página

Versão de trabalho proposta. Usar em conjunto com o dossiê. Os textos abaixo foram escritos para o novo site; não são citações dos documentos internos. Trechos marcados como pendentes não entram no site público. A implementação deve preservar a lógica e ajustar quebras de linha após inspeção responsiva.

## Sistema de navegação e ações

Menu: **Como funciona · Para sua empresa · Evoluções · Sobre · Blog**.

Submenu de Para sua empresa: **Estruturar marketing · Reposicionar a marca · Implantar o posicionamento**.

Ação principal: **Conversar sobre minha empresa** → formulário curto em /pt/contact.

Ação alternativa: **Agendar uma conversa** → [agenda fornecida por Caroline](https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C). Os dois caminhos são independentes. O formulário não é pré-requisito para agendar.

Link de exploração: **Ver como funciona**. Em vez de três botões com o mesmo peso, usar botão principal, botão secundário e link textual. Repetir a mesma hierarquia no rodapé de conversão.

Publicar Evoluções no menu quando houver caso validado. Blog precisa de destino funcional; agenda precisa de endereço real. As pendências devem ficar no controle de implementação, nunca renderizadas como texto entre colchetes para o visitante.

## 1. Home — /pt

### Bloco 1 — Reconhecimento e oferta

Etiqueta:

**Infraestrutura de Marketing Acoplável**

H1:

**Seu negócio cresceu. Acople uma estrutura de marketing à altura.**

Texto:

A MATA reúne um time de pessoas e um time de IA para conduzir o marketing junto ao seu negócio, da estratégia à execução. Para empresas que cresceram sem estruturar marketing e marcas que precisam acompanhar uma nova fase.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**

Link: **Ver como funciona →**

Visual: gradiente oficial MATA reconhecível na atmosfera da primeira dobra; estrutura da empresa à qual o módulo MATA se conecta. Mostrar no máximo três rótulos legíveis no primeiro estado: **Seu negócio**, **Time de pessoas**, **Time de IA**. Contexto e prioridades aparecem no aprofundamento, sem sobrecarregar o hero.

Nota de direção: “à altura” é uma promessa de adequação, sustentada pelo funcionamento e pelos casos. Não acrescentar promessas de receita, escala ou produtividade. A categoria principal já explica o acoplamento; a imagem reforça, não substitui a informação.

### Bloco 2 — Quando a MATA começa a fazer sentido

H2:

**O que o seu negócio precisa fazer acontecer agora?**

Introdução:

A estrutura começa pelo momento da empresa. Pode faltar quem conduza o marketing, uma marca que traduza o negócio atual ou um time para colocar uma nova direção em prática.

Entrada principal, com maior peso visual:

**A empresa cresceu. O marketing ainda depende de você.**

Seu negócio já tem clientes, produto e operação. A MATA se acopla à empresa para organizar prioridades, reunir as competências necessárias e dar continuidade ao trabalho de marketing.

Link: **Quero estruturar o marketing →**

Entrada secundária A:

**O negócio mudou. A marca ainda conta a história antiga.**

Ajudamos a traduzir a evolução da empresa em posicionamento, narrativa e pontos de contato que façam sentido para o mercado de hoje.

Link: **Quero reposicionar a marca →**

Entrada secundária B:

**A nova direção está pronta. Falta colocá-la em prática.**

Conectamos o posicionamento aprovado ao site, aos materiais comerciais, ao conteúdo e às escolhas que fazem a marca existir no dia a dia.

Link: **Quero implantar o posicionamento →**

Composição: um bloco principal mais amplo e duas entradas relacionadas. Evitar três planos de assinatura ou três pacotes de serviço. Todos os textos devem estar acessíveis sem interação obrigatória.

### Bloco 3 — MATA built in. e evidência

Etiqueta proposta: **MATA built in.**

H2 para conjunto validado:

**A infraestrutura MATA, incorporada a negócios reais.**

Introdução: Conheça onde a MATA está em operação e as estruturas que ajudou a construir. Cada história mostra o contexto, nossa participação e o que mudou. Ajustar a introdução se o conjunto publicado só incluir relações históricas.

Apresentar assinatura MATA, logo da empresa, status atual ou ciclo histórico, contribuição e acesso ao de/para. Não presumir que toda marca mencionada contratou infraestrutura completa; aplicar regras do arquivo 07.

Estrutura, a preencher com prova real:

- Situação da empresa e contexto relevante.
- Responsabilidade assumida pela MATA.
- Mudança em uso e sua evidência.
- Link: **Conhecer essa evolução →**.

Sem case pronto, usar o próximo bloco como demonstração antecipada. Não publicar logos cinza, números fictícios, depoimentos provisórios ou “em breve” no meio da prova.

### Bloco 4 — A infraestrutura em funcionamento

H2:

**Uma decisão de negócio precisa chegar ao trabalho.**

Texto:

Uma dúvida que aparece nas vendas pode mudar a forma de apresentar um produto. A MATA conecta essa leitura às prioridades de marketing e acompanha o caminho até a resposta entrar em uso.

Rótulo visível: **Exemplo ilustrativo de funcionamento**.

Sequência:

1. **O negócio traz uma questão.** O comprador não está entendendo uma diferença importante da solução.
2. **A MATA investiga e organiza.** O time conversa com as pessoas certas e reúne materiais e evidências.
3. **Pessoas e IA preparam o trabalho.** A IA ajuda a organizar informações e desenvolver versões. A pessoa responsável conduz as escolhas e a revisão.
4. **A decisão ganha forma.** A resposta chega à página, à proposta ou ao conteúdo que precisa mudar.
5. **O uso orienta a próxima escolha.** O retorno do comercial e do público ajuda a revisar o trabalho.

Fechamento:

Você participa das decisões de negócio. A MATA cuida de conectar essas decisões ao andamento do marketing.

Link: **Entender o acoplamento →**.

Interação: passos clicáveis e percorríveis por teclado; nenhum timer obrigatório. O conteúdo completo continua disponível em modo estático e com movimento reduzido. Não apresentar a sequência como caso de cliente ou fluxo autônomo já medido.

### Bloco 5 — Pessoas + IA

Etiqueta: **AI-oriented. Condução humana.**

H2:

**Um time de pessoas e um time de IA, trabalhando no contexto da sua empresa.**

Texto:

As pessoas conduzem a relação, as escolhas e a avaliação do trabalho. A IA participa da organização de informações, da preparação de versões e do apoio a atividades recorrentes, com direção e revisão humanas.

Frase de apoio:

Você conta com essa capacidade de trabalho. A equipe MATA opera a tecnologia que a sustenta.

Microblocos:

**Pessoas** — Entender, escolher, criar, conversar e responder pelo trabalho.

**IA** — Organizar contexto, preparar materiais e apoiar a execução.

**Prioridades compartilhadas** — O trabalho parte da realidade do negócio e dos objetivos combinados.

Não inserir uma quantidade fixa de profissionais, agentes ou ferramentas. A composição depende do mandato e da capacidade contratada.

### Bloco 6 — Efeito na liderança

H2:

**A MATA devolve espaço mental.**

Texto:

Ter marketing funcionando significa saber quem está conduzindo o trabalho, quais prioridades estão em andamento e onde sua decisão é necessária. A liderança continua próxima, mas deixa de precisar ligar cada ponta para o marketing avançar.

Três consequências, apresentadas como finalidade do modelo:

**Decisões chegam com contexto.** O time organiza a questão e apresenta uma recomendação.

**O trabalho tem continuidade.** Prioridades e próximos passos têm responsáveis.

**A marca acompanha o negócio.** O que muda na empresa pode se refletir na comunicação e nos materiais em uso.

Link: **Ver como dividimos as responsabilidades →**.

### Bloco 7 — Blog

H2:

**Perguntas que aparecem quando o negócio cresce.**

Texto:

Leituras sobre estrutura de marketing, evolução de marca e o trabalho de pessoas e IA dentro das empresas.

Três chamadas editoriais:

**Como estruturar a área de marketing quando a empresa já cresceu**

Critérios para escolher o que precisa ser organizado, quem conduz o trabalho e que capacidade será necessária. **Time da MATA**.

**O reposicionamento foi aprovado? Sim. E agora?**

O que acontece entre aprovar uma nova direção e fazer a empresa trabalhar a partir dela. **Caroline Miranda Martha**.

**Produzir marketing não é conduzir marketing**

Quando produzir fica mais acessível, onde o trabalho de marketing passa a se acumular? **Caroline Miranda Martha**.

Link: **Explorar o Blog →**.

Não inventar datas, links de publicação, capas ou tempo de leitura. O tempo pode ser calculado após a implantação dos textos; os resumos acima são copy nova para apresentação editorial.

### Bloco 8 — Conversa

H2:

**O que precisa mudar no marketing da sua empresa?**

Texto:

Conte o momento do negócio ou escolha um horário para conversar. Vamos entender onde a MATA pode se acoplar e qual trabalho essa estrutura precisaria assumir.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

Link opcional: **Tenho algumas dúvidas →** para FAQ de Como funciona.

## 2. Como funciona — /pt/how-it-works

H1:

**Como uma infraestrutura de marketing se acopla ao seu negócio.**

Introdução:

A MATA reúne pessoas, IA e uma forma de organizar o trabalho a partir da realidade da empresa. O começo é entender o que precisa avançar e combinar as responsabilidades para fazer isso acontecer.

### Entendemos o negócio

Conversamos com a liderança e com as áreas relevantes para entender a oferta, os públicos, a operação e o que o marketing precisa ajudar a resolver. Materiais existentes e situações comerciais fazem parte dessa leitura.

O que o comprador deve compreender: não precisa entregar um plano de marketing pronto; precisa permitir acesso ao contexto necessário.

### Definimos o que a estrutura vai assumir

Combinamos prioridades, capacidade de trabalho, responsabilidades e decisões que precisam voltar à empresa. A composição do time acompanha esse mandato.

Mostrar quadro simples:

| A MATA conduz, dentro do combinado | A empresa continua decidindo |
|---|---|
| Organização e recomendações de marketing | Direção do negócio e investimento |
| Coordenação do trabalho e das competências envolvidas | Compromissos relevantes da oferta |
| Preparação, execução e revisão de materiais | Aprovações reservadas e informações técnicas de sua responsabilidade |
| Acompanhamento do que foi colocado em uso | Mudanças em produto, preço ou operação |

Texto: A divisão é acordada para cada empresa. Proximidade com o comercial não significa assumir toda a área de vendas.

### Conectamos pessoas e IA ao trabalho

O time de pessoas conduz as escolhas e a relação com a empresa. O time de IA apoia atividades delimitadas, usando o contexto disponível e os critérios de revisão. A MATA integra essas capacidades à execução.

Texto de confiança: Você não precisa coordenar agentes ou montar a combinação de ferramentas para o marketing acontecer.

### Transformamos prioridades em execução

Uma mesma direção pode precisar chegar ao site, à apresentação comercial, ao conteúdo ou a uma campanha. O time organiza essa sequência para que as partes trabalhem a favor do mesmo objetivo.

Exemplos de capacidades, sempre subordinados à prioridade:

- Tornar a oferta mais clara: posicionamento, narrativa e materiais comerciais.
- Fazer a marca ganhar consistência: identidade, aplicações e conteúdo.
- Colocar uma mudança no mercado: site, canais e comunicação de lançamentos.
- Aprender com o trabalho: retorno do comercial, uso dos materiais e indicadores acordados.

Nota: os exemplos não constituem pacote universal nem promessa de inclusão ilimitada.

### Acompanhamos e ajustamos

A entrega encontra a realidade: uma dúvida do público, uma mudança no produto, o uso pelo comercial. O acompanhamento ajuda a decidir o que continuar, corrigir ou priorizar em seguida.

### O que você consegue acompanhar

Exibir exemplos de artefatos apenas após validação: registro de prioridades, uma decisão com contexto, um material em uso e uma revisão de aprendizado. Esses objetos explicam o método melhor do que siglas isoladas.

Para apresentar SSOT: “Base de contexto da marca”. Para apresentar ranking: “Prioridades e escolhas de trabalho”. Para shadowing: “Aprendizado com o comercial”. Usar nomes proprietários como detalhe, quando vigentes e comprovados.

### Perguntas frequentes

**A MATA é uma agência?**

A MATA é uma infraestrutura de marketing acoplável. Você conta com um time de pessoas e um time de IA conectados ao negócio, com responsabilidades combinadas para conduzir o trabalho e acompanhar sua execução. Na conversa inicial, detalhamos o que essa estrutura assume no seu caso.

**Preciso ter alguém de marketing para trabalhar com a MATA?**

O modelo foi pensado especialmente para empresas com negócio relevante que ainda não estruturaram essa função. É necessário ter uma liderança que participe das decisões de negócio e facilite o acesso às informações e pessoas importantes para o trabalho.

**Vou precisar aprender a usar ferramentas de IA?**

A equipe MATA opera a tecnologia que sustenta o trabalho. Sua participação está no contexto e nas decisões necessárias para a empresa, não em coordenar o time de IA.

**O marketing passa a funcionar sem minha participação?**

A liderança continua envolvida nas decisões que importam. O objetivo é ter uma estrutura que organiza, recomenda e acompanha o trabalho, com clareza sobre quando sua participação é necessária.

**Já temos um posicionamento. A MATA pode começar daí?**

Sim. A entrada pode ser a implantação da direção existente. O primeiro passo é entender o que foi definido, quais materiais estão em uso e o que precisa mudar para essa direção chegar ao dia a dia.

**Como são definidos o time e o investimento?**

A partir do trabalho que a empresa precisa conduzir e da capacidade necessária para isso. A conversa deve esclarecer dedicação, competências, prioridades e despesas adicionais antes da contratação.

**A estrutura pode mudar ao longo do tempo?**

O modelo é desenhado para acompanhar mudanças nas prioridades da empresa. Alterações de capacidade, composição e condições seguem o que for combinado na contratação.

**O que fica com a empresa?**

Os materiais e registros destinados à marca, os acessos e as condições de continuidade precisam estar claros na contratação. A conversa também distingue esses entregáveis da infraestrutura e dos métodos utilizados pela MATA.

Nota interna: essa resposta evita ampliar uma promessa ainda contraditória nas fontes. Antes da publicação, substituir por redação comercial precisa conforme as condições efetivamente adotadas.

**Vocês trabalham com mídia paga?**

A escolha de canais depende do problema, do público e do momento do negócio. A MATA valoriza construir uma base consistente de marca, conteúdo e ativos; mídia paga pode participar quando fizer sentido para a estratégia e o investimento acordado.

CTA final: **Conte o momento da sua empresa.**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 3. Estruturar marketing — /pt/estruturar-marketing

H1:

**Sua empresa cresceu. O marketing ainda precisa de estrutura.**

Texto:

O negócio já tem produto, clientes e operação. Para o marketing acompanhar, é preciso definir o que ele vai assumir e ter capacidade para conduzir esse trabalho com continuidade.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

### Quando tudo ainda volta para a liderança

Quem explica o negócio para cada profissional? Quem decide o que vem primeiro? Quem percebe que o material já ficou desatualizado? Quando essas respostas são sempre a mesma pessoa, o marketing ocupa uma parte crescente da agenda de quem deveria poder olhar para o negócio.

### O que passa a ter estrutura

**Direção.** Entender o problema que merece prioridade.

**Responsabilidade.** Saber quem conduz, quem executa e onde a empresa decide.

**Capacidade.** Reunir pessoas e IA para o trabalho escolhido.

**Continuidade.** Acompanhar a execução e o que acontece depois.

### Como a MATA entra

A MATA se acopla ao negócio com um time de pessoas e um time de IA. A estrutura reúne competências e organiza o trabalho a partir do que a empresa precisa fazer acontecer, com responsabilidades e prioridades combinadas.

### O primeiro movimento depende do gargalo

Se o comprador não entende o produto, a prioridade pode estar na explicação da oferta. Se a marca conta uma versão antiga da empresa, pode ser necessário rever o posicionamento. Se já existe uma direção clara, o trabalho pode começar pela implantação e pela rotina.

Não colocar um cronograma obrigatório de 30/60/90 dias como promessa de implantação. Pode haver um exemplo de percurso, identificado como ilustrativo, depois de validar o processo comercial.

### Você participa de quê?

A liderança traz objetivos, decisões e acesso ao negócio. A MATA organiza a condução do marketing dentro do mandato acordado. O início serve também para tornar essa divisão explícita.

### Veja uma evolução

Espaço de caso relacionado à construção da função; condicionado a evidência. Sem caso pronto, ligar para a demonstração da home e para Como funciona, sem alegação de resultado.

Leitura: **Como estruturar a área de marketing quando a empresa já cresceu**.

Fechamento: **Seu próximo passo pode ser estruturar quem conduz o marketing.**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 4. Reposicionar a marca — /pt/reposicionamento

H1:

**O negócio avançou. A marca precisa contar essa história.**

Texto:

A empresa pode ter ampliado sua capacidade, mudado o portfólio ou passado a disputar um mercado diferente. A MATA ajuda a traduzir essa evolução em uma direção de marca e em comunicação que faça sentido para quem precisa escolher você.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

### Começamos pelo que mudou

O que a empresa faz hoje? Para quem isso importa? O que o mercado já reconhece e o que ainda não percebe? Essas perguntas ajudam a distinguir uma questão de posicionamento de um ajuste de linguagem ou expressão visual.

### Preservar também é uma decisão

Trajetória, relações e reputação podem dar credibilidade ao próximo movimento. Reposicionar exige entender o que precisa mudar e o que continua sustentando a confiança no negócio.

### Da direção às situações de compra

Uma posição precisa orientar como a empresa apresenta sua oferta, demonstra valor e responde às perguntas do comprador. O trabalho chega à narrativa, à identidade e aos materiais que colocam essa direção diante do mercado, conforme o escopo acordado.

### O que acontece depois da aprovação

A implantação precisa de prioridades, responsáveis e acompanhamento. A infraestrutura acoplável da MATA conecta essa etapa à capacidade de execução, para que a mudança alcance os pontos de contato relevantes.

Nota comercial: a continuidade e sua capacidade são combinadas. Não presumir que todo projeto exige contrato recorrente nem que um contrato de estratégia já inclui todas as aplicações.

### Já existe uma direção aprovada?

Podemos começar pela passagem entre a estratégia e o uso. Entender o que já foi construído é parte do trabalho.

Link: **Conhecer a implantação de posicionamento →**.

Caso: reservar de/para com peças comparáveis e raciocínio, sem mostrar apenas troca de logo.

Fechamento: **Qual parte do seu negócio a marca ainda não consegue mostrar?**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 5. Implantar o posicionamento — /pt/implementar-posicionamento

H1:

**O posicionamento está aprovado. Agora, ele precisa entrar em uso.**

Texto:

A próxima proposta comercial, a página de solução e o conteúdo publicado precisam começar a refletir a nova direção. A MATA organiza e conduz essa passagem com um time de pessoas e um time de IA acoplados ao negócio.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

### Partimos do que já foi construído

Lemos a estratégia existente, entendemos as decisões e observamos os materiais em uso. O objetivo é identificar o que já orienta bem o trabalho e onde ainda falta tradução ou definição.

### Escolhemos onde a mudança precisa aparecer primeiro

Nem tudo tem a mesma urgência. O que influencia uma decisão de compra, sustenta a explicação da oferta ou está em uso recorrente pode exigir prioridade. A sequência de implantação acompanha a realidade da empresa.

### Conectamos os pontos de contato

Site, proposta, apresentação, conteúdo e comunicação de lançamento podem precisar de mudanças diferentes para expressar a mesma direção. A MATA organiza essa execução e as decisões necessárias para manter coerência.

### Acompanhamos a adoção

O comercial está usando o material? O público entendeu a mensagem? Alguma promessa depende de uma decisão que ainda não foi tomada? O retorno da implantação ajuda a ajustar o trabalho.

### Você não precisa recomeçar automaticamente

Um posicionamento bem construído é um ponto de partida. Se encontrarmos uma lacuna que impede a execução, ela será trazida para discussão com contexto. Refazer a estratégia não deve ser uma condição presumida para colocar o que já existe em prática.

Leitura: **O reposicionamento foi aprovado? Sim. E agora?**.

Fechamento: **Qual parte da sua nova marca ainda está no papel?**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 6. Evoluções — /pt/results

Página estruturada para receber evidências; não publicar como biblioteca vazia.

H1:

**A infraestrutura MATA, incorporada a negócios reais.**

Introdução:

Cada negócio pede um trabalho diferente. Aqui, mostramos a situação que encontramos, as responsabilidades que assumimos e o que passou a existir ou funcionar depois.

Para cada caso:

- Nome oficial e setor, se liberados.
- Uma frase sobre a mudança observada.
- Situação anterior → trabalho da MATA → resultado ou capacidade criada.
- Período explícito.
- Evidência representativa e link **Conhecer a evolução**.

Evitar classificações por tipo de peça. Se o conjunto justificar filtros, usar situações: Estruturação, Reposicionamento, Implantação. Não criar filtros para três casos ou menos se só aumentarem a interface.

### Página de caso

H1 descreve a transformação demonstrável. Abrir pelo contexto da empresa, seguir para o que precisava mudar e mostrar como as decisões chegaram à execução. Comparações devem trazer legendas, data e o que está sendo comparado. Texto também explica o de/para para quem não vê as imagens.

Fechar com o que segue em operação e como foi observado. Crédito dos profissionais/parceiros envolvidos quando pertinente. Indicar resultados comerciais como correlação ou contribuição quando não houver atribuição comprovada.

CTA: **Sua empresa vive um momento parecido?** + os dois caminhos de contato.

## 7. Sobre — /pt/story

H1:

**A MATA nasce da necessidade de fazer o marketing acompanhar o negócio.**

Texto:

Há empresas que construíram produtos, relações e operações relevantes antes de ter uma estrutura de marketing. Outras mudaram tanto que a marca ainda conta uma versão anterior do negócio. A MATA está sendo construída para trabalhar dentro dessa realidade.

### Uma infraestrutura acoplável

Reunimos um time de pessoas e um time de IA para conectar contexto, escolhas e execução. A empresa passa a contar com uma estrutura que conduz o trabalho de marketing com proximidade e responsabilidades combinadas.

### Por que MATA

O nome vem da biomimética e da observação de sistemas vivos: partes que se conectam, trocam e se desenvolvem em relação umas com as outras. Essa lógica inspira a forma como pensamos a relação entre marca, pessoas, tecnologia e negócio.

### A construção do modelo

A IA participa do nosso trabalho e da forma como desenvolvemos capacidade. As pessoas conduzem as escolhas, a relação com as empresas e a avaliação daquilo que colocamos em uso. O modelo continua evoluindo a partir dessa experiência.

### Caroline Miranda Martha

**Fundadora da MATA.**

Adicionar fotografia real, biografia validada e link profissional confirmado. Não inventar anos de experiência, formação, prêmios ou histórico. A página não deve depender de números de currículo para explicar o modelo.

### Como pensamos

O negócio é o briefing. A forma faz parte do pensamento. A entrega não é a linha de chegada. Esses princípios orientam a maneira como a MATA procura entender, construir e acompanhar o trabalho.

Links: **Conhecer MATAthinking →** · **Ler o Blog →**.

Fechamento: **Vamos entender o momento da sua empresa.**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 8. MATAthinking — /pt/principles

H1: **Como pensamos o trabalho de marketing.**

Introdução: Os princípios da MATA orientam como entramos no negócio, fazemos escolhas e acompanhamos o que o trabalho produz.

Direção editorial: preservar o sentido dos seis princípios públicos. A versão de sete princípios no Positioning é uma alternativa interna; não fazer uma fusão silenciosa. A proposta abaixo adapta os títulos públicos à linguagem desta experiência.

1. **O negócio é o briefing.** Entender a empresa e o problema que levou a uma demanda faz parte do trabalho.
2. **Proximidade precisa virar entendimento.** Conhecer produto, comercial e contexto ajuda a escolher melhor.
3. **A iniciativa faz parte da responsabilidade.** Observar, trazer uma leitura e propor próximos passos dentro do mandato combinado.
4. **Entender o conjunto. Assumir a própria parte.** Curiosidade ampla com responsabilidade clara.
5. **A forma faz parte do pensamento.** Uma direção precisa chegar ao texto, ao design e à experiência com clareza.
6. **A entrega não é a linha de chegada.** Acompanhar o uso e o efeito ajuda a decidir o trabalho seguinte.

Cada princípio pode receber um exemplo documentado da operação. Enquanto não houver, manter a explicação curta; não fabricar cenas como se fossem ocorrências reais.

## 9. Contato — /pt/contact

H1:

**Conte o que precisa mudar. Ou escolha um horário para conversar.**

Introdução:

Começamos pelo momento da empresa e pelo trabalho que o marketing precisa ajudar a fazer acontecer.

### Caminho 1 — Formulário curto

Título: **Sobre sua empresa**.

Campos:

1. **Seu nome** — obrigatório.
2. **Seu e-mail** — obrigatório, validação de formato.
3. **Empresa ou site** — obrigatório; aceitar texto, não exigir que quem não tem site informe uma URL.
4. **O que melhor descreve o momento?** — obrigatório: “Precisamos estruturar marketing”; “A marca precisa acompanhar o negócio”; “Temos um posicionamento para implantar”; “Quero explicar outra situação”.
5. **O que precisa mudar?** — opcional, texto livre, máximo proposto de 1.000 caracteres.

Botão: **Enviar contexto**.

Microcopy: **Seu contato será usado para responder a esta conversa.** Vincular à política aplicável depois de aprovada; não inventar política ou checkbox de newsletter.

Loading: **Enviando…**.

Sucesso, somente com envio confirmado: **Recebemos seu contexto. Obrigado por contar o momento da sua empresa.**

Erro: **Não conseguimos enviar agora. Seu texto continua aqui para você tentar novamente. Você também pode falar por e-mail.**

Validação: **Informe seu nome.** · **Confira o endereço de e-mail.** · **Informe a empresa ou o site.** · **Escolha a situação que melhor descreve seu momento.**

### Caminho 2 — Agenda

Título: **Prefere conversar direto?**

Texto: **Escolha um horário disponível na agenda.**

Botão: **Agendar uma conversa**.

Usar a agenda confirmada: https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C . Abrir diretamente, sem exigir formulário. Conferir acesso público; não inventar duração, disponibilidade ou integração.

### Canais diretos

E-mail: **hello@wearemata.company** — endereço observado no site atual.

WhatsApp: preservar o destino atual observado, sujeito a conferência de recebimento. Texto inicial sugerido: **Oi, vim pelo site da MATA e quero conversar sobre o marketing da minha empresa.**

LinkedIn: [MATA](https://www.linkedin.com/company/wearemata).

## 10. Blog — entrada e contrato de conteúdo

H1: **Marketing na realidade de quem conduz um negócio.**

Texto: Leituras sobre estrutura, marca e o trabalho de pessoas e IA. Para entender o que precisa mudar e como fazer essa mudança acontecer.

Trilhas: **Estruturar marketing · Marca em movimento · Pessoas + IA**.

Começar pelos três artigos existentes, com as autorias corretas. A página só deve mostrar conteúdo que de fato possa ser aberto. A recomendação atual é /blog ou /pt/blog, com endereço final a confirmar; subdomínio é alternativa explicada no arquivo 07. Configurar o endereço em um único lugar, aplicado ao menu, às chamadas editoriais e aos links de retorno.

## 11. Metadados propostos

Os títulos e descrições abaixo são propostas; validar comprimento visual nos resultados e no compartilhamento. Não há contagem de caracteres que garanta exibição integral.

| Página | Título | Descrição |
|---|---|---|
| Home | MATA — Infraestrutura de Marketing Acoplável | Um time de pessoas e um time de IA para empresas que cresceram sem estruturar marketing e marcas que precisam acompanhar o negócio. |
| Como funciona | Como funciona a infraestrutura acoplável da MATA | Entenda como pessoas, IA e responsabilidades combinadas conectam o contexto da empresa à estratégia e à execução de marketing. |
| Estruturar | Sua empresa cresceu sem marketing? Conheça a MATA | Estruture a condução do marketing com pessoas e IA conectadas à realidade do negócio, das prioridades ao acompanhamento da execução. |
| Reposicionamento | Reposicionamento de marca para empresas em evolução — MATA | Traduza a evolução do negócio em posicionamento, narrativa e comunicação, com um caminho para fazer a nova direção entrar em uso. |
| Implantação | Como colocar seu posicionamento em prática — MATA | Conecte a direção aprovada ao site, aos materiais comerciais e ao conteúdo com uma estrutura que organiza e conduz a implantação. |
| Sobre | Sobre a MATA — Pessoas, IA e marketing acoplável | Conheça a visão que orienta a MATA e a construção de uma infraestrutura de marketing conectada à realidade das empresas. |
| Contato | Converse sobre sua empresa — MATA | Conte o momento do negócio em um formulário curto ou agende uma conversa para entender onde a MATA pode se acoplar. |

## 12. Inglês e migração editorial

Caroline confirmou: primeiro afinar o site e o Blog em português; só depois traduzir para inglês. A publicação dos artigos será manual nesta fase. A versão /en existente deve ser inventariada e preservada sem alterações incidentais até uma decisão de lançamento coerente; não traduzir nem criar novas páginas EN nesta etapa. Não misturar blocos novos em português com conteúdo antigo em inglês. Não anunciar versão equivalente em inglês de um artigo que só existe em português.

Vocabulário proposto: **Pluggable Brand Marketing Infrastructure**, **A human team and an AI team**, **Book a conversation**. A assinatura **Brand marketing, built in.** pode permanecer em contextos expressivos.

No lançamento de cada idioma, manter a equivalência entre oferta, condições, casos e contato. Marcação de idiomas e links alternativos devem apontar para páginas realmente existentes. Caso uma nova página ainda não tenha versão em inglês, comunicar a disponibilidade de idioma de modo claro, sem fingir tradução concluída.


---

Documento: 04-CONHECIMENTO-DO-PROJETO.txt

PROJETO: WEBSITE MATA — WEAREMATA.CO

Atualizar o projeto existente de wearemata.co. A fonte de decisão é o pedido de Caroline Miranda Martha e o pacote atual de briefing. Não criar uma empresa ou um SaaS diferente para satisfazer uma aparência tecnológica.

MARCA E CATEGORIA
Escrever MATA em caixa alta. Categoria principal proposta: Infraestrutura de Marketing Acoplável. A alternativa Infraestrutura de Brand Marketing Acoplável pode aprofundar a definição, mas a primeira é a referência principal em português. Em inglês: Pluggable Brand Marketing Infrastructure. Acoplamento é uma lógica central de operação e de expressão visual.

A MATA reúne um time de pessoas e um time de IA conectados ao negócio para conduzir marketing, da leitura de contexto e escolha de prioridades à execução acompanhada. O comprador contrata essa capacidade. A equipe MATA opera a tecnologia. Mostrar responsabilidade humana, não autonomia ilimitada nem uma ferramenta de autoatendimento.

OBJETIVO
Atrair conversas com empresas aderentes ao modelo. Público prioritário: empresas com negócio relevante, produto/serviço validado e sem estrutura de marketing. Segunda família: empresas cuja marca ficou atrás do negócio e empresas com posicionamento aprovado que precisam implantá-lo. Não presumir que todo cliente quer refazer a marca. Não inventar corte de faturamento ou recorte exclusivo B2B.

PERCEPÇÃO
A MATA deve ser percebida como martech e infraestrutura acoplável. Demonstrar pessoas, IA, contexto, decisões e trabalho em uso. Evitar organizar a home como portfólio de serviços ou como ataque a agências. Não criar dashboards, agentes, resultados, logos ou produtos proprietários fictícios para parecer tecnologia.

CONTEÚDO
O visitante vem primeiro: qual situação resolve, o que se contrata, como se acopla, o que a MATA assume, quem responde, o que continua com a empresa e por que confiar. Promessa central: continuidade de condução e espaço mental para a liderança. A execução e o acabamento continuam essenciais.

NAVEGAÇÃO
Como funciona; Para sua empresa (Estruturar marketing, Reposicionar a marca, Implantar o posicionamento); Evoluções quando houver caso validado; Sobre; Blog. Logo retorna à home. MATAthinking identifica princípios, não substitui Blog no menu. Preservar rotas existentes quando possível; redirecionar individualmente quando mudarem.

CONTATO CONFIRMADO
Dois caminhos independentes: Conversar sobre minha empresa → formulário curto; Agendar uma conversa → agenda real. Ninguém precisa preencher o formulário para agendar. Agenda confirmada: https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C . Formulário: nome, e-mail, empresa/site, situação principal e mensagem opcional. Reutilizar destino válido e testar recebimento. Manter e-mail e WhatsApp como alternativas reais. E-mail atual observado: hello@wearemata.company; não mudar o domínio por suposição.

DESIGN
O gradiente oficial é central e obrigatório: reconhecível no hero, no acoplamento e em momentos de continuidade. Usar assets/gradientes/MATA-gradiente-oficial.png, sem substituir por gradiente genérico. Interfaces claras devem proteger leitura sem apagar essa assinatura.
Usar MATA Design System oficial. Tecnologia orgânica, base clara e neutralidade com expressão material. Canvas #F1F2F4, superfície #FFFFFF, texto principal #171C1B, prata #D8DDE1, gelo #DEE5EB, menta pálida #B0E6D8 e #00F0A9 com parcimônia. Stack Sans dos arquivos oficiais; fallback Helvetica Neue/Arial. Logos oficiais sem redesenho. Não usar a imagem de referência como arquivo oficial do logo.

As duas referências fornecidas por Caroline mostram estruturas modulares conectadas por vidro e um módulo MATA acoplado ao negócio. Essa é a direção expressiva prioritária. Dar função aos encaixes e às conexões. Evitar blobs decorativos, roxo/azul genérico de IA, robôs, cérebro luminoso e florestas literais. Manter a maior parte da interface clara. Não transformar o verde profundo do objeto em fundo padrão de todas as páginas.

INTERAÇÃO
Um momento memorável de acoplamento; os demais movimentos servem clareza e feedback. Texto real em HTML, sem informação essencial apenas em imagem, vídeo, hover ou canvas. Modo de movimento reduzido explica a mesma coisa. Mobile tem composição própria, texto e ação cedo, sem reduzir um diagrama desktop inteiro.

PROVAS E SELO
Grafias confirmadas: Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF. A MATA quer ser uma assinatura de infraestrutura incorporada. Proposta: MATA built in., descritor Infraestrutura de Brand Marketing. Seção: A infraestrutura MATA, incorporada a negócios reais. Distinguir operação atual e ciclo histórico com período; não atribuir selo integral a projeto pontual. Nome do selo é recomendação, não ativo oficial aprovado. Não usar “Marcas com as quais construímos” como conceito central. Ver arquivo 07.
Cases mostram contexto, situação anterior, responsabilidade da MATA, decisões, execução, resultado e evidências. Logos/cases deliberadamente pendentes de seleção. Preparar componentes em rascunho; esconder se vazios. Não mapear casos anônimos a marcas por suposição. Conferir nomes/grafias e relação atual/concluída. O site atual traz uma contagem de imprensa anunciada como 35, com detalhamento que soma 31: não republicar sem conciliação. ARR e prazos também pedem validação.

LIMITES DE ALEGAÇÃO
Não publicar preços, mínimos, aviso prévio, SLAs, duração de onboarding ou garantias sem fonte vigente. Não converter metas de piloto e propostas da tese de Produtos internos + IA em capacidades já disponíveis. Não afirmar que a IA foi treinada exclusivamente ou que toda tecnologia é proprietária. Não prometer transferência de toda a infraestrutura MATA ao cliente; distinguir materiais/registros da marca e métodos/produtos internos conforme contrato.

BLOG
Fase confirmada: novo site e Blog em português, publicação manual por enquanto. Só traduzir para inglês depois de PT estar afinado. Preparar estrutura de idioma e relação entre traduções, sem criar páginas EN vazias. Recomendação prática: /pt/blog agora, /en/blog quando houver traduções reais. Automação futura depende do sistema de publicação, não exige subdomínio por si só.
Blog explícito no menu. Endereço em avaliação: recomendação /blog ou /pt/blog; blog.wearemata.co é alternativa se houver vantagem editorial. Não migrar por suposição. Endereço em configuração única. Sem iframe da publicação, duplicação desnecessária ou links inventados. Começar com três artigos fornecidos. Autoria: Como estruturar a área de marketing quando a empresa já cresceu = Time da MATA; Produzir marketing não é conduzir marketing e O reposicionamento foi aprovado? Sim. E agora? = Caroline Miranda Martha. Preservar textos e revisar links/formatação na publicação. Não inventar datas ou posts.

IMPLEMENTAÇÃO E VERIFICAÇÃO
Inspecionar stack e integrações reais antes de escolher ferramentas. Não reescrever a aplicação por hábito. Verificar rotas diretas, refresh, metadados por rota, idioma, canonical, sitemap, robots, links, 404 e formulário real. Não presumir que todos os requisitos de SEO já existem. Sem garantia de ranking ou citação em IA.

Testar desktop e 320/375/414/768 px; teclado, foco, menu, formulários, estados de envio, erro e sucesso, toque, contraste, leitura e movimento reduzido. Nenhum botão sem destino real. Uma mensagem de sucesso depende de confirmação de envio. Não enviar dados pessoais de formulário para eventos de analytics. Não publicar arquivos internos de briefing em public/.

Entregar prévia navegável e registro do que foi verificado e do que continua pendente. A beleza da composição e o sucesso do build não substituem a conferência do site real.


---

Documento: 05-IMPLEMENTACAO-E-QA.md

# Implementação e critérios de aceite — MATA

Este documento orienta a atualização do projeto existente no Lovable. É uma especificação proposta, não um relatório de testes da futura implementação. A auditoria do site atual está no arquivo 02. A copy está no arquivo 03.

## 1. Antes de alterar o projeto

Inventariar rotas PT/EN, componentes, formulários, integrações, domínio, analytics, metadados e forma atual de publicação. Registrar a versão inicial para permitir comparação e recuperação. Aproveitar componentes adequados ao sistema visual. Não escolher uma nova stack sem necessidade identificada.

Não presumir renderização, indexabilidade ou integrações pelo nome Lovable. A documentação distingue arquiteturas conforme a geração do projeto. Inspecionar o projeto real antes de decidir como resolver cada requisito. [Documentação Lovable de SEO e AEO](https://docs.lovable.dev/features/seo-aeo).

Construir em prévia. Briefing, referências internas, notas de casos e documentos de pesquisa não são arquivos públicos do site. Apenas assets destinados à publicação entram na pasta pública.

## 2. Configurações e destinos reais

| Configuração | Valor / regra |
|---|---|
| Domínio institucional | https://wearemata.co |
| Contato por e-mail | hello@wearemata.company — observado no site atual |
| Agenda confirmada por Caroline | https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C |
| WhatsApp observado | https://wa.me/5516996071579?text=Oi%2C%20vim%20pelo%20site%20da%20MATA%20e%20quero%20falar%20com%20voc%C3%AAs. |
| LinkedIn observado | https://www.linkedin.com/company/wearemata |
| Destino do formulário | Inspecionar integração existente e validar recebimento; ainda não verificado nesta pesquisa |
| Endereço definitivo do Blog | Recomendação: /blog ou /pt/blog; alternativa blog.wearemata.co; decisão final em avaliação |
| Cases publicados | Apenas registros com evidência e conteúdo pronto; não preencher lacunas automaticamente |

O link da agenda é fornecido pela usuária. Nesta pesquisa, a ferramenta de leitura web não conseguiu inspecionar sua página. Isso não demonstra falha do endereço. A revisão da implementação deve verificar sua abertura e disponibilidade pública, sem criar uma reserva de teste sem autorização.

Usar uma configuração central para a agenda e para o Blog, evitando URLs repetidas em componentes. Não depender de variáveis secretas para um endereço público. Credenciais do destino do formulário ficam em configuração protegida no servidor.

## 3. Navegação e migração

Manter os endereços existentes onde a função é equivalente. Mapa proposto:

| Origem observada | Destino / decisão |
|---|---|
| /pt | Home nova, mesma rota |
| /pt/how-it-works | Como funciona, mesma rota |
| /pt/results | Evoluções; preservar a rota e preparar conteúdo validado |
| /pt/story | Sobre a MATA, mesma rota |
| /pt/principles | Princípios, mesma rota, acessível por Sobre e rodapé |
| /pt/contact | Contato com formulário e agenda, mesma rota |
| Novas páginas de situação | Criar URLs estáveis conforme arquivo 02; não gerar variações concorrentes |
| /en e demais rotas inglesas | Inventariar e preservar até adaptação integral; não misturar copy PT em páginas EN |
| Raiz / | Propor PT como entrada da nova versão; conferir o comportamento existente, que levou a /en nesta pesquisa. Não iniciar o novo fluxo em inglês desatualizado |

Se houver mudança de URL, registrar correspondência individual e usar redirecionamento permanente para o equivalente. Evitar redirecionar tudo para a home. Testar links antigos, navegação direta e atualização do navegador. [Orientação Google para mudanças de URL](https://developers.google.com/search/docs/crawling-indexing/site-move-with-url-changes).

Menu desktop: Como funciona; Para sua empresa; Evoluções quando houver conteúdo validado; Sobre; Blog; ação de contato. O acesso à agenda aparece na primeira dobra e na página de contato. Não comprimir sete itens mais dois botões no cabeçalho mobile. Menu mobile deve oferecer os dois caminhos de contato com rótulos completos e claros.

Não ocultar a situação prioritária em um seletor que o visitante precisa descobrir. As três entradas permanecem compreensíveis na home. Páginas de entrada funcionam diretamente, inclusive quando acessadas por pesquisa ou artigo.

## 4. Componentes e estados

| Componente | Conteúdo / comportamento | Estado sem material definitivo |
|---|---|---|
| Hero | Categoria, problema de negócio, pessoas + IA, dois contatos, acoplamento | Usar referências existentes com texto separado em HTML |
| Diagrama do acoplamento | Negócio/contexto → capacidade MATA → decisões e trabalho em uso → retorno de contexto | Representação conceitual identificada; nunca dashboard de produto inexistente |
| Entradas por situação | Estruturar marketing, reposicionar, implantar | Todas as páginas com copy própria; sem números inventados |
| Funcionamento | Responsabilidades, relação com cliente, pessoas e IA | Não exige imagem de ferramenta interna |
| Evolução | Antes, intervenção, depois, evidência e contexto | Rascunho oculto se não validado; não exibir card vazio |
| Artigo | Título, autoria, resumo, destino, data apenas real | Publicar texto revisado ou manter rascunho; sem artigo fictício |
| Contato | Formulário e agenda independentes | Agenda já definida; destino do formulário precisa de verificação |
| Fundadora | Nome e papel reais, foto se fornecida | Bloco editorial sem retrato fictício; biografia a conferir |

Acoplamento deve comunicar conexão e continuidade. Não apresentar um catálogo de módulos com preço ou contratação separada se essa não for a oferta validada. A interação é explicativa, não um configurador comercial.

## 5. Direção visual aplicada

O gradiente oficial MATA é central, conforme prioridade expressa de Caroline. Usar assets/gradientes/MATA-gradiente-oficial.png e verificar sua presença reconhecível no hero desktop e mobile. Incorporar o selo proposto MATA built in. no bloco de evidência, distinguindo relações atuais e históricas. O arquivo 07 detalha aplicações, campos e critérios; não gerar selo de certificação.

Usar as imagens fornecidas como referência de material, conexão, luz e composição. Aplicar logos oficiais dos arquivos SVG. Não extrair ou redesenhar o logotipo a partir da capa. As fontes oficiais estão no pacote com o aviso de licença disponível.

Prioridades: tipografia legível, hierarquia editorial, espaço proporcional e contraste. Prata, gelo, menta e vidro aparecem como materiais do sistema, não como efeito em cada botão. Uma cena de acoplamento expressiva na home é suficiente para estabelecer a linguagem; outras páginas usam derivações contidas.

Texto nunca incorporado à imagem como único meio de leitura. Os dois arquivos de referência têm proporções de capa; criar composição apropriada para mobile, preservando o conceito em vez de recortar cegamente o centro. Não encomendar novos assets antes de testar a composição com o material existente.

Carregar apenas fontes/pesos necessários, definir dimensões de imagens e disponibilizar formatos adequados ao navegador. Priorizar imagem principal; adiar imagens abaixo da dobra. Não usar vídeo ou WebGL como requisito para compreender a oferta. Se houver animação, ela deve degradar para uma cena estática igualmente clara.

## 6. Formulário e agenda

Formulário curto: nome, e-mail, empresa/site, situação principal e mensagem opcional. Quatro campos obrigatórios; mensagem até 1.000 caracteres. Campo empresa/site aceita o nome de uma empresa sem exigir URL. Permitir “Outro momento” na situação. Manter rótulos visíveis, não apenas placeholders.

Estados: inicial; preenchimento; erro por campo; enviando; sucesso confirmado; falha de envio com recuperação. Preservar os dados quando ocorrer falha. Evitar duplo envio enquanto a primeira solicitação está em andamento. Não usar um temporizador para simular sucesso. Não prometer prazo de resposta não confirmado.

Validar no servidor e aplicar proteção contra abuso compatível com a experiência. Enviar apenas informações necessárias ao destino aprovado. Não acrescentar inscrição de newsletter ao envio de contato. Se for adotada uma inscrição, torná-la separada e opcional. Revisar aviso de privacidade de acordo com o fluxo real de dados, sem inventar políticas.

“Agendar uma conversa” abre diretamente a URL confirmada. Recomenda-se link simples, sem incorporar um calendário pesado na home. Se abrir nova aba, indicar isso de forma acessível. Não exigir envio de formulário, login no site MATA ou etapa de qualificação para acessar horários.

Verificar abertura da agenda em janela sem sessão autenticada; conferir que se trata da agenda certa. Não inferir duração, nome do anfitrião ou disponibilidade sem leitura da própria agenda. Registrar clique não equivale a reunião agendada.

## 7. Blog: subdiretório recomendado e alternativa de subdomínio

Caroline confirmou português primeiro, publicação manual e tradução apenas depois de a versão PT estar afinada. Não construir agente de autopublicação nesta fase. Modelo mínimo dos artigos: identificador estável, título, slug, idioma, autoria, resumo, corpo, imagem e texto alternativo, rascunho/publicado, datas reais e referência à tradução quando existir. Esse modelo prepara integrações futuras sem contratar ou implementar uma plataforma extra agora.

Recomendação prática: /pt/blog e /pt/blog/slug; /en/blog e /en/blog/slug apenas quando houver conteúdo revisado em inglês. Um artigo PT sem tradução não recebe link alternativo EN fictício. Não exigir tradução para publicar ou melhorar PT.

Preparar um campo único para o endereço da publicação. Menu usa o rótulo “Blog”. A identidade deve manter reconhecimento da MATA, com uma superfície editorial adequada à leitura longa. Link de volta ao institucional no domínio editorial.

Para a opção recomendada: usar um índice real em /pt/blog e, se os artigos estiverem revisados, páginas locais completas. Se ainda não houver publicação pronta, o índice pode explicar brevemente a linha editorial e direcionar ao contato, sem cards clicáveis falsos ou promessas de data. Não apresentar arquivos de trabalho como artigos publicados.

Se for escolhido um subdomínio: escolher um endereço principal para cada artigo; atualizar cards e links; se um artigo local migrar, redirecionar sua URL ao equivalente. Não manter dois conteúdos integrais concorrentes sem plano de canonicalização. Canonical é um sinal, não uma garantia de escolha pelo buscador. [Google sobre consolidação de URLs](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls).

Metadados do artigo: título, descrição, autoria correta, data real, imagem com descrição quando informativa, URL principal e artigos relacionados relevantes. Não atribuir ao Time da MATA textos assinados por Caroline, nem o inverso. Não alterar o corpo dos três artigos por iniciativa de implementação; revisar links e formatação com os documentos originais.

## 8. Busca e mensuração

Cada página precisa de título e descrição específicos, um H1 descritivo, hierarquia de headings coerente, idioma correto, links rastreáveis, canonical consistente, imagem social e resposta adequada a erro/rota inexistente. Sitemap contém páginas públicas canônicas. Não indexar rascunhos de cases, páginas de prévia e conteúdo incompleto. Implementar hreflang apenas entre versões equivalentes efetivamente publicadas.

Dados estruturados devem representar o que é visível e verdadeiro: organização, artigos e navegação quando pertinente. Não inventar avaliações, preços ou software proprietário para preencher schema. Indexação e elegibilidade são necessárias; nenhuma implementação garante ranking ou menção em respostas de IA. O Google não exige schema especial ou arquivo exclusivo para suas funcionalidades de IA. [Google: funcionalidades de IA e seu website](https://developers.google.com/search/docs/appearance/ai-features).

Eventos propostos, respeitando a ferramenta e as escolhas de privacidade do projeto:

| Evento | Quando acontece | O que permite entender |
|---|---|---|
| contact_form_view | Formulário visualizado | Acesso ao caminho de contato |
| contact_form_start | Primeira interação significativa | Intenção de preencher |
| contact_form_submit_success | Destino confirma envio | Solicitação enviada |
| contact_form_submit_error | Envio falha | Fricção operacional |
| booking_click | Clique no link da agenda | Interesse em agendar, não reserva concluída |
| situation_click | Acesso a uma situação | Temas que geram interesse |
| case_view | Leitura de case publicado | Uso de evidência |
| blog_click | Acesso à publicação | Interesse editorial |

Parâmetros úteis: página, posição do CTA, situação escolhida por categoria e idioma. Não enviar nome, e-mail, mensagem ou conteúdo livre da empresa para analytics. Não inflar conversões contando clique, formulário e agendamento como três clientes diferentes. Se não houver integração confiável com o calendário, medir reuniões realizadas no processo comercial e manter essa limitação explícita.

## 9. Critérios de qualidade da prévia

### Compreensão e conteúdo

- Em uma primeira leitura, o visitante identifica a situação atendida e o que contrata.
- O gradiente oficial é reconhecível e a composição comunica infraestrutura incorporada.
- O selo proposto mantém logo oficial, contribuição e status verdadeiros.
- A MATA aparece como estrutura operada por pessoas e IA; nenhuma tela sugere compra de um aplicativo de autoatendimento inexistente.
- A prioridade de empresas sem marketing está visível. Reposicionamento e implantação têm caminhos distintos.
- “Acoplável” é explicado por relação, responsabilidades e visual; não depende de repetir a palavra.
- A IA tem papel concreto, responsabilidade humana e limites de alegação.
- Não há métricas, depoimentos, nomes de clientes ou escopos criados para preencher layout.
- Todas as notas editoriais e variáveis de rascunho estão fora da interface pública.

### Responsividade e acessibilidade

- Conferir 320, 375, 414, 768, 1024 e 1440 px, além de ampliação de texto e zoom.
- Nenhum transbordamento horizontal ou sobreposição de CTA, menu e texto essencial.
- Menu abre e fecha por teclado; foco é visível e retorna corretamente; Escape fecha quando aplicável.
- Inputs têm rótulos, mensagens compreensíveis e erros associados ao campo; sucesso pode ser percebido por tecnologia assistiva.
- Informação não depende apenas de cor, hover, movimento ou imagem.
- Contraste de texto comum ao menos 4,5:1; texto grande 3:1; verificar também componentes e foco conforme WCAG.
- Respeitar preferência de movimento reduzido. Animações não bloqueiam leitura ou navegação.
- Conferir ordem de leitura, headings, nomes acessíveis, alt descritivo e imagens decorativas sem ruído.

Usar [WCAG 2.2](https://www.w3.org/WAI/WCAG22/quickref/) como referência de verificação; um checklist parcial não certifica conformidade integral.

### Desempenho, integração e busca

- Rotas abrem diretamente e sobrevivem a refresh; links antigos têm destino equivalente.
- Formulário tem envio e recebimento efetivamente testados em destino controlado, com registro do resultado.
- Agenda abre publicamente no destino fornecido; nenhum teste cria reunião sem autorização.
- Blog e idioma funcionam sem links vazios, loops ou mistura de páginas.
- Metadados e conteúdo podem ser lidos no HTML/renderização adequada da rota real.
- Conferir console, rede, fontes e assets ausentes; revisar em navegador mobile real quando disponível.
- Medir desempenho da prévia e depois em produção. Como referência de experiência real: LCP até 2,5 s, INP até 200 ms e CLS até 0,1 no percentil 75. Medidas de laboratório não substituem dados de campo. [Core Web Vitals](https://web.dev/articles/vitals).

## 10. Entrega esperada do Lovable

Prévia navegável com copy real e links funcionais; relação de páginas alteradas; evidência visual desktop/mobile; registro de testes executados; pendências claramente separadas de falhas. Apresentar quais resultados são observados e quais são apenas metas.

Antes da publicação, conferir formulário, páginas públicas, identidade e condições comerciais efetivamente utilizadas. Cases podem continuar em rascunho sem bloquear o restante do site. Não chamar de pronto um formulário que apenas mostra uma mensagem de sucesso local.


---

Documento: 06-COLETA-DE-CASES-E-PENDENCIAS.md

# Evoluções, de/para e informações a completar

Instrumento de coleta para Caroline. Não é copy pública. Não preencher lacunas por inferência. A escolha de logos e dos casos ficou deliberadamente para uma etapa posterior; a implementação pode preparar os componentes agora.

## 1. Escolher os primeiros casos

Priorizar um caso que mostre estruturação de marketing, um de reposicionamento conectado ao negócio e um de implantação de posicionamento. Não é obrigatório encontrar um caso diferente para cada categoria: um caso forte e verificável vale mais do que três exemplos frágeis.

Critérios: proximidade com o comprador prioritário, clareza do problema, participação real da MATA, mudança demonstrável e materiais disponíveis. Uma imagem bonita ajuda a leitura, mas não prova sozinha que a operação mudou.

## 2. Ficha para cada marca

| Pergunta | Resposta a preencher |
|---|---|
| Nome público exato da marca e eventual grupo | |
| Website da marca | |
| Relação atual ou projeto concluído? Período? | |
| Momento do negócio quando a MATA entrou | |
| O que já funcionava e deveria ser preservado? | |
| Qual problema a liderança enfrentava? | |
| O que a MATA assumiu? | |
| Quem mais participou e com qual responsabilidade? | |
| Qual decisão mudou o rumo do trabalho? | |
| Que materiais, canais ou rotinas foram implantados? | |
| O que passou a funcionar de maneira diferente? | |
| Como sabemos? Fonte, data, métrica ou observação verificável | |
| Limite de atribuição: o que não decorre apenas da MATA? | |
| O que pode aparecer publicamente? Nome, logo, imagens, números, depoimento | |
| Pessoa responsável por validar os fatos | |
| Arquivos de antes e depois disponíveis | |

Não é necessário divulgar dados sensíveis para fazer um caso útil. Se números não puderem aparecer, descrever mudanças concretas e apresentar evidência permitida. Caso anônimo precisa ser verdadeiro e suficientemente contextualizado, sem criar uma identificação indireta indesejada.

## 3. De/para que demonstra negócio

| Dimensão | Antes | Decisão/intervenção da MATA | Depois | Evidência possível |
|---|---|---|---|---|
| Clareza da oferta | Como a oferta era explicada? | Qual narrativa/prioridade foi revista? | O que passou a ser entendido? | Páginas e materiais datados; retorno documentado |
| Marca e negócio | O que ficou para trás? | O que foi preservado e atualizado? | Onde a nova leitura aparece? | Identidade aplicada, apresentação, website |
| Condução | Quem precisava coordenar tudo? | Qual responsabilidade foi assumida? | Como decisões e execução passaram a ocorrer? | Plano, cadência e responsáveis, com dados internos omitidos |
| Implantação | O que estava aprovado mas sem uso? | Quais pontos de contato foram priorizados? | O que entrou em operação? | Propostas, site, conteúdos, materiais comerciais |
| Continuidade | Onde o trabalho se interrompia? | Que rotina foi estabelecida? | O que passou a ser acompanhado? | Sequência de entregas e decisões verificáveis |
| Efeito observado | Qual situação inicial? | Qual contribuição específica? | Qual sinal ou resultado ocorreu, em que período? | Relatório com definição e fonte |

Se usar comparação visual, mostrar peças equivalentes e contexto: mesma função, período e objetivo. Um slider pode ser complemento; não deve esconder explicação, ser a única forma de comparação ou prejudicar uso por teclado. Em mobile, imagens empilhadas com legendas costumam preservar melhor a leitura.

## 4. Marcas confirmadas por Caroline

**Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF.**

As grafias estão confirmadas. Para cada marca, completar período, relação atual/histórica, escopo, evidências e arquivos oficiais. A seleção de logos segue para etapa posterior, como solicitado.

Caroline quer que a presença da MATA seja uma assinatura de infraestrutura incorporada. A proposta **MATA built in.** e suas versões atual/histórica estão no arquivo 07. A seção passa a ser **A infraestrutura MATA, incorporada a negócios reais.** Não usar uma faixa genérica de clientes como conceito principal. Um projeto pontual não recebe automaticamente selo de infraestrutura completa.

Adicionar à ficha de coleta: esta relação correspondeu a infraestrutura acoplada? Em qual escopo e período? O que o selo pode afirmar com precisão? Ter trabalhado com uma marca não permite atribuir todo o seu desempenho à MATA.

## 5. Alegações observadas no site atual

São pontos de partida para apuração, não resultados revalidados nesta pesquisa. Não associar os casos anônimos abaixo às marcas acima por semelhança.

| Caso descrito publicamente | Alegação observada | Conferir antes de reutilizar |
|---|---|---|
| Software de saúde com cerca de 25 anos | Relançamento em 3 meses em comparação com plano de 12 meses | Datas, escopo, origem do plano, o que entrou em produção e contribuição de outros envolvidos |
| Fintech | 35 inserções; detalhamento de 6 tier 1 + 24 tier 2 + 1 TV | O detalhamento soma 31. Conciliar as quatro ocorrências restantes e definir inserção, veículo, período e duplicações |
| Incorporadora de alto padrão | Aquisição em aproximadamente um mês | O que significa aquisição nesse contexto, sequência temporal e limite de atribuição |
| Holding com três marcas | Aproximadamente US$ 80 milhões de ARR | Definição, moeda, período, fonte e relação com atuação MATA; porte do cliente não equivale a receita gerada pela MATA |
| Produto D2C de proteína | 100 mil visualizações em duas semanas, sem mídia paga | Plataforma, publicação, período, agregação, definição de visualização e o que se sabe além do alcance |

## 6. Modelo de texto após a coleta

**Título:** uma mudança concreta, em linguagem simples.

**Contexto:** o que a empresa fazia e qual era seu momento.

**Antes:** problema específico e consequência para negócio ou liderança.

**O que assumimos:** responsabilidade da MATA e colaboração com cliente/parceiros.

**Decisões e implantação:** duas ou três escolhas relevantes e como entraram em uso.

**Depois:** mudança observável, período e evidência. Se for resultado parcial, dizer isso.

**O que esse caso ajuda a entender:** conexão com estruturação, reposicionamento ou implantação, sem transformar um resultado particular em promessa universal.

**Contato:** “Sua empresa vive um momento parecido?” com formulário e agenda independentes.

## 7. Outras informações a completar

| Item | Situação | Como avançar |
|---|---|---|
| Categoria principal | Recomendação: Infraestrutura de Marketing Acoplável | Testar compreensão na prévia; alternativa Brand Marketing explicada no dossiê |
| Dois caminhos de contato | Confirmados | Implementar formulário curto e agenda independentes |
| URL da agenda | Fornecida por Caroline | Usar a URL do arquivo 05 e conferir abertura pública |
| Destino do formulário | Ainda não verificado | Reutilizar integração válida ou definir destino; testar recebimento |
| Endereço do Blog | Em avaliação; recomendação /blog ou /pt/blog | Conferir plataforma de edição e fechar endereço antes da publicação |
| Cases e logos | Seleção adiada pela usuária | Preparar em rascunho e preencher com esta ficha |
| Termos de operação e comerciais | Há divergências nos documentos históricos | Conferir documento vigente; omitir números e condições específicas até então |
| Foto e bio da fundadora | Complementar | Usar nome Caroline Miranda Martha; conferir texto e imagem antes de publicar |
| Versão em inglês | Caroline adiou até o site PT estar afinado | Primeiro site e Blog em PT, publicação manual; inglês depois |

Nenhuma dessas pendências exige refazer a pesquisa ou a arquitetura. Elas completam componentes e condições que já estão definidos no briefing.


---

Documento: 07-GRADIENTE-SELO-E-BLOG.md

# Direção final de identidade, selo e Blog

Este complemento incorpora as últimas orientações de Caroline. Deve ser lido junto com os arquivos 02, 03 e 05. As recomendações de nome do selo e endereço do Blog são propostas para revisão; a prioridade do gradiente, a percepção de martech e as grafias das marcas foram confirmadas pela usuária.

## 1. O gradiente é uma assinatura central

O gradiente oficial da MATA precisa ser reconhecível já na primeira dobra. Não basta incluir um logotipo em gradiente e deixar o restante com aparência genérica. Ele participa da atmosfera do hero, da luz dos módulos e de momentos de conexão ao longo do site.

Arquivo mestre fornecido no pacote: **assets/gradientes/MATA-gradiente-oficial.png**, copiado da referência oficial do MATA Design System. A imagem tem transições amplas entre menta, prata, gelo e lilás acinzentado. A leitura é luminosa e material, sem faixas duras de arco-íris. As duas capas fornecidas por Caroline complementam essa referência com a lógica de acoplamento.

Token oficial de apoio, para aplicações em que CSS seja apropriado:

```css
--mata-holo: linear-gradient(120deg,
  #AEB3C7 0%, #D8DDE1 22%, #F1F2F4 43%,
  #B0E6D8 62%, #00F0A9 78%, #DEE5EB 100%);
```

O token não substitui a comparação visual com a imagem mestre: um gradiente linear aplicado mecanicamente pode produzir faixas diferentes da atmosfera do arquivo. Usar a imagem oficial diretamente ou reproduzir suas relações de cor e difusão, verificando o resultado.

| Área | Aplicação pretendida |
|---|---|
| Hero | Campo atmosférico reconhecível, com área de contraste para a mensagem e módulos acoplados |
| Funcionamento | Reflexos do gradiente nas conexões, ajudando a acompanhar o contexto e a passagem ao trabalho |
| Selo MATA | Superfície ou faixa holográfica na versão expressiva; versão funcional de alto contraste |
| Fechamento de contato | Retomada do gradiente para encerrar a experiência com identidade |
| Páginas internas | Abertura ou detalhe recorrente que preserva continuidade sem atrapalhar leitura longa |
| Blog | Identidade reconhecível na abertura e nos elementos editoriais; corpo de texto em superfície de leitura estável |

A proporção neutral-first do sistema orienta a legibilidade, mas não pode ser interpretada como licença para apagar o gradiente. Caroline explicitou sua centralidade para este website. O equilíbrio deve ser verificado na composição inteira e em mobile.

## 2. Como a martech aparece na experiência

O visual precisa comunicar uma capacidade incorporada ao negócio. Módulos têm papel e conexão; pessoas e IA fazem parte da estrutura; há fluxo de contexto, decisão, execução e aprendizado. A estética de tecnologia ganha credibilidade quando o conteúdo mostra o funcionamento.

Critérios para a primeira prévia:

- Gradiente e materiais específicos da MATA reconhecíveis, inclusive no mobile.
- Uma cena de acoplamento central, com mensagem de negócio compreensível.
- Oferta organizada por situação e responsabilidade, sem vitrine de pacotes de serviços.
- Pessoas e IA visíveis desde a home, com explicação do papel de cada uma.
- Evidência de estruturação, implantação e continuidade; o acabamento criativo aparece dentro dessa contribuição.
- Nenhuma interface de produto, número de agentes ou métrica fictícia para criar aparência de martech.

## 3. Selo: MATA como marca incorporada

Caroline quer que a presença da MATA agregue valor à marca cliente como uma infraestrutura reconhecível. A referência conceitual é a lógica de ingrediente de marca: uma empresa incorpora algo reconhecido de outra empresa e torna essa presença visível.

Na referência citada por Caroline, o selo Creapure é associado a uma qualidade específica e a parceiros verificáveis. Para a MATA, a inspiração útil é vincular uma assinatura a uma contribuição real e identificável. O briefing não importa garantias, critérios industriais ou aparência visual desse selo. [Fonte oficial: selo Creapure](https://www.creapure.com/pt/creapure/o-selo-de-qualidade-creapure/).

### Recomendação de assinatura

**MATA built in.**

Descritor: **Infraestrutura de Brand Marketing**.

Explicação pública proposta: **A assinatura da infraestrutura MATA dentro de um negócio.**

Essa formulação mantém o vínculo com “Brand marketing, built in.”, já presente na referência de Caroline. A categoria principal da empresa continua Infraestrutura de Marketing Acoplável: acoplável explica como a capacidade entra; built in expressa sua presença quando incorporada.

Alternativa integralmente em português: **MATA na estrutura.** Não usar as duas assinaturas como dois selos diferentes; escolher uma na revisão visual. A recomendação inicial é MATA built in.

### Relação ativa e contribuição histórica

| Situação comprovada | Apresentação proposta | Informação que acompanha |
|---|---|---|
| Infraestrutura MATA em operação | MATA built in. · Infraestrutura em operação | Empresa, escopo e início da relação |
| Ciclo de infraestrutura concluído | MATA built in. · Ciclo [período real] | Período encerrado, contribuição e o que permaneceu em uso quando verificável |
| Projeto específico que não correspondeu ao modelo de infraestrutura | Descrever participação real no case; não aplicar selo integral automaticamente | Tipo de contribuição e período |

Os textos de período são campos de rascunho até serem preenchidos. O selo não significa que a MATA endossa todos os produtos, toda a operação ou todo o desempenho da empresa. Ele identifica uma participação específica. Não chamar de “certificação MATA” ou “qualidade garantida” sem que exista um programa próprio que sustente isso.

### Seção no site

Etiqueta: **MATA built in.**

H2 proposto: **A infraestrutura MATA, incorporada a negócios reais.**

Texto: **Conheça onde a MATA está em operação e as estruturas que ajudou a construir. Cada história mostra o contexto, nossa participação e o que mudou.**

Cards: logo da empresa, status da relação, contribuição em uma frase e acesso ao case. Se houver apenas histórico, ajustar a frase de introdução ao conjunto efetivamente publicado. Sem logos liberados e fatos completos, manter a seção em rascunho.

Esta seção substitui o tratamento de “Marcas com as quais construímos”. Não acrescentar uma faixa de logos acima de outra faixa equivalente. Na home, ela integra o bloco de evidência e conduz a Evoluções.

### Direção de desenho do selo

Construir uma assinatura compacta usando o logotipo oficial MATA intacto e “built in.” como elemento complementar. Testar uma forma de módulo com encaixe e uma versão tipográfica mais simples. Não redesenhar letras do logo, não produzir medalha, estrela de certificação ou imitação da referência Creapure.

Versões previstas: expressiva com gradiente oficial; funcional monocromática; histórico com período legível. O logo de cada cliente permanece separado, com respiro e proporção adequada. O selo é um ativo a desenhar e revisar, não um logo oficial já existente no pacote.

No futuro, uma aplicação no site do cliente pode apontar para a página que explica a contribuição MATA. Preparar essa possibilidade sem implantar agora um portal, códigos de verificação ou qualquer programa complexo. Não inserir o selo em canais de clientes como parte desta tarefa.

### Marcas confirmadas por Caroline

**Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF.**

As grafias estão resolvidas. Continuam a completar: relação atual/histórica, escopo, período, escolha dos logos e evidências. A inclusão na lista não concede automaticamente o selo de infraestrutura; conferir a contribuição de cada relação.

## 4. Blog: recomendação após a pergunta sobre endereço

**Decisão de fase confirmada por Caroline:** site e Blog primeiro em português, publicação manual por enquanto; tradução para inglês só depois de a versão PT estar afinada. A ideia de agente publicador fica para o futuro. Não implementá-la agora. O domínio de referência continua wearemata.co; uma menção a .com na conversa não foi tratada como instrução para mudar o domínio.

Preparar artigos com idioma, autoria, estado de publicação e relação entre traduções. A possibilidade de automação depende do editor e de suas integrações; um subdomínio não é requisito intrínseco. Para a estrutura atual, a recomendação prática é **wearemata.co/pt/blog**, com /en/blog reservado conceitualmente para quando houver traduções publicáveis. Não criar páginas inglesas vazias.

Recomendação: **wearemata.co/blog**, ajustando para **/pt/blog** se a estrutura de idiomas do projeto for mantida. O endereço final ainda não foi confirmado por Caroline. A intenção original de domínio separado passou a ser uma alternativa em avaliação.

| Opção | Quando faz sentido para a MATA | Implicação |
|---|---|---|
| /blog ou /pt/blog | Conteúdo editorial faz parte da experiência institucional e comercial | Caminhos e identidade no mesmo site; definir editor e publicação adequados |
| blog.wearemata.co | Plataforma editorial separada oferece vantagem operacional importante | Integração de navegação, identidade e mensuração entre duas instalações |

blog.wearemata.co é um subdomínio de wearemata.co, não exige comprar outro domínio. O endereço visível e a ferramenta de edição são decisões diferentes: um blog em subdiretório pode ter gestão editorial própria; a viabilidade depende da hospedagem e da integração escolhidas.

Minha recomendação é sobre continuidade da experiência e manutenção. Não prometer que /blog ganha posições automaticamente. A orientação geral do Google é escolher a estrutura que funciona para o negócio e para os visitantes; a fonte abaixo é histórica e não deve ser usada para inferir regras atuais de ferramentas de verificação. [Google sobre subdomínios e subdiretórios](https://developers.google.com/search/blog/2008/01/feeling-lucky-at-pubcon).

Se a publicação precisar de nome próprio nos resultados de pesquisa, há uma diferença concreta: o Google suporta site names por domínio ou subdomínio, não por subdiretório. Isso pode favorecer uma publicação independente, mas não é uma necessidade demonstrada da MATA nesta etapa. [Documentação de nomes de site](https://developers.google.com/search/docs/appearance/site-names).

No Lovable, preparar o índice e os modelos de artigo de modo que o endereço não fique espalhado pelos componentes. Não executar uma migração de domínio por suposição. Antes de publicar, fechar o endereço, a forma de editar artigos e os links canônicos.


---

Documento: PROMPT-INICIAL-LOVABLE.txt

Quero atualizar o website atual da MATA, wearemata.co, neste projeto. Leia integralmente os arquivos 02-DOSSIE-ESTRATEGICO-MATA.md, 03-COPY-E-ESTRUTURA-POR-PAGINA.md e 05-IMPLEMENTACAO-E-QA.md e observe as duas imagens anexas antes de propor ou implementar mudanças.

O objetivo é comunicar a MATA como Infraestrutura de Marketing Acoplável: um time de pessoas e um time de IA conectado ao negócio para conduzir marketing. A MATA deve ser percebida como martech. A empresa contrata a capacidade; o time MATA opera a tecnologia. O acoplamento é central tanto no conteúdo quanto no visual.

Nosso público prioritário são empresas com negócio relevante que não têm estrutura de marketing. Também atendemos duas situações relacionadas à marca: o negócio evoluiu e precisa de reposicionamento; ou o posicionamento já existe e precisa sair do papel. O website deve partir do que essas pessoas precisam compreender para decidir, e não de uma lista do que a MATA quer mostrar.

Quero Blog explicitamente no menu. A recomendação atual do briefing é /blog ou /pt/blog; o endereço final está em avaliação, com subdomínio como alternativa quando houver vantagem editorial. Quero dois caminhos de contato independentes: formulário curto e botão Agendar uma conversa. Use a agenda já fornecida: https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C . Não faça do formulário uma exigência para agendar.

Use a identidade oficial MATA e as referências de estruturas que se acoplam. Os módulos e suas conexões precisam explicar o modelo. Use texto real e preserve clareza no celular. Não invente uma interface de software, agentes autônomos, números, clientes, logos, depoimentos ou funcionalidades para preencher espaço.

Primeiro examine o projeto atual: stack, rotas, componentes, formulários, integrações, metadados e publicação. Faça um resumo curto do que encontrou e identifique conflitos materiais com o briefing. Depois comece pela home com conteúdo real e uma composição de acoplamento em desktop e mobile. Desenvolva as demais páginas a partir desse sistema. Preserve o que funciona e evite migrações desnecessárias.

Os cases e logos devem ter estrutura preparada, mas só entram no site público quando houver conteúdo validado. Não copie automaticamente as métricas do site atual; há pendências indicadas no dossiê. As hipóteses de produtos internos e as condições comerciais não confirmadas não são promessas publicáveis.

Guarde as decisões duráveis no conhecimento do projeto conforme o arquivo 04. Os arquivos de briefing são referência de desenvolvimento; não devem ser expostos como arquivos públicos do website.

Leia também 07-GRADIENTE-SELO-E-BLOG.md. O gradiente MATA é obrigatório e central: use o arquivo oficial assets/gradientes/MATA-gradiente-oficial.png junto das duas capas. O look and feel deve comunicar martech e infraestrutura acoplada, com funcionamento real e responsabilidade humana. A proposta de selo é MATA built in., com descritor Infraestrutura de Brand Marketing; desenvolver para revisão, distinguindo operação atual e ciclos históricos. As marcas confirmadas são Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF. Não presumir escopo integral de infraestrutura em todas as relações.

Fase de lançamento confirmada: trabalhar o novo site e Blog somente em português; publicação manual dos artigos por enquanto. Traduzir para inglês apenas depois de a versão PT estar afinada. Preparar o modelo editorial para idiomas e possível automação futura, sem construir agente de publicação agora. Recomenda-se /pt/blog; /en/blog só quando houver traduções revisadas.

Ao concluir cada etapa, mostre a prévia e o que foi verificado. Antes de considerar a versão pronta, confira navegação, responsividade, contraste, teclado, reduced motion, estados do formulário, recebimento real, agendamento, Blog, idiomas e requisitos de busca. Diferencie implementado, verificado e pendente. Não trate sucesso de build como prova de qualidade da experiência.
