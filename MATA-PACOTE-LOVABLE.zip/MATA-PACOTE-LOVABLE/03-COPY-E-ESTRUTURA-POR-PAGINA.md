# MATA — Copy e estrutura por página

Versão de trabalho proposta. Usar em conjunto com o dossiê. Os textos abaixo foram escritos para o novo site; não são citações dos documentos internos. Trechos marcados como pendentes não entram no site público. A implementação deve preservar a lógica e ajustar quebras de linha após inspeção responsiva.

## Sistema de navegação e ações

Menu: **Como funciona · Para sua empresa · Evoluções · Sobre · Blog**.

Submenu de Para sua empresa: **Estruturar marketing · Reposicionar a marca · Implantar o posicionamento**.

Ação principal: **Conversar sobre minha empresa** → formulário curto em /pt/contact.

Ação alternativa: **Agendar uma conversa** → [agenda fornecida por Caroline](https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C). Os dois caminhos são independentes. O formulário não é pré-requisito para agendar.

Link de exploração: **Ver como funciona**. Em vez de três botões com o mesmo peso, usar botão principal, botão secundário e link textual. Repetir a mesma hierarquia no rodapé de conversão.

Publicar Evoluções no menu quando houver caso validado. Blog precisa de destino funcional; agenda precisa de endereço real. As pendências devem ficar no controle de implementação, nunca renderizadas como texto entre colchetes para o visitante.

## 1. Home — /pt

### Bloco 1 — Reconhecimento e oferta

Etiqueta:

**Infraestrutura de Marketing Acoplável**

H1:

**Seu negócio cresceu. Acople uma estrutura de marketing à altura.**

Texto:

A MATA reúne um time de pessoas e um time de IA para conduzir o marketing junto ao seu negócio, da estratégia à execução. Para empresas que cresceram sem estruturar marketing e marcas que precisam acompanhar uma nova fase.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**

Link: **Ver como funciona →**

Visual: gradiente oficial MATA reconhecível na atmosfera da primeira dobra; estrutura da empresa à qual o módulo MATA se conecta. Mostrar no máximo três rótulos legíveis no primeiro estado: **Seu negócio**, **Time de pessoas**, **Time de IA**. Contexto e prioridades aparecem no aprofundamento, sem sobrecarregar o hero.

Nota de direção: “à altura” é uma promessa de adequação, sustentada pelo funcionamento e pelos casos. Não acrescentar promessas de receita, escala ou produtividade. A categoria principal já explica o acoplamento; a imagem reforça, não substitui a informação.

### Bloco 2 — Quando a MATA começa a fazer sentido

H2:

**O que o seu negócio precisa fazer acontecer agora?**

Introdução:

A estrutura começa pelo momento da empresa. Pode faltar quem conduza o marketing, uma marca que traduza o negócio atual ou um time para colocar uma nova direção em prática.

Entrada principal, com maior peso visual:

**A empresa cresceu. O marketing ainda depende de você.**

Seu negócio já tem clientes, produto e operação. A MATA se acopla à empresa para organizar prioridades, reunir as competências necessárias e dar continuidade ao trabalho de marketing.

Link: **Quero estruturar o marketing →**

Entrada secundária A:

**O negócio mudou. A marca ainda conta a história antiga.**

Ajudamos a traduzir a evolução da empresa em posicionamento, narrativa e pontos de contato que façam sentido para o mercado de hoje.

Link: **Quero reposicionar a marca →**

Entrada secundária B:

**A nova direção está pronta. Falta colocá-la em prática.**

Conectamos o posicionamento aprovado ao site, aos materiais comerciais, ao conteúdo e às escolhas que fazem a marca existir no dia a dia.

Link: **Quero implantar o posicionamento →**

Composição: um bloco principal mais amplo e duas entradas relacionadas. Evitar três planos de assinatura ou três pacotes de serviço. Todos os textos devem estar acessíveis sem interação obrigatória.

### Bloco 3 — MATA built in. e evidência

Etiqueta proposta: **MATA built in.**

H2 para conjunto validado:

**A infraestrutura MATA, incorporada a negócios reais.**

Introdução: Conheça onde a MATA está em operação e as estruturas que ajudou a construir. Cada história mostra o contexto, nossa participação e o que mudou. Ajustar a introdução se o conjunto publicado só incluir relações históricas.

Apresentar assinatura MATA, logo da empresa, status atual ou ciclo histórico, contribuição e acesso ao de/para. Não presumir que toda marca mencionada contratou infraestrutura completa; aplicar regras do arquivo 07.

Estrutura, a preencher com prova real:

- Situação da empresa e contexto relevante.
- Responsabilidade assumida pela MATA.
- Mudança em uso e sua evidência.
- Link: **Conhecer essa evolução →**.

Sem case pronto, usar o próximo bloco como demonstração antecipada. Não publicar logos cinza, números fictícios, depoimentos provisórios ou “em breve” no meio da prova.

### Bloco 4 — A infraestrutura em funcionamento

H2:

**Uma decisão de negócio precisa chegar ao trabalho.**

Texto:

Uma dúvida que aparece nas vendas pode mudar a forma de apresentar um produto. A MATA conecta essa leitura às prioridades de marketing e acompanha o caminho até a resposta entrar em uso.

Rótulo visível: **Exemplo ilustrativo de funcionamento**.

Sequência:

1. **O negócio traz uma questão.** O comprador não está entendendo uma diferença importante da solução.
2. **A MATA investiga e organiza.** O time conversa com as pessoas certas e reúne materiais e evidências.
3. **Pessoas e IA preparam o trabalho.** A IA ajuda a organizar informações e desenvolver versões. A pessoa responsável conduz as escolhas e a revisão.
4. **A decisão ganha forma.** A resposta chega à página, à proposta ou ao conteúdo que precisa mudar.
5. **O uso orienta a próxima escolha.** O retorno do comercial e do público ajuda a revisar o trabalho.

Fechamento:

Você participa das decisões de negócio. A MATA cuida de conectar essas decisões ao andamento do marketing.

Link: **Entender o acoplamento →**.

Interação: passos clicáveis e percorríveis por teclado; nenhum timer obrigatório. O conteúdo completo continua disponível em modo estático e com movimento reduzido. Não apresentar a sequência como caso de cliente ou fluxo autônomo já medido.

### Bloco 5 — Pessoas + IA

Etiqueta: **AI-oriented. Condução humana.**

H2:

**Um time de pessoas e um time de IA, trabalhando no contexto da sua empresa.**

Texto:

As pessoas conduzem a relação, as escolhas e a avaliação do trabalho. A IA participa da organização de informações, da preparação de versões e do apoio a atividades recorrentes, com direção e revisão humanas.

Frase de apoio:

Você conta com essa capacidade de trabalho. A equipe MATA opera a tecnologia que a sustenta.

Microblocos:

**Pessoas** — Entender, escolher, criar, conversar e responder pelo trabalho.

**IA** — Organizar contexto, preparar materiais e apoiar a execução.

**Prioridades compartilhadas** — O trabalho parte da realidade do negócio e dos objetivos combinados.

Não inserir uma quantidade fixa de profissionais, agentes ou ferramentas. A composição depende do mandato e da capacidade contratada.

### Bloco 6 — Efeito na liderança

H2:

**A MATA devolve espaço mental.**

Texto:

Ter marketing funcionando significa saber quem está conduzindo o trabalho, quais prioridades estão em andamento e onde sua decisão é necessária. A liderança continua próxima, mas deixa de precisar ligar cada ponta para o marketing avançar.

Três consequências, apresentadas como finalidade do modelo:

**Decisões chegam com contexto.** O time organiza a questão e apresenta uma recomendação.

**O trabalho tem continuidade.** Prioridades e próximos passos têm responsáveis.

**A marca acompanha o negócio.** O que muda na empresa pode se refletir na comunicação e nos materiais em uso.

Link: **Ver como dividimos as responsabilidades →**.

### Bloco 7 — Blog

H2:

**Perguntas que aparecem quando o negócio cresce.**

Texto:

Leituras sobre estrutura de marketing, evolução de marca e o trabalho de pessoas e IA dentro das empresas.

Três chamadas editoriais:

**Como estruturar a área de marketing quando a empresa já cresceu**

Critérios para escolher o que precisa ser organizado, quem conduz o trabalho e que capacidade será necessária. **Time da MATA**.

**O reposicionamento foi aprovado? Sim. E agora?**

O que acontece entre aprovar uma nova direção e fazer a empresa trabalhar a partir dela. **Caroline Miranda Martha**.

**Produzir marketing não é conduzir marketing**

Quando produzir fica mais acessível, onde o trabalho de marketing passa a se acumular? **Caroline Miranda Martha**.

Link: **Explorar o Blog →**.

Não inventar datas, links de publicação, capas ou tempo de leitura. O tempo pode ser calculado após a implantação dos textos; os resumos acima são copy nova para apresentação editorial.

### Bloco 8 — Conversa

H2:

**O que precisa mudar no marketing da sua empresa?**

Texto:

Conte o momento do negócio ou escolha um horário para conversar. Vamos entender onde a MATA pode se acoplar e qual trabalho essa estrutura precisaria assumir.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

Link opcional: **Tenho algumas dúvidas →** para FAQ de Como funciona.

## 2. Como funciona — /pt/how-it-works

H1:

**Como uma infraestrutura de marketing se acopla ao seu negócio.**

Introdução:

A MATA reúne pessoas, IA e uma forma de organizar o trabalho a partir da realidade da empresa. O começo é entender o que precisa avançar e combinar as responsabilidades para fazer isso acontecer.

### Entendemos o negócio

Conversamos com a liderança e com as áreas relevantes para entender a oferta, os públicos, a operação e o que o marketing precisa ajudar a resolver. Materiais existentes e situações comerciais fazem parte dessa leitura.

O que o comprador deve compreender: não precisa entregar um plano de marketing pronto; precisa permitir acesso ao contexto necessário.

### Definimos o que a estrutura vai assumir

Combinamos prioridades, capacidade de trabalho, responsabilidades e decisões que precisam voltar à empresa. A composição do time acompanha esse mandato.

Mostrar quadro simples:

| A MATA conduz, dentro do combinado | A empresa continua decidindo |
|---|---|
| Organização e recomendações de marketing | Direção do negócio e investimento |
| Coordenação do trabalho e das competências envolvidas | Compromissos relevantes da oferta |
| Preparação, execução e revisão de materiais | Aprovações reservadas e informações técnicas de sua responsabilidade |
| Acompanhamento do que foi colocado em uso | Mudanças em produto, preço ou operação |

Texto: A divisão é acordada para cada empresa. Proximidade com o comercial não significa assumir toda a área de vendas.

### Conectamos pessoas e IA ao trabalho

O time de pessoas conduz as escolhas e a relação com a empresa. O time de IA apoia atividades delimitadas, usando o contexto disponível e os critérios de revisão. A MATA integra essas capacidades à execução.

Texto de confiança: Você não precisa coordenar agentes ou montar a combinação de ferramentas para o marketing acontecer.

### Transformamos prioridades em execução

Uma mesma direção pode precisar chegar ao site, à apresentação comercial, ao conteúdo ou a uma campanha. O time organiza essa sequência para que as partes trabalhem a favor do mesmo objetivo.

Exemplos de capacidades, sempre subordinados à prioridade:

- Tornar a oferta mais clara: posicionamento, narrativa e materiais comerciais.
- Fazer a marca ganhar consistência: identidade, aplicações e conteúdo.
- Colocar uma mudança no mercado: site, canais e comunicação de lançamentos.
- Aprender com o trabalho: retorno do comercial, uso dos materiais e indicadores acordados.

Nota: os exemplos não constituem pacote universal nem promessa de inclusão ilimitada.

### Acompanhamos e ajustamos

A entrega encontra a realidade: uma dúvida do público, uma mudança no produto, o uso pelo comercial. O acompanhamento ajuda a decidir o que continuar, corrigir ou priorizar em seguida.

### O que você consegue acompanhar

Exibir exemplos de artefatos apenas após validação: registro de prioridades, uma decisão com contexto, um material em uso e uma revisão de aprendizado. Esses objetos explicam o método melhor do que siglas isoladas.

Para apresentar SSOT: “Base de contexto da marca”. Para apresentar ranking: “Prioridades e escolhas de trabalho”. Para shadowing: “Aprendizado com o comercial”. Usar nomes proprietários como detalhe, quando vigentes e comprovados.

### Perguntas frequentes

**A MATA é uma agência?**

A MATA é uma infraestrutura de marketing acoplável. Você conta com um time de pessoas e um time de IA conectados ao negócio, com responsabilidades combinadas para conduzir o trabalho e acompanhar sua execução. Na conversa inicial, detalhamos o que essa estrutura assume no seu caso.

**Preciso ter alguém de marketing para trabalhar com a MATA?**

O modelo foi pensado especialmente para empresas com negócio relevante que ainda não estruturaram essa função. É necessário ter uma liderança que participe das decisões de negócio e facilite o acesso às informações e pessoas importantes para o trabalho.

**Vou precisar aprender a usar ferramentas de IA?**

A equipe MATA opera a tecnologia que sustenta o trabalho. Sua participação está no contexto e nas decisões necessárias para a empresa, não em coordenar o time de IA.

**O marketing passa a funcionar sem minha participação?**

A liderança continua envolvida nas decisões que importam. O objetivo é ter uma estrutura que organiza, recomenda e acompanha o trabalho, com clareza sobre quando sua participação é necessária.

**Já temos um posicionamento. A MATA pode começar daí?**

Sim. A entrada pode ser a implantação da direção existente. O primeiro passo é entender o que foi definido, quais materiais estão em uso e o que precisa mudar para essa direção chegar ao dia a dia.

**Como são definidos o time e o investimento?**

A partir do trabalho que a empresa precisa conduzir e da capacidade necessária para isso. A conversa deve esclarecer dedicação, competências, prioridades e despesas adicionais antes da contratação.

**A estrutura pode mudar ao longo do tempo?**

O modelo é desenhado para acompanhar mudanças nas prioridades da empresa. Alterações de capacidade, composição e condições seguem o que for combinado na contratação.

**O que fica com a empresa?**

Os materiais e registros destinados à marca, os acessos e as condições de continuidade precisam estar claros na contratação. A conversa também distingue esses entregáveis da infraestrutura e dos métodos utilizados pela MATA.

Nota interna: essa resposta evita ampliar uma promessa ainda contraditória nas fontes. Antes da publicação, substituir por redação comercial precisa conforme as condições efetivamente adotadas.

**Vocês trabalham com mídia paga?**

A escolha de canais depende do problema, do público e do momento do negócio. A MATA valoriza construir uma base consistente de marca, conteúdo e ativos; mídia paga pode participar quando fizer sentido para a estratégia e o investimento acordado.

CTA final: **Conte o momento da sua empresa.**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 3. Estruturar marketing — /pt/estruturar-marketing

H1:

**Sua empresa cresceu. O marketing ainda precisa de estrutura.**

Texto:

O negócio já tem produto, clientes e operação. Para o marketing acompanhar, é preciso definir o que ele vai assumir e ter capacidade para conduzir esse trabalho com continuidade.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

### Quando tudo ainda volta para a liderança

Quem explica o negócio para cada profissional? Quem decide o que vem primeiro? Quem percebe que o material já ficou desatualizado? Quando essas respostas são sempre a mesma pessoa, o marketing ocupa uma parte crescente da agenda de quem deveria poder olhar para o negócio.

### O que passa a ter estrutura

**Direção.** Entender o problema que merece prioridade.

**Responsabilidade.** Saber quem conduz, quem executa e onde a empresa decide.

**Capacidade.** Reunir pessoas e IA para o trabalho escolhido.

**Continuidade.** Acompanhar a execução e o que acontece depois.

### Como a MATA entra

A MATA se acopla ao negócio com um time de pessoas e um time de IA. A estrutura reúne competências e organiza o trabalho a partir do que a empresa precisa fazer acontecer, com responsabilidades e prioridades combinadas.

### O primeiro movimento depende do gargalo

Se o comprador não entende o produto, a prioridade pode estar na explicação da oferta. Se a marca conta uma versão antiga da empresa, pode ser necessário rever o posicionamento. Se já existe uma direção clara, o trabalho pode começar pela implantação e pela rotina.

Não colocar um cronograma obrigatório de 30/60/90 dias como promessa de implantação. Pode haver um exemplo de percurso, identificado como ilustrativo, depois de validar o processo comercial.

### Você participa de quê?

A liderança traz objetivos, decisões e acesso ao negócio. A MATA organiza a condução do marketing dentro do mandato acordado. O início serve também para tornar essa divisão explícita.

### Veja uma evolução

Espaço de caso relacionado à construção da função; condicionado a evidência. Sem caso pronto, ligar para a demonstração da home e para Como funciona, sem alegação de resultado.

Leitura: **Como estruturar a área de marketing quando a empresa já cresceu**.

Fechamento: **Seu próximo passo pode ser estruturar quem conduz o marketing.**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 4. Reposicionar a marca — /pt/reposicionamento

H1:

**O negócio avançou. A marca precisa contar essa história.**

Texto:

A empresa pode ter ampliado sua capacidade, mudado o portfólio ou passado a disputar um mercado diferente. A MATA ajuda a traduzir essa evolução em uma direção de marca e em comunicação que faça sentido para quem precisa escolher você.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

### Começamos pelo que mudou

O que a empresa faz hoje? Para quem isso importa? O que o mercado já reconhece e o que ainda não percebe? Essas perguntas ajudam a distinguir uma questão de posicionamento de um ajuste de linguagem ou expressão visual.

### Preservar também é uma decisão

Trajetória, relações e reputação podem dar credibilidade ao próximo movimento. Reposicionar exige entender o que precisa mudar e o que continua sustentando a confiança no negócio.

### Da direção às situações de compra

Uma posição precisa orientar como a empresa apresenta sua oferta, demonstra valor e responde às perguntas do comprador. O trabalho chega à narrativa, à identidade e aos materiais que colocam essa direção diante do mercado, conforme o escopo acordado.

### O que acontece depois da aprovação

A implantação precisa de prioridades, responsáveis e acompanhamento. A infraestrutura acoplável da MATA conecta essa etapa à capacidade de execução, para que a mudança alcance os pontos de contato relevantes.

Nota comercial: a continuidade e sua capacidade são combinadas. Não presumir que todo projeto exige contrato recorrente nem que um contrato de estratégia já inclui todas as aplicações.

### Já existe uma direção aprovada?

Podemos começar pela passagem entre a estratégia e o uso. Entender o que já foi construído é parte do trabalho.

Link: **Conhecer a implantação de posicionamento →**.

Caso: reservar de/para com peças comparáveis e raciocínio, sem mostrar apenas troca de logo.

Fechamento: **Qual parte do seu negócio a marca ainda não consegue mostrar?**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 5. Implantar o posicionamento — /pt/implementar-posicionamento

H1:

**O posicionamento está aprovado. Agora, ele precisa entrar em uso.**

Texto:

A próxima proposta comercial, a página de solução e o conteúdo publicado precisam começar a refletir a nova direção. A MATA organiza e conduz essa passagem com um time de pessoas e um time de IA acoplados ao negócio.

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

### Partimos do que já foi construído

Lemos a estratégia existente, entendemos as decisões e observamos os materiais em uso. O objetivo é identificar o que já orienta bem o trabalho e onde ainda falta tradução ou definição.

### Escolhemos onde a mudança precisa aparecer primeiro

Nem tudo tem a mesma urgência. O que influencia uma decisão de compra, sustenta a explicação da oferta ou está em uso recorrente pode exigir prioridade. A sequência de implantação acompanha a realidade da empresa.

### Conectamos os pontos de contato

Site, proposta, apresentação, conteúdo e comunicação de lançamento podem precisar de mudanças diferentes para expressar a mesma direção. A MATA organiza essa execução e as decisões necessárias para manter coerência.

### Acompanhamos a adoção

O comercial está usando o material? O público entendeu a mensagem? Alguma promessa depende de uma decisão que ainda não foi tomada? O retorno da implantação ajuda a ajustar o trabalho.

### Você não precisa recomeçar automaticamente

Um posicionamento bem construído é um ponto de partida. Se encontrarmos uma lacuna que impede a execução, ela será trazida para discussão com contexto. Refazer a estratégia não deve ser uma condição presumida para colocar o que já existe em prática.

Leitura: **O reposicionamento foi aprovado? Sim. E agora?**.

Fechamento: **Qual parte da sua nova marca ainda está no papel?**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 6. Evoluções — /pt/results

Página estruturada para receber evidências; não publicar como biblioteca vazia.

H1:

**A infraestrutura MATA, incorporada a negócios reais.**

Introdução:

Cada negócio pede um trabalho diferente. Aqui, mostramos a situação que encontramos, as responsabilidades que assumimos e o que passou a existir ou funcionar depois.

Para cada caso:

- Nome oficial e setor, se liberados.
- Uma frase sobre a mudança observada.
- Situação anterior → trabalho da MATA → resultado ou capacidade criada.
- Período explícito.
- Evidência representativa e link **Conhecer a evolução**.

Evitar classificações por tipo de peça. Se o conjunto justificar filtros, usar situações: Estruturação, Reposicionamento, Implantação. Não criar filtros para três casos ou menos se só aumentarem a interface.

### Página de caso

H1 descreve a transformação demonstrável. Abrir pelo contexto da empresa, seguir para o que precisava mudar e mostrar como as decisões chegaram à execução. Comparações devem trazer legendas, data e o que está sendo comparado. Texto também explica o de/para para quem não vê as imagens.

Fechar com o que segue em operação e como foi observado. Crédito dos profissionais/parceiros envolvidos quando pertinente. Indicar resultados comerciais como correlação ou contribuição quando não houver atribuição comprovada.

CTA: **Sua empresa vive um momento parecido?** + os dois caminhos de contato.

## 7. Sobre — /pt/story

H1:

**A MATA nasce da necessidade de fazer o marketing acompanhar o negócio.**

Texto:

Há empresas que construíram produtos, relações e operações relevantes antes de ter uma estrutura de marketing. Outras mudaram tanto que a marca ainda conta uma versão anterior do negócio. A MATA está sendo construída para trabalhar dentro dessa realidade.

### Uma infraestrutura acoplável

Reunimos um time de pessoas e um time de IA para conectar contexto, escolhas e execução. A empresa passa a contar com uma estrutura que conduz o trabalho de marketing com proximidade e responsabilidades combinadas.

### Por que MATA

O nome vem da biomimética e da observação de sistemas vivos: partes que se conectam, trocam e se desenvolvem em relação umas com as outras. Essa lógica inspira a forma como pensamos a relação entre marca, pessoas, tecnologia e negócio.

### A construção do modelo

A IA participa do nosso trabalho e da forma como desenvolvemos capacidade. As pessoas conduzem as escolhas, a relação com as empresas e a avaliação daquilo que colocamos em uso. O modelo continua evoluindo a partir dessa experiência.

### Caroline Miranda Martha

**Fundadora da MATA.**

Adicionar fotografia real, biografia validada e link profissional confirmado. Não inventar anos de experiência, formação, prêmios ou histórico. A página não deve depender de números de currículo para explicar o modelo.

### Como pensamos

O negócio é o briefing. A forma faz parte do pensamento. A entrega não é a linha de chegada. Esses princípios orientam a maneira como a MATA procura entender, construir e acompanhar o trabalho.

Links: **Conhecer MATAthinking →** · **Ler o Blog →**.

Fechamento: **Vamos entender o momento da sua empresa.**

Botões: **Conversar sobre minha empresa** · **Agendar uma conversa**.

## 8. MATAthinking — /pt/principles

H1: **Como pensamos o trabalho de marketing.**

Introdução: Os princípios da MATA orientam como entramos no negócio, fazemos escolhas e acompanhamos o que o trabalho produz.

Direção editorial: preservar o sentido dos seis princípios públicos. A versão de sete princípios no Positioning é uma alternativa interna; não fazer uma fusão silenciosa. A proposta abaixo adapta os títulos públicos à linguagem desta experiência.

1. **O negócio é o briefing.** Entender a empresa e o problema que levou a uma demanda faz parte do trabalho.
2. **Proximidade precisa virar entendimento.** Conhecer produto, comercial e contexto ajuda a escolher melhor.
3. **A iniciativa faz parte da responsabilidade.** Observar, trazer uma leitura e propor próximos passos dentro do mandato combinado.
4. **Entender o conjunto. Assumir a própria parte.** Curiosidade ampla com responsabilidade clara.
5. **A forma faz parte do pensamento.** Uma direção precisa chegar ao texto, ao design e à experiência com clareza.
6. **A entrega não é a linha de chegada.** Acompanhar o uso e o efeito ajuda a decidir o trabalho seguinte.

Cada princípio pode receber um exemplo documentado da operação. Enquanto não houver, manter a explicação curta; não fabricar cenas como se fossem ocorrências reais.

## 9. Contato — /pt/contact

H1:

**Conte o que precisa mudar. Ou escolha um horário para conversar.**

Introdução:

Começamos pelo momento da empresa e pelo trabalho que o marketing precisa ajudar a fazer acontecer.

### Caminho 1 — Formulário curto

Título: **Sobre sua empresa**.

Campos:

1. **Seu nome** — obrigatório.
2. **Seu e-mail** — obrigatório, validação de formato.
3. **Empresa ou site** — obrigatório; aceitar texto, não exigir que quem não tem site informe uma URL.
4. **O que melhor descreve o momento?** — obrigatório: “Precisamos estruturar marketing”; “A marca precisa acompanhar o negócio”; “Temos um posicionamento para implantar”; “Quero explicar outra situação”.
5. **O que precisa mudar?** — opcional, texto livre, máximo proposto de 1.000 caracteres.

Botão: **Enviar contexto**.

Microcopy: **Seu contato será usado para responder a esta conversa.** Vincular à política aplicável depois de aprovada; não inventar política ou checkbox de newsletter.

Loading: **Enviando…**.

Sucesso, somente com envio confirmado: **Recebemos seu contexto. Obrigado por contar o momento da sua empresa.**

Erro: **Não conseguimos enviar agora. Seu texto continua aqui para você tentar novamente. Você também pode falar por e-mail.**

Validação: **Informe seu nome.** · **Confira o endereço de e-mail.** · **Informe a empresa ou o site.** · **Escolha a situação que melhor descreve seu momento.**

### Caminho 2 — Agenda

Título: **Prefere conversar direto?**

Texto: **Escolha um horário disponível na agenda.**

Botão: **Agendar uma conversa**.

Usar a agenda confirmada: https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C . Abrir diretamente, sem exigir formulário. Conferir acesso público; não inventar duração, disponibilidade ou integração.

### Canais diretos

E-mail: **hello@wearemata.company** — endereço observado no site atual.

WhatsApp: preservar o destino atual observado, sujeito a conferência de recebimento. Texto inicial sugerido: **Oi, vim pelo site da MATA e quero conversar sobre o marketing da minha empresa.**

LinkedIn: [MATA](https://www.linkedin.com/company/wearemata).

## 10. Blog — entrada e contrato de conteúdo

H1: **Marketing na realidade de quem conduz um negócio.**

Texto: Leituras sobre estrutura, marca e o trabalho de pessoas e IA. Para entender o que precisa mudar e como fazer essa mudança acontecer.

Trilhas: **Estruturar marketing · Marca em movimento · Pessoas + IA**.

Começar pelos três artigos existentes, com as autorias corretas. A página só deve mostrar conteúdo que de fato possa ser aberto. A recomendação atual é /blog ou /pt/blog, com endereço final a confirmar; subdomínio é alternativa explicada no arquivo 07. Configurar o endereço em um único lugar, aplicado ao menu, às chamadas editoriais e aos links de retorno.

## 11. Metadados propostos

Os títulos e descrições abaixo são propostas; validar comprimento visual nos resultados e no compartilhamento. Não há contagem de caracteres que garanta exibição integral.

| Página | Título | Descrição |
|---|---|---|
| Home | MATA — Infraestrutura de Marketing Acoplável | Um time de pessoas e um time de IA para empresas que cresceram sem estruturar marketing e marcas que precisam acompanhar o negócio. |
| Como funciona | Como funciona a infraestrutura acoplável da MATA | Entenda como pessoas, IA e responsabilidades combinadas conectam o contexto da empresa à estratégia e à execução de marketing. |
| Estruturar | Sua empresa cresceu sem marketing? Conheça a MATA | Estruture a condução do marketing com pessoas e IA conectadas à realidade do negócio, das prioridades ao acompanhamento da execução. |
| Reposicionamento | Reposicionamento de marca para empresas em evolução — MATA | Traduza a evolução do negócio em posicionamento, narrativa e comunicação, com um caminho para fazer a nova direção entrar em uso. |
| Implantação | Como colocar seu posicionamento em prática — MATA | Conecte a direção aprovada ao site, aos materiais comerciais e ao conteúdo com uma estrutura que organiza e conduz a implantação. |
| Sobre | Sobre a MATA — Pessoas, IA e marketing acoplável | Conheça a visão que orienta a MATA e a construção de uma infraestrutura de marketing conectada à realidade das empresas. |
| Contato | Converse sobre sua empresa — MATA | Conte o momento do negócio em um formulário curto ou agende uma conversa para entender onde a MATA pode se acoplar. |

## 12. Inglês e migração editorial

Caroline confirmou: primeiro afinar o site e o Blog em português; só depois traduzir para inglês. A publicação dos artigos será manual nesta fase. A versão /en existente deve ser inventariada e preservada sem alterações incidentais até uma decisão de lançamento coerente; não traduzir nem criar novas páginas EN nesta etapa. Não misturar blocos novos em português com conteúdo antigo em inglês. Não anunciar versão equivalente em inglês de um artigo que só existe em português.

Vocabulário proposto: **Pluggable Brand Marketing Infrastructure**, **A human team and an AI team**, **Book a conversation**. A assinatura **Brand marketing, built in.** pode permanecer em contextos expressivos.

No lançamento de cada idioma, manter a equivalência entre oferta, condições, casos e contato. Marcação de idiomas e links alternativos devem apontar para páginas realmente existentes. Caso uma nova página ainda não tenha versão em inglês, comunicar a disponibilidade de idioma de modo claro, sem fingir tradução concluída.
