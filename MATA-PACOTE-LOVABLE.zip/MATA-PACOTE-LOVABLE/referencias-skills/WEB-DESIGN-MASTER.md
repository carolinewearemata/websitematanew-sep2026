# Referência oficial para consulta

Cópia dos textos consultados. Não é uma skill instalada no Lovable. Instruções explícitas de Caroline prevalecem. Caminhos relativos abaixo pertencem à organização original; os assets selecionados estão no pacote e as orientações de implementação estão nos arquivos 02 a 07.


---

## Fonte: SKILL.md

---
name: web-design-master
description: "Direção, arquitetura de experiência, construção e controle de qualidade para websites e interfaces web profissionais. Use ao criar, redesenhar, estudar ou auditar landing pages, sites institucionais, portfolios, e-commerce, SaaS, dashboards e produtos web; especialmente quando o resultado precisa evitar aparência genérica de IA, respeitar um design system existente e ser verificado no navegador. Não use como substituta da skill da marca, de uma ferramenta de implementação exigida ou de trabalho puramente backend."
---

# Web Design Master

Atuar como direção de web design e controle de qualidade da experiência implementada. Transformar intenção, conteúdo e restrições em uma interface específica, utilizável, responsiva e bem acabada. A base é universal; a identidade vem do briefing e, quando existir, do design system conectado.

Não prometer gosto infalível nem nota estética automática. Qualidade é demonstrada pela coerência das decisões, pelos comportamentos implementados e pela inspeção da saída real.

## Contrato de integração

Reconhecer qualquer uma destas formas como pedido de conexão:

- `$web-design-master + $nome-da-skill-de-design-system — tarefa`
- `CONNECT DESIGN SYSTEM: nome, pasta, arquivo ou URL`
- Linguagem natural equivalente, como “use a Web Design Master com o design system da marca”.

Ao conectar:

1. Procurar no contexto, nas skills disponíveis e nas fontes do projeto um sistema que corresponda inequivocamente à marca/produto nomeado. Conectar automaticamente quando a correspondência for clara; se houver mais de um candidato plausível, pedir a escolha.
2. Ler a skill e as fontes canônicas do design system antes de decidir a aparência. Uma lembrança ou resumo não equivale ao manual consultado.
3. Registrar quais fontes e ativos foram realmente consultados e as lacunas materiais.
4. Aplicar esta ordem de autoridade: instrução explícita e conteúdo aprovado; design system conectado para identidade, tokens, componentes e ativos; Web Design Master para arquitetura, UX, responsividade, implementação e QA; convenções técnicas do projeto.
5. Não importar cores, fontes, logos, componentes ou hábitos de outra marca. Não completar lacunas com regras lembradas de clientes anteriores.
6. Quando uma regra de marca prejudicar leitura, acessibilidade ou comportamento, procurar primeiro uma combinação permitida. Se o conflito material permanecer, explicar o caso e oferecer uma alternativa; não alterar a marca silenciosamente.

Sem design system disponível, criar uma direção provisória específica ao briefing e documentar apenas as decisões necessárias. Não simular que uma identidade provisória é oficial.

Ler [integration-design-system.md](references/integration-design-system.md) sempre que houver conexão, descoberta ou documentação de um sistema.

## Escolher o modo e o registro

Escolher um modo principal:

- **Build:** criar ou ampliar uma experiência.
- **Redesign:** preservar verdade do produto, conteúdo e comportamento; diagnosticar antes de substituir a camada visual.
- **Audit:** avaliar sem modificar, salvo pedido explícito de correção.
- **Study:** extrair princípios de referências sem clonar composição, texto, identidade ou ativos.
- **Document:** registrar um sistema coerente já implementado sem inventar regras ausentes.

Classificar a superfície:

- **Brand:** marketing, campanha, portfolio e institucional; design carrega posicionamento e pode usar estrutura mais expressiva.
- **Product:** SaaS, dashboard, e-commerce operacional e ferramenta; design serve a tarefas, previsibilidade, estados e densidade.
- **Read:** documentação, editorial e conteúdo longo; design serve navegação e leitura.

Uma experiência pode combinar registros por rota, mas cada página precisa de um registro dominante. Ler a seção correspondente de [surface-modes.md](references/surface-modes.md).

## Fluxo obrigatório

### 1. Ler antes de desenhar

Inspecionar o pedido, o projeto existente e as fontes disponíveis. Extrair sem burocracia:

- público, contexto e tarefa principal;
- ação desejada e critério de sucesso;
- conteúdo, provas e dados reais;
- rotas, estados, dispositivos e requisitos de acessibilidade;
- design system, referências e rejeições confirmadas;
- stack, componentes existentes, prazo e limites do escopo.

Perguntar somente pelo que bloqueia uma decisão material. Assumir detalhes reversíveis e identificá-los brevemente. Não reabrir fatos já confirmados.

Quando o usuário pedir uma direção alinhada ao gosto já registrado ou citar Dribbble Beauty Platform, Alia, Nubank ou Ladies, Wine & Design, ler [curated-references.md](references/curated-references.md). Usar essas fontes como lentes de decisão; nunca como identidade substituta do design system conectado.

### 2. Definir a direção antes do código

Produzir uma ficha curta de direção com:

- tese da página e ordem da narrativa;
- macroestrutura e comportamento responsivo;
- registro, densidade e hierarquia;
- papéis tipográficos e cromáticos;
- estratégia de imagem, ilustração, dados ou interface;
- princípio de interação/motion;
- um momento memorável, quando apropriado;
- escolhas recusadas e motivo observável.

Quando a direção estiver aberta, explorar até três conceitos estruturalmente distintos sob conteúdo e restrições equivalentes. Variar arquitetura, relação texto–imagem, ritmo ou interação — não apenas paleta. Se o usuário autorizou escolher e concluir, selecionar a direção mais adequada sem exigir votação.

Ler [direction-anti-slop.md](references/direction-anti-slop.md) para greenfield, redesign expressivo ou quando houver risco de aparência genérica.

### 3. Estabilizar a verdade do projeto

Trabalhar com conteúdo real. Não inventar métricas, depoimentos, logos de clientes, selos, preços, estudos ou alegações. Quando conteúdo autoral for parte do pedido, distinguir copy de trabalho de fatos verificados.

Reutilizar o sistema existente antes de criar exceções. Se o projeto precisar de memória persistente e não houver fonte canônica:

- usar `PRODUCT.md` para público, proposta, tarefas e restrições duráveis;
- usar `WEB-DESIGN.md` para direção visual implementada, tokens, layout, motion, componentes e do/don'ts;
- não sobrescrever documentos existentes sem autorização; atualizar ou propor merge conforme o escopo.

### 4. Construir como sistema

Preservar semântica, comportamento, conteúdo aprovado e convenções do projeto. Implementar com componentes reutilizáveis e tokens sem transformar toda diferença em variante global.

Garantir:

- hierarquia e conteúdo antes de efeitos;
- tokens semânticos para cor, tipo, espaço, forma, elevação e motion;
- estados relevantes de interação, carregamento, vazio, erro, sucesso e indisponibilidade;
- comportamento responsivo estrutural, não apenas redução de fonte;
- teclado, foco visível, labels, nomes acessíveis e contraste adequado;
- imagens e ícones com função, qualidade e origem compatíveis;
- motion que comunica relação, feedback ou mudança de estado, com alternativa reduzida;
- desempenho proporcional ao valor perceptivo da técnica.

Ler [implementation-craft.md](references/implementation-craft.md) durante construção e [responsive-accessibility.md](references/responsive-accessibility.md) quando houver interface interativa ou múltiplos tamanhos.

### 5. Examinar a especificidade

Antes de considerar a página pronta, perguntar:

1. A macroestrutura decorre desta mensagem e desta tarefa ou é uma sequência habitual?
2. Cada escolha forte pertence ao mesmo sistema ou o resultado virou colagem de tendências?
3. Se logo e texto fossem trocados, a página serviria indiferentemente a qualquer negócio?
4. Há cards, pills, gradientes, glow, tipografia gigante, serif editorial, ícones genéricos ou animações apenas porque eram o caminho mais provável?
5. Remover decoração sem função melhora ou empobrece a ideia? Manter somente o que desempenha um papel.

Não proibir um recurso por associação com IA. Repetição aprovada é consistência; repetição indiferente ao conteúdo é problema. Descrever efeitos observáveis, nunca alegar detectar autoria artificial com certeza.

### 6. Revisar o website real

Sucesso de build não comprova qualidade de interface. Abrir e operar a experiência no navegador quando houver ferramenta disponível. Ler e aplicar [browser-qa.md](references/browser-qa.md).

No mínimo, verificar:

- rotas e estados materiais, inclusive erro, vazio e loading quando existirem;
- larguras de 320, 375, 414, 768 e uma largura desktop apropriada;
- navegação por teclado, foco, hover, active, disabled e reduced motion;
- conteúdo real, overflow, clipping, quebras, sobreposições, legibilidade e alvos de toque;
- consistência entre páginas e aderência ao design system conectado;
- console, erros de recursos e regressões funcionais relevantes.

Corrigir achados em um passe agrupado e confirmar em um segundo. Se a mesma falha persistir por três ciclos, mudar a abordagem ou explicitar o bloqueio. Sem inspeção visual, marcar o que não foi verificado e não chamar o material de pronto para publicação.

Quando houver arquivos web locais compatíveis, resolver o diretório desta skill e executar `python3 <diretório-da-skill>/scripts/web_preflight.py <caminho>` como apoio. O script é triagem, não substitui revisão humana, browser, axe/Lighthouse ou testes do projeto.

## Entrega

Entregar o formato solicitado e resumir:

- direção principal e como ela serve ao objetivo;
- design system conectado ou natureza provisória do sistema;
- dispositivos, estados e verificações realmente concluídos;
- limitações ou riscos materiais restantes.

Em auditoria, ordenar achados por impacto, localizar o problema e propor correção concreta. Não publicar, instalar dependências, enviar a terceiros ou alterar manuais de marca apenas por efeito desta skill.

Para origem da síntese, escolhas incorporadas e limites, ler [source-audit.md](references/source-audit.md). Para transformar feedback real em evolução segura, ler [learning-loop.md](references/learning-loop.md).


---

## Fonte: references/integration-design-system.md

# Integração com design systems

Use este protocolo quando houver skill de marca, design system, brand book, biblioteca de componentes, arquivo de tokens ou produto existente.

## Comandos de conexão

Forma recomendada para o usuário:

```text
$web-design-master + $design-system-da-marca — crie/redesenhe/audite [escopo]
```

Alternativa quando o sistema não é uma skill:

```text
CONNECT DESIGN SYSTEM: [pasta, arquivo, link ou nome da fonte canônica]
```

O sinal `+` significa colaboração com autoridades distintas, não fusão de identidades.

## Mapa de autoridade

| Tema | Autoridade primária |
|---|---|
| Objetivo, escopo, copy e dados aprovados | Pedido explícito e fontes do projeto |
| Logo, cores, fontes, iconografia e voz | Design system/skill da marca |
| Tokens e componentes existentes | Design system e código vigente |
| Arquitetura da página e fluxo | Web Design Master, respeitando produto e conteúdo |
| Estados, responsividade e acessibilidade | Web Design Master + requisitos do projeto |
| Convenções de implementação | Repositório, stack e ferramentas exigidas |
| Aprovação final | Usuário/equipe responsável; nunca presumida |

## Handshake de conexão

1. Identificar a fonte canônica e sua data/versão quando disponível.
2. Localizar logos, fontes, tokens, componentes, grid, fotografia, iconografia e exemplos aprovados/rejeitados.
3. Separar regras duras, padrões preferidos, exemplos e lacunas. Um exemplo não é regra global automaticamente.
4. Criar um mapa curto: `fonte → decisão afetada → status consultado/não encontrado`.
5. Resolver lacunas com princípios universais e decisões provisórias explicitadas. Não preencher com memória de outra marca.
6. No encerramento, dizer qual sistema foi conectado e o que não pôde ser verificado.

## Conflitos

Preservar a identidade sem sacrificar requisitos materiais. Tentar, nesta ordem:

1. variante oficial mais apropriada;
2. mudança permitida de fundo, tamanho, posição ou densidade;
3. componente oficial alternativo;
4. exceção proposta e explicitamente aprovada.

Não modificar logo, inventar tom, sintetizar peso de fonte ou criar cor “quase oficial” silenciosamente.

## Ausência de sistema

Criar um sistema provisório mínimo, derivado do briefing e da implementação real. Documentar:

- Creative North Star em uma frase específica;
- papéis semânticos de cor;
- famílias, papéis e escala tipográfica;
- grid, containers, espaçamento e breakpoints;
- forma, borda, elevação e tratamento de imagem;
- motion e reduced motion;
- componentes recorrentes com estados;
- do/don'ts confirmados pela direção.

Não preencher seções irrelevantes nem transformar uma decisão de uma página em lei global.

## Memória sem deriva

`PRODUCT.md` guarda verdade durável do produto; `WEB-DESIGN.md` descreve o sistema visual efetivamente implementado. Uma ficha de página guarda decisões locais. Não duplicar as três camadas.

Atualizar memória somente com fatos confirmados ou decisões que sobreviveram à implementação e à revisão. Não registrar “ficou bonito” como regra.


---

## Fonte: references/direction-anti-slop.md

# Direção e defesa contra aparência genérica

## Briefing que produz forma

Antes de nomear estilo, determine:

- o que a pessoa precisa entender, sentir e fazer;
- qual prova torna a promessa confiável;
- que objeto, ritual, linguagem ou tensão pertence a este assunto;
- o que a marca rejeita de forma confirmada;
- qual densidade e grau de expressão cabem ao contexto.

Adjetivos como “premium”, “moderno” e “clean” não constituem direção. Traduza-os em relações observáveis de tipo, espaço, imagem, cor, forma e comportamento.

## Três controles

Use valores de 1 a 10 como ferramenta interna, não como estética automática:

- **Variação estrutural:** 1 segue padrões familiares; 10 usa composição e navegação muito incomuns.
- **Intensidade de motion:** 1 quase estática; 10 coreografia dominante.
- **Densidade visual:** 1 muito espaçosa; 10 informação concentrada.

Ajuste por superfície. Um checkout pode pedir 2/2/5; um portfolio experimental, 8/7/4. O número não substitui justificativa.

## Variedade estrutural

Evite escolher apenas um tema e pintar a mesma página. Considere famílias de macroestrutura:

- manifesto editorial com prova intercalada;
- demonstração centrada no objeto/produto;
- narrativa progressiva ou scrollytelling;
- índice/arquivo navegável;
- split assimétrico com papéis diferentes;
- composição modular orientada a casos;
- jornada/timeline quando sequência é o argumento;
- utilitário task-first para produto.

Escolha a estrutura que melhor transporta conteúdo e ação. Não force novidade em tarefas que dependem de reconhecimento imediato.

## Autocrítica antes de implementar

Avalie:

- **Filosofia:** há uma ideia coerente ou só uma coleção de referências?
- **Hierarquia:** a ordem de atenção coincide com a prioridade da mensagem/tarefa?
- **Execução:** a direção cabe na stack, no conteúdo, no prazo e nos dispositivos?
- **Especificidade:** as escolhas revelam o assunto e a marca?
- **Restrição:** existe foco suficiente para que uma ideia domine?
- **Variedade:** a estrutura foi escolhida ou herdada por hábito?

Se duas dimensões forem fracas, refine a direção antes do código.

## Sinais de default a investigar

Não são proibições. Exigem função e coerência:

- hero centralizado seguido de três cards e CTA;
- excesso de containers arredondados e cards dentro de cards;
- gradiente de texto, glow e fundo roxo/azul como substitutos de identidade;
- serif editorial sobre creme com grain apenas para parecer sofisticado;
- brutalismo, bento grid ou glassmorphism sem relação com o conteúdo;
- tipografia gigante acompanhada de rótulos minúsculos e pouco legíveis;
- bibliotecas de ícones usadas como ilustração genérica;
- dashboards usados como decoração em sites de marketing;
- motion espalhado sem hierarquia ou causalidade;
- dados, logos e testemunhos fictícios.

## Gate de especificidade

Marque risco baixo, médio ou alto e descreva a combinação responsável. Risco alto bloqueia “pronto” quando a página poderia trocar de marca sem perda perceptível, quando o conteúdo foi moldado para caber no template ou quando a direção depende principalmente de clichês sem função.


---

## Fonte: references/surface-modes.md

# Registros de superfície

Escolha pelo trabalho que a pessoa está realizando, não pela indústria isoladamente.

## Brand: design carrega posicionamento

Adequado a landing pages, campanhas, portfolios, institucional e lançamentos.

- Estruture a narrativa em torno de promessa, prova, mecanismo e ação reais; não imponha uma fórmula fixa.
- Varie macroestrutura, ritmo, escala, imagem e silêncio dentro de uma gramática única.
- Defina um gesto autoral ligado ao assunto: composição, navegação, imagem, tipo ou interação. Uma coleção de efeitos não substitui uma ideia.
- O primeiro viewport deve estabelecer hierarquia e caráter, não necessariamente centralizar headline, subtítulo e dois botões.
- Evite provas inventadas, faixas de logos fictícios, estatísticas sem fonte e testemunhos genéricos.

## Product: design serve à tarefa

Adequado a SaaS autenticado, dashboard, admin, checkout, ferramentas e fluxos com estado.

- Familiaridade pode ser virtude. Originalidade não deve tornar controles padrão estranhos.
- Modele primeiro objetos, tarefas, prioridades, navegação e estados; estilize depois.
- Considere default, hover, focus-visible, active, selected, disabled, loading, empty, error e success quando relevantes.
- Em layout responsivo, transforme estrutura: colapse navegação, priorize colunas, adapte tabelas e preserve ações críticas.
- Empty states ensinam a próxima ação. Loading preserva estrutura. Erros dizem o que ocorreu e como recuperar.
- Motion comunica mudança de estado e causalidade; em geral, 150–250 ms basta para controles frequentes.

## Read: design serve à compreensão

Adequado a documentação, artigos, relatórios web, bases de conhecimento e narrativas longas.

- Priorize medida de linha, contraste, ritmo vertical, navegação e posição de leitura.
- Sumário, âncoras, busca, notas, tabelas e código precisam funcionar com teclado e mobile.
- Use tipografia expressiva onde ela orienta, não onde compete com a leitura.
- Imagens, gráficos e destaques devem acrescentar informação, não quebrar texto apenas para ornamentar.

## Experiências híbridas

Uma home pode ser Brand e o app Product. Compartilhe identidade e tokens fundamentais, mas permita densidade, composição e motion próprios de cada registro. Não transforme dashboard em campanha nem landing page em grade de widgets.
