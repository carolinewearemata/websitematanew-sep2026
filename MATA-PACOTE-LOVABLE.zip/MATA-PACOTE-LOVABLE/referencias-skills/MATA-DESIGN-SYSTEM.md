# Referência oficial para consulta

Cópia dos textos consultados. Não é uma skill instalada no Lovable. Instruções explícitas de Caroline prevalecem. Caminhos relativos abaixo pertencem à organização original; os assets selecionados estão no pacote e as orientações de implementação estão nos arquivos 02 a 07.


---

## Fonte: SKILL.md

---
name: mata-design-system
description: Cria, adapta e revisa materiais visuais da MATA usando a identidade oficial, incluindo apresentações, documentos, interfaces, redes sociais e imagens. Use quando uma entrega for da marca MATA; não aplique suas regras a clientes da MATA ou a outras marcas.
---

# MATA Design System

Use este pacote como fonte operacional da identidade visual da MATA. Preserve texto aprovado, dados, formato e instruções explícitas do pedido. Não aplique automaticamente a estética da MATA a Touch Health, Terra Molhada ou qualquer cliente.

## Antes de criar

1. Confirme que a entrega pertence à marca MATA.
2. Defina público, mensagem principal, ação desejada, canal, dimensões e conteúdo obrigatório a partir do contexto disponível.
3. Consulte [Fundamentos](references/01-fundamentos.md) e [Identidade visual](references/02-identidade-visual.md).
4. Para interfaces, consulte [Layout e componentes](references/03-layout-e-componentes.md). Para imagens, consulte [Direção de arte](references/04-direcao-de-arte-e-imagens.md). Para apresentações, documentos ou redes sociais, consulte [Formatos](references/05-formatos.md).
5. Use os logos incluídos em `assets/logos-png/` ou `assets/logos-svg/`. Quando houver acesso ao Drive, verifique a fonte oficial vinculada em [Identidade visual](references/02-identidade-visual.md). Não redesenhe nem regenere o logo.

## Princípios de decisão

- Trate a identidade como tecnologia orgânica: viva, modular, translúcida e precisa.
- Mantenha a maior parte da composição clara, neutra e respirável.
- Use holografia, vidro, iridescência e verde luminoso como materiais ou pontos de luz, não como decoração constante.
- Faça a comunicação parecer inteligente e experimental, sem cair em linguagem corporativa genérica, luxo ostensivo, rusticidade, sustentabilidade literal ou cyberpunk.
- Faça a tipografia e a hierarquia resolverem a comunicação antes de acrescentar efeitos.
- Em capas, heros, aberturas e peças de impacto, considere tipografia deliberadamente grande e estourada: palavras podem sangrar, ultrapassar o quadro ou ser parcialmente cortadas quando a leitura principal continuar inequívoca. Não reduza automaticamente o título para fazê-lo caber de forma convencional.
- Se trocar o logo e o texto faria a peça servir para qualquer empresa, procure uma decisão mais específica à MATA.

Use `assets/ELEMENTOS VISUAIS/` como repertório de formas que podem ser aplicadas diretamente ou reinterpretadas. A biblioteca é uma rota visual, não um conjunto fechado: novos elementos podem ser construídos quando preservarem sua lógica formal. Para fundos expressivos, consulte `assets/gradientes/` antes de reconstruir o gradiente.

## Revisão obrigatória

Revise a saída final renderizada, não apenas o arquivo-fonte. Use [QA visual](references/06-qa-visual.md) para verificar hierarquia, legibilidade, marca, imagens, acabamento e formato. Classifique o resultado como aprovado nos itens verificados, precisa de correção ou não verificado. Não declare uma peça pronta quando a renderização final não foi inspecionada.

## Evolução do sistema

Decisões novas só entram no sistema quando houver aprovação explícita ou evidência recorrente. Registre-as em [Governança e aprendizados](references/07-governanca-e-aprendizados.md), separando regra aprovada, hipótese em teste e aprendizado localizado. Não transforme uma preferência de uma peça em regra universal.


---

## Fonte: references/01-fundamentos.md

# Fundamentos da marca

## Ideia central

A MATA combina pessoas, inteligência artificial, sistemas e especialistas para assumir a função de marketing de forma próxima ao negócio. Sua expressão visual deve traduzir uma organização viva: capaz de aprender, conectar partes, criar estrutura e evoluir sem perder clareza.

## Conceito visual

**Tecnologia orgânica** é o território principal. A natureza entra como estrutura e comportamento — células, membranas, raízes, micélio, enxertos, redes e organismos modulares — nunca como símbolo genérico de sustentabilidade.

## Personalidade

- inteligente, não corporativa;
- sofisticada, não luxuosa;
- experimental, mas utilizável;
- orgânica, não rústica;
- tecnológica, não cyberpunk;
- leve, respirável e editorial;
- humana + IA, sem clichês evidentes de inteligência artificial.

## Princípios

### Sistema vivo

A geometria oficial do logo permanece estável. Material, luz, textura, escala e composição podem evoluir dentro de regras coerentes.

### Natureza como estrutura

Boas referências incluem membranas, ramificações, enxertos, pétalas abstratas, organismos modulares, superfícies biológicas translúcidas e estruturas que se conectam ou se recombinam.

Evite florestas literais como fundo institucional, mãos segurando plantas, planeta, reciclagem e códigos visuais de consultoria ESG.

### Material, não efeito

Gradiente, vidro, cromo e holografia devem parecer luz ou matéria com comportamento físico. Não aplique efeitos prontos indiscriminadamente.

### Clareza antes de expressão

O conteúdo precisa ser entendido antes que a camada expressiva seja percebida. Em materiais densos, deixe a interface ou página neutra e use a marca como pontuação.

### Especificidade

Uma entrega da MATA deve nascer de sua mensagem e de seu contexto. Evite composições que funcionariam igualmente para qualquer startup depois de trocar logo e texto.


---

## Fonte: references/02-identidade-visual.md

# Identidade visual

## Logos oficiais

Use primeiro as cópias portáteis em `assets/logos-png/` e `assets/logos-svg/`. Quando houver acesso ao Drive, confira a [fonte oficial atual](https://drive.google.com/drive/folders/1d6wq8ePKAKTVnLvvy8wBGM8hfkqzFAfp) para saber se existe versão mais recente.

Existem duas composições oficiais — horizontal e vertical — e cinco tratamentos: preto, branco, gradiente, verde e vidro. Os arquivos estão disponíveis em AI, PDF, PNG e SVG.

- Use preto ou branco em aplicações funcionais, pequenas ou densas.
- Use gradiente em capas, heros, lançamentos e momentos expressivos.
- Use vidro somente quando o logo estiver grande o suficiente para o material ser percebido.
- Use o verde fornecido no ativo oficial; não reconstrua sua cor a partir de tokens antigos.
- Não distorça, redesenhe, regenere, aplique sombra direta ou use o logo anterior em materiais novos.

Tamanhos mínimos de trabalho: horizontal preto/branco 28 px; horizontal gradiente/vidro 40 px; vertical preto/branco 48 px; vertical gradiente/vidro 64 px.

## Paleta neutral-first

| Token | Valor | Função |
|---|---|---|
| `mata.canvas` | `#F1F2F4` | fundo principal |
| `mata.surface` | `#FFFFFF` | cartões e superfícies |
| `mata.silver` | `#D8DDE1` | bordas e campos suaves |
| `mata.lavenderGray` | `#AEB3C7` | acento frio e dados |
| `mata.ice` | `#DEE5EB` | atmosfera e superfície secundária |
| `mata.paleMint` | `#B0E6D8` | destaque suave |
| `mata.signalMint` | `#00F0A9` | energia e atenção, com parcimônia |
| `mata.ink` | `#171C1B` | texto e ação escura |
| `mata.mutedInk` | `#6F7777` | texto secundário |
| `mata.border` | `#DDE2E4` | borda padrão |
| `mata.legacyForest` | `#0E4333` | apoio opcional/legado |

Proporção de referência: 70–80% neutros claros; 10–20% prata, lilás ou menta pálida; 5–10% menta brilhante ou holografia; 0–5% verde-escuro.

## Gradiente

```css
--mata-holo: linear-gradient(120deg,
  #AEB3C7 0%, #D8DDE1 22%, #F1F2F4 43%,
  #B0E6D8 62%, #00F0A9 78%, #DEE5EB 100%);
```

O menta brilhante deve funcionar como reflexo ou ponto de luz. Evite faixas de arco-íris e fundos inteiramente saturados.

O arquivo visual de referência está incluído em `assets/gradientes/[MATA] Referência de fundo - gradiente 01.png`. Use-o diretamente quando a aplicação permitir ou como evidência para reproduzir a mesma atmosfera em outras dimensões. Não substitua essa referência por um arco-íris genérico.

## Tipografia

Fonte principal: **Stack Sans Variable**, disponível em `assets/fonts/`, quando a licença e a implementação permitirem. Fallback digital: `"Helvetica Neue", Arial, sans-serif`.

Escala inicial: Display XL 64/68; Display L 48/52; H1 36/42; H2 28/34; H3 22/28; Body L 18/28; Body 16/24; Body S 14/20; Label 12/16.

- Display: peso 300–450, grande e respirável.
- Título de interface: 500–600, compacto e funcional.
- Corpo: 400, com entrelinha generosa.
- Labels: 500 e contraste suficiente.

### Tipografia de impacto

Tipografia grande e estourada é uma expressão desejada da MATA em momentos editoriais e de alto impacto. Títulos podem ocupar grande parte da tela, sangrar nas bordas, ultrapassar o quadro ou apresentar cortes intencionais. Preserve ao menos a leitura essencial da mensagem, o contraste e o ritmo da composição. Use esse recurso em capas, heros, aberturas, campanhas e frases-manifesto; não o aplique automaticamente a tabelas, formulários ou conteúdo funcional.

## Formas e materiais

Raios funcionais: 8, 12, 18, 24 e 32 px; use pílula apenas quando semanticamente adequada.

Camada expressiva: formas de membrana, loops, tubos conectados, anéis transparentes, pétalas abstratas e módulos assimétricos. Materiais principais: holográfico/iridescente, vidro refrativo, metal translúcido polido e neutro fosco.


---

## Fonte: references/03-layout-e-componentes.md

# Layout e componentes digitais

## Composição

- Trabalhe com uma mensagem dominante, uma camada de sustentação e detalhes somente quando existirem.
- Use bastante espaço negativo e margens consistentes.
- Prefira grids claros com assimetria deliberada a composições centralizadas por padrão.
- Mantenha linhas de texto confortáveis e hierarquia tipográfica evidente.
- Antes de adicionar formas ou efeitos, verifique se tamanho, peso, alinhamento e proximidade já resolvem a leitura.

## Escala tipográfica expressiva

Em peças de impacto, trate a tipografia como arquitetura. Uma palavra ou frase curta pode dominar a tela, atravessar colunas, sangrar lateralmente ou ser recortada pela borda. O corte deve parecer deliberado e não pode eliminar a compreensão da mensagem central. Equilibre a massa tipográfica com espaço negativo e elementos menores de orientação. Em telas responsivas, adapte o corte em cada proporção em vez de apenas reduzir a mesma composição.

## Shell digital

Fundo `#F1F2F4`, superfície `#FFFFFF`, texto principal `#171C1B`, texto secundário `#6F7777`, borda `#DDE2E4`, estado suave `#B0E6D8`, estado forte `#00F0A9` e botão principal `#171C1B` com texto branco.

## Componentes

### Cartões

Superfície branca, borda neutra de 1 px, raio de 18–24 px, sombra mínima ou ausente e espaçamento interno generoso. Use tratamento holográfico apenas em um cartão ou estado especial.

### Botões

- Primário: fundo quase preto, texto branco.
- Secundário: branco ou transparente, borda neutra.
- Especial: holográfico apenas em momentos excepcionais.
- Destrutivo: vermelho semântico acessível.

### Inputs

Superfície neutra, borda de 1 px, raio de 12 px e foco em menta com contraste acessível. Evite sombras internas pesadas.

### Tabelas e dashboards

Mantenha a base neutra. Use menta para estados ativos, selecionados ou métricas prioritárias. Comece séries com prata, cinza-lilás e menta pálida. Não use cabeçalho verde-escuro como padrão.

### Status

Pendente: prata/lilás; em andamento: menta pálida; concluído: menta com texto escuro; erro: vermelho semântico; informação: azul-gelo ou neutro. Nunca dependa apenas de cor.

## Movimento

Transições funcionais de 180–260 ms. Em áreas expressivas, deriva lenta de gradiente, refração suave e morfologia orgânica em ciclos de 4–12 s. Evite bounce intenso, elasticidade exagerada e elementos flutuando constantemente.

## Acessibilidade

Texto de corpo deve cumprir WCAG AA. Não use cinza claro sobre holografia, movimento atrás de texto denso ou logo expressivo quando preto/branco tiver melhor contraste.


---

## Fonte: references/04-direcao-de-arte-e-imagens.md

# Direção de arte e imagens

## Linguagem principal

Use CGI editorial ou fotografia/3D de alto acabamento, com fundo claro, um objeto protagonista e espaço negativo. A morfologia deve parecer orgânica e tecnológica ao mesmo tempo, sem ser uma ilustração literal da natureza.

Materiais: vidro, pérola, cromo translúcido, prata-lilás e iridescência com reflexos de menta. Sombras e reflexos devem ser sutis e fisicamente críveis.

## Metáforas úteis

- núcleo ou centro do organismo;
- enxerto ou parte especializada acoplada;
- rede ramificada;
- membrana ou filtro;
- células modulares;
- conexão semelhante a micélio;
- estrutura de apoio;
- loop vivo;
- interface entre dois sistemas.

## Prompt-base

Minimal editorial 3D CGI in the MATA visual language. Organic futuristic form inspired by biological structures, membranes, petals, roots or modular living systems, without literal sustainability symbolism. Holographic and iridescent glass material with silver, soft lilac, pale mint and restrained bright mint reflections. Light neutral background, generous negative space, subtle realistic shadows and reflections, sophisticated art direction, soft studio lighting, premium contemporary design, no text, no eco icons, no forest, no hands holding plants, no cyberpunk, no loud rainbow colors.

Acrescente depois o conceito específico da peça, o enquadramento e a proporção.

## Evite

Banco de imagem de sustentabilidade, cérebros brilhantes, robôs, circuitos, HUDs, neon cyberpunk, fundo preto automático, arco-íris saturado, verde dominando o quadro e excesso de objetos.

## Inspeção

Confira recorte, proporção, halos, anatomia, conexões incoerentes, texto deformado, ruído e nitidez no tamanho final. Upscale não comprova recuperação de detalhes. Não declare uma imagem achatada como editável.


---

## Fonte: references/06-qa-visual.md

# QA visual

Revise a saída final no tamanho e no formato de uso.

## Conteúdo

- A mensagem principal é compreendida rapidamente?
- Texto aprovado, dados, nomes e condições permanecem exatos?
- Existe uma ação ou conclusão clara quando necessária?

## Hierarquia e composição

- A ordem de leitura é inequívoca?
- Margens, alinhamentos, entrelinhas e espaçamentos formam um ritmo coerente?
- Há tangências, viúvas, quebras ruins, acentos cortados ou elementos quase alinhados?
- A decoração tem função ou pode ser retirada?

## Marca

- O logo é oficial, está proporcional e tem contraste?
- Cores, tipografia, materiais e formas pertencem ao sistema da MATA?
- A peça continua específica à MATA quando comparada a visuais genéricos de startup/IA?
- A tecnologia orgânica aparece sem símbolos literais de sustentabilidade?

## Imagem

- Resolução, recorte, luz, sombra e material funcionam no tamanho final?
- Há halos, artefatos, texto deformado, anatomia ou objetos incoerentes?
- A imagem acrescenta significado em vez de preencher espaço?

## Acessibilidade e formato

- Texto e controles têm contraste adequado?
- Estados não dependem somente de cor?
- Nada essencial está fora da área segura, cortado ou pequeno demais?
- Todas as páginas, quadros ou variações foram inspecionados?

## Resultado

- **Aprovado nos itens verificados:** critérios materiais atendidos na saída renderizada.
- **Precisa de correção:** falha observável com correção proposta.
- **Não verificado:** não houve acesso à renderização, ao ativo oficial ou ao contexto necessário.

Depois de corrigir, renderize novamente a área afetada e confira o conjunto quando estilos compartilhados tiverem mudado.
