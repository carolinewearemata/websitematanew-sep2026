# MATA — Direção estratégica do novo website

Preparado para Caroline Miranda Martha • 13 de setembro de 2026 • Versão de trabalho para implementação no Lovable

Este documento traduz a pesquisa em decisões de conteúdo, arquitetura e experiência. A copy proposta está no arquivo 03; as instruções de execução estão nos arquivos 01, 04 e 05. É um briefing fundamentado, não uma declaração de que o novo website já foi implementado ou testado.

## 1. A decisão central

A MATA deve ser apresentada como **Infraestrutura de Marketing Acoplável**: um time de pessoas e um time de IA que se conectam ao negócio para conduzir marketing, da escolha de prioridades à execução acompanhada.

O visitante precisa concluir: “Minha empresa pode passar a contar com uma estrutura que assume esse trabalho, entende o negócio e faz as partes funcionarem juntas.” Essa compreensão deve surgir antes de nomes de métodos, listas de competências ou explicações institucionais.

A percepção de martech virá de quatro evidências: uma infraestrutura reconhecível; tecnologia participando do trabalho; uma operação explicável; e responsabilidade humana clara. A identidade visual deve dar forma a essa proposta. O site não deve criar a expectativa de uma assinatura de software que o próprio comprador precisará configurar e operar.

### Nome da categoria e linguagem pública

| Formulação | Papel recomendado | Razão |
|---|---|---|
| Infraestrutura de Marketing Acoplável | Categoria principal em português | Torna a oferta mais acessível a quem não trabalha com marketing e preserva a lógica central do acoplamento. |
| Infraestrutura de Brand Marketing Acoplável | Definição aprofundada e contextos especializados | Explicita a centralidade da marca, mas aumenta o esforço de interpretação. |
| Brand Marketing Infrastructure | Assinatura institucional possível | Mantém o território internacional, porém não explica sozinha a característica acoplável. |
| Pluggable Brand Marketing Infrastructure | Categoria recomendada em inglês | Preserva o acoplamento na tradução. Exige revisão editorial da versão completa em inglês. |
| Brand marketing, built in. | Assinatura expressiva, conforme referência enviada | É uma síntese de marca; precisa estar acompanhada da explicação do modelo. |
| Martech | Enquadramento institucional | Útil para descrever o tipo de empresa, sem impor ao comprador um novo termo como requisito de compreensão. |

Recomendação: usar uma categoria principal consistente. Não alternar cinco definições na mesma jornada. “Brand” continua presente no conteúdo: posicionamento, percepção de valor, narrativa, coerência e implantação da marca.

### O significado de acoplável

Acoplar é conectar uma capacidade de trabalho à realidade de uma empresa que já existe. Envolve aprender o negócio, reconhecer suas relações e prioridades, combinar responsabilidades e colocar a estrutura para trabalhar nesse contexto. O visual de encaixe deve expressar essa conexão.

O acoplamento não é instantâneo: precisa de acesso às pessoas e informações relevantes. Tampouco significa tomar decisões de negócio sem a liderança. O benefício é reduzir a necessidade de a liderança reconstruir contexto, organizar cada passagem e cobrar todo próximo passo.

“Acoplável” descreve a capacidade de conexão. “Acoplada” descreve a estrutura em funcionamento. “Incorporada” pode explicar a proximidade, mas não deve substituir a palavra central em todos os pontos.

## 2. O comprador e as três situações de entrada

Há um público prioritário e uma segunda família de necessidades. Não são três públicos equivalentes.

### Prioridade 1 — Negócio relevante, marketing ainda sem estrutura

Empresa com produto ou serviço validado, clientes, operação e trajetória, mas sem ninguém de marketing ou sem uma função capaz de conduzir o conjunto. O comprador provável é fundador, CEO, sócio ou liderança comercial/operacional. São papéis de trabalho para orientar a arquitetura, não personas validadas por entrevistas nesta pesquisa.

O que pode estar acontecendo: decisões de marketing voltam para a liderança; fornecedores recebem partes do contexto; o produto só é bem explicado em uma reunião; o site não acompanha a oferta; iniciativas param quando a agenda aperta.

O que precisa ver: o que a MATA assume, quem conduzirá o trabalho, como começa, que participação continua sendo necessária, como prioridades e capacidade são combinadas e o que ficará funcionando.

### Prioridade 2A — O negócio avançou, a marca ficou para trás

Empresa cuja capacidade, portfólio, mercado ou ambição mudou. Precisa descobrir como tornar essa evolução compreensível e crível para o comprador.

O que precisa ver: leitura do negócio antes de identidade visual, preservação do que gera confiança, investigação de público e oferta, decisões de posicionamento, tradução em comunicação e plano de implantação.

### Prioridade 2B — O reposicionamento foi aprovado, mas não entrou em uso

A direção de marca pode ter sido construída pela própria empresa ou por outro parceiro. Falta conectá-la ao site, aos materiais, ao comercial, ao conteúdo e às decisões cotidianas.

O que precisa ver: a MATA pode começar pela direção existente, verificar o que ela resolve e organizar a implantação. Não presumir que será necessário refazer todo o branding para poder ajudar.

### Qualificação sem elitismo

Falar de negócio validado, necessidade recorrente, complexidade, acesso e vontade de dar continuidade. Não inventar corte mínimo de faturamento, número de colaboradores, investimento ou setor. O briefing atual não autoriza fechar a oferta exclusivamente em B2B. Usar exemplos B2B e B2B2C quando houver evidências, com filtro por situação de negócio.

Evitar “empresas sem marketing” como sinônimo de empresas atrasadas. Muitas cresceram por produto, serviço, reputação e relações comerciais. A estrutura passa a ser necessária em um novo momento.

## 3. Perguntas que o site precisa responder

| Pergunta do visitante | Resposta que o site deve oferecer | Onde |
|---|---|---|
| Isso serve para uma empresa como a minha? | Reconhecimento das três situações, com prioridade visual para a primeira | Hero e entradas da home |
| O que estou contratando? | Infraestrutura acoplável, com pessoas, IA e condução do trabalho | Home e Como funciona |
| Vou ter que gerenciar mais um fornecedor? | Responsável, prioridades, acompanhamento e participação da liderança | Demonstração e FAQ |
| É uma ferramenta que eu preciso aprender a usar? | A equipe MATA opera a tecnologia que sustenta o trabalho | Bloco humano + IA |
| O que vocês fazem de concreto? | Exemplos de decisões e desdobramentos em marca, site, comercial e conteúdo | Como funciona e páginas de entrada |
| Vocês entendem meu negócio? | Forma de investigação e evidência de trabalhos reais | Método, Sobre e casos |
| Preciso refazer minha marca? | Diagnóstico distingue direção, expressão e implementação | Reposicionamento |
| Já temos estratégia. Vocês colocam em prática? | Entrada específica para implantação | Implantar posicionamento |
| O que continua comigo? | Direção de negócio, orçamento e decisões reservadas | Responsabilidades e FAQ |
| Quanto custa e como dimensiona? | Explicação da capacidade e das condições a combinar, sem valores inventados | Como funciona e Contato |
| Por que confiar? | Casos contextualizados, pessoas identificadas e trabalho verificável | Prova e Sobre |
| Qual o próximo passo? | Conversa sobre a empresa, com contexto suficiente para começar | CTA e Contato |

## 4. O que a pesquisa mudou na proposta

### MATA Positioning

Reforça leitura profunda do negócio, iniciativa, continuidade depois da entrega, estrutura flexível e alívio de coordenação para a liderança. Também contém hipóteses, versões históricas, condições comerciais divergentes e debates internos. Não é uma especificação única pronta para ser copiada.

Aplicação: aproveitar os mecanismos que tornam a promessa compreensível; retirar do texto público afirmações absolutas e decisões antigas conflitantes. A orientação desta conversa sobre acoplamento, público e percepção de martech prevalece sobre rascunhos anteriores.

### Diagnóstico do site e Arquitetura e copy v0.1

Os dois documentos acertam ao mudar a hierarquia: situação do negócio, modelo, mecanismo, efeito e prova. A nova proposta preserva isso e faz quatro ajustes: explicita o acoplamento; diferencia implantação de reposicionamento; inclui Blog literalmente no menu; e torna a home mais seletiva, deixando o aprofundamento para rotas específicas.

Não recomendo implementar toda a home com conteúdo que muda ao selecionar uma persona. Isso dificulta comparar entradas e pode esconder informação importante. Links claros para páginas específicas tornam as alternativas legíveis e compartilháveis.

### Produtos internos + IA

O insight mais relevante é a distinção entre comprador e operador. A empresa compra capacidade de condução; a equipe MATA opera a tecnologia. O documento diferencia uso real de IA, práticas em consolidação, protótipos e propostas de produtos.

Aplicação: apresentar a participação atual de pessoas e IA e demonstrar o fluxo de trabalho. Não anunciar MATA Projects, MATA Ecosystem, MultiCA ou um Brand OS completo como produtos disponíveis sem validação operacional. Não transportar metas de piloto, cenários, custos internos ou hipóteses de margem para o site.

### Os três artigos localizados na pasta Blog e Artigos

| Artigo | Autoria indicada na fonte | Aprendizado para o website |
|---|---|---|
| Produzir marketing não é conduzir marketing | Caroline Miranda Martha | O valor está também no trabalho que antecede e sucede a produção. “Coordenação devolvida” ajuda a entender a dor, mas precisa de uma cena concreta no site. |
| Como estruturar a área de marketing quando a empresa já cresceu | Time da MATA | Organizar problema, responsabilidade e capacidade antes de contratar canais e profissionais. Autonomia depende de acesso e mandato. |
| O reposicionamento foi aprovado? Sim. E agora? | Caroline Miranda Martha | A nova marca é testada em propostas, páginas e conversas reais. Implementação é uma necessidade própria. |

A voz é próxima, observadora e capaz de explicar tensões sem simplificações falsas. A home deve ser mais curta do que os artigos; o Blog preserva o argumento desenvolvido e a autoria correta.

### Presença digital, Estratégia editorial e Mapa de demanda

Contribuem com uma ponte entre linguagem de busca e categoria própria. As páginas comerciais respondem à decisão de contratar. O blog responde a dúvidas, diagnósticos e comparações. As prioridades de busca são hipóteses de aderência ao público, não volumes medidos nesta tarefa.

## 5. Diagnóstico independente do site em produção

Site inspecionado: [wearemata.co/pt](https://wearemata.co/pt). A abertura pela raiz levou a /en nesta sessão; foi possível mudar para português. Foram lidas as seis rotas do menu em português e a home em inglês. Foram operados os sete movimentos de Como funciona, a troca de idioma e o menu mobile.

Inspeção visual: home, funcionamento, resultados e contato em desktop; home, contato e navegação em viewport de 375 × 812. É uma avaliação de conteúdo e experiência por amostragem. Não houve envio de formulários, teste de recebimento, acesso a analytics ou medição de Core Web Vitals.

| Achado | Consequência | Mudança recomendada |
|---|---|---|
| A primeira dobra diz o que a MATA é, mas não identifica o comprador nem explica pessoas + IA | O visitante precisa rolar para reconhecer a pertinência | Público, composição e ação disponíveis no início |
| “Time completo ou segunda camada” aparece logo na home e no funcionamento | Duas promessas competem com o foco comercial | Priorizar a estrutura para quem precisa assumir a função; tratar exceções em conversa |
| Posicionamento & Assets, Desdobramentos & Aplicações, Manifestações & Eventos organizam a oferta | A leitura se aproxima de uma coleção de serviços | Organizar por responsabilidade e situações de negócio |
| Blocos de dados de mercado aparecem antes da prova própria | O visitante recebe uma justificativa genérica antes de evidência da MATA | Subir um caso validado ou uma demonstração identificada |
| As formas translúcidas são recorrentes, mas não explicam relações com precisão | O visual sugere tecnologia sem mostrar o acoplamento | Dar rótulos, função e sequência ao gesto de conexão |
| A home mobile tem grande intervalo antes da mensagem e a explicação está abaixo | Usa o espaço inicial sem esclarecer o modelo | Reduzir a altura mínima do hero; texto essencial antes da imagem secundária |
| O CTA atual é longo e recebe leitura pequena no celular | A ação perde legibilidade | “Conversar sobre minha empresa” ou “Ver como funciona” |
| Como funciona abre com H2 na árvore observada | A hierarquia editorial da rota pode ser mais clara | Um H1 descritivo por rota, com movimentos em níveis subsequentes |
| O menu português mistura HOME e STORY e não tem Blog | Navegação menos direta para esse comprador e ausência da entrada editorial | Rótulos em português e Blog explícito |
| O nome acessível do botão mobile é “Toggle menu” | Há um detalhe de idioma a corrigir | “Abrir menu” / “Fechar menu”, com estado expandido |
| Resultados usa “Em apenas 7 meses” | O enquadramento envelhece e privilegia volume/velocidade | Casos com período, contexto e transformação |
| Caso de imprensa anuncia 35; detalhamento mostra 6 + 24 + 1 | O detalhamento não explica quatro inserções | Conciliar contagem, período, deduplicação e categorias |
| Caso da holding usa aproximadamente US$ 80M de ARR | O indicador precisa de definição e autorização | Verificar se se trata de receita anual ou receita recorrente anual e se pode ser publicado |
| “Tudo que a gente constrói fica na sua marca” inclui agentes e sistemas | Pode conflitar com a tese de produtos internos da MATA | Definir entregáveis da marca, registros e infraestrutura reutilizável separadamente |

O formulário e os canais diretos estão visíveis. O e-mail publicado é hello@wearemata.company; o domínio de e-mail não deve ser trocado para .co por suposição. O WhatsApp observado está documentado no pacote de implementação. A leitura desses links não comprova recebimento.

## 6. Arquitetura recomendada

### Navegação principal

**Como funciona · Para sua empresa · Evoluções · Sobre · Blog · Conversar sobre minha empresa**

“Para sua empresa” abre três links: Estruturar marketing, Reposicionar a marca, Implantar o posicionamento. No celular, uma lista expansível com os mesmos destinos. O logo retorna à home. A nova versão nasce em português; inglês só será adaptado depois de a experiência PT estar afinada, conforme decisão de Caroline. Inventariar rotas inglesas existentes sem traduzir ou anunciar equivalência agora. Nenhum seletor deve levar a uma tradução nova inexistente.

“Evoluções” entra na navegação pública quando houver ao menos um caso preparado para publicação. A estrutura da página e dos casos fica pronta em rascunho. Não mostrar uma página vazia nem inventar resultados para preencher o menu.

“MATAthinking” é o nome do pensamento e dos princípios. Fica em Sobre, no rodapé e conectado ao Blog. Não substitui o rótulo Blog que Caroline pediu explicitamente.

### Rotas

| Rota sugerida | Trabalho da página | Prioridade |
|---|---|---|
| /pt | Reconhecer situação, compreender oferta e avançar | Lançamento |
| /pt/how-it-works | Explicar acoplamento, pessoas + IA, capacidade, responsabilidade e início | Lançamento; preservar endereço existente |
| /pt/estruturar-marketing | Converter a principal situação de compra | Lançamento |
| /pt/reposicionamento | Explicar mudança de direção e sua implantação | Lançamento |
| /pt/implementar-posicionamento | Receber quem já tem estratégia aprovada | Lançamento |
| /pt/results | Biblioteca de evoluções reais | Preparar; publicar com evidência |
| /pt/results/[slug] | Um caso completo e compartilhável | Conforme documentação |
| /pt/story | Origem, fundadora, visão e modo de construir a empresa | Lançamento; rótulo Sobre |
| /pt/principles | MATAthinking e princípios operacionais | Preservar e atualizar |
| /pt/contact | Dar contexto e iniciar uma conversa | Lançamento |
| /pt/blog | Índice editorial no site; /blog se a arquitetura final dispensar prefixo de idioma | Recomendação atual de publicação; endereço final a fechar |

Manter as rotas atuais quando isso evita migrações desnecessárias. Se os slugs forem traduzidos, criar redirecionamentos individuais para seus equivalentes e atualizar links internos. Não redirecionar todas as páginas antigas para a home.

### Jornada principal

```mermaid
flowchart TD
    A[Home: reconheço meu momento] --> B[Entendo a infraestrutura acoplável]
    B --> C[Vejo pessoas e IA trabalhando]
    C --> D[Encontro prova ou exemplo identificado]
    D --> E[Converso sobre minha empresa]
    A --> F[Estruturar marketing]
    A --> G[Reposicionar a marca]
    A --> H[Implantar uma direção aprovada]
    F --> E
    G --> E
    H --> E
    I[Artigo do Blog] --> F
    I --> G
    I --> H
```

### A home em oito blocos

1. **Oferta e reconhecimento:** categoria, mensagem central, pessoas + IA, público e dois caminhos de ação.
2. **Situação de entrada:** um bloco de maior peso para estruturar marketing; dois caminhos relacionados à marca.
3. **Prova curta:** um caso validado com contexto; enquanto não existir, exemplo ilustrativo identificado de como o trabalho se conecta.
4. **Acoplamento em funcionamento:** demonstração de um problema passando por contexto, decisão, execução e revisão.
5. **Pessoas + IA:** divisão de trabalho, responsável humano e benefício para quem contrata.
6. **O que muda para a liderança:** continuidade, clareza e espaço mental, com mecanismos concretos.
7. **Pensamento e leituras:** três artigos escolhidos pelas perguntas que respondem.
8. **Conversa e dúvidas essenciais:** CTA, expectativa do próximo passo e acesso ao aprofundamento.

Não repetir um longo “Como funciona” depois de uma demonstração que já explica o ciclo. A home oferece a compreensão necessária; a rota específica responde às objeções de contratação.

## 7. Direção visual: o acoplamento como linguagem

### Referências diretamente fornecidas por Caroline

A imagem “Brand marketing, built in.” comunica uma capacidade inserida em um fluxo. A capa provisória mostra um módulo MATA ligado a estruturas vizinhas por conexões translúcidas. A segunda é a referência principal para a lógica espacial; a primeira, para síntese verbal e conexão entre matéria e tipografia.

Usar as imagens como evidência de direção. Não aplicar uma capa inteira como fundo com texto adicional por cima: isso prejudica adaptação, leitura e repetição. Construir a composição com texto real e elementos visuais separados. O logotipo aplicado no novo site deve vir dos arquivos oficiais atuais, mesmo quando uma referência incorpora uma versão anterior.

### Conceito escolhido

**A estrutura da empresa recebe uma capacidade de marketing e passa a trabalhar conectada a ela.**

No hero, uma composição assimétrica: mensagem dominante à esquerda; estrutura modular à direita ou atravessando a borda do bloco sem cobrir o texto. Um módulo MATA se conecta ao negócio. Não colocar a MATA como dona de vendas, produto e operação: as conexões representam troca de contexto, não hierarquia sobre todas as áreas.

Ao avançar, a composição se torna uma explicação: uma pergunta que vem do comercial, um ponto de decisão, um material em uso e o retorno dessa experiência. É o mesmo vocabulário formal com mais informação, em vez de diferentes efeitos a cada seção.

### Alternativas consideradas

| Conceito | Potencial | Decisão |
|---|---|---|
| Manifesto tipográfico | Força verbal e simplicidade | Usar em momentos curtos, mas não como toda a explicação de categoria |
| Infraestrutura acoplada | Une posicionamento, referências e demonstração | Direção escolhida |
| Portfólio em grande escala | Prova criativa imediata | Reservar para casos; como estrutura central favoreceria percepção de agência |

### Aplicação do Design System

Fontes consultadas: MATA Design System oficial, fundamentos, identidade, layout/componentes, direção de arte e QA; Design Master — Instrução completa; Web Design Master e referências de integração, direção e registros de superfície.

| Papel | Direção |
|---|---|
| Base | #F1F2F4 e branco, com predominância clara |
| Texto principal / ação | #171C1B; botão escuro com texto branco |
| Apoio | Prata #D8DDE1, azul-gelo #DEE5EB, menta pálida #B0E6D8 |
| Energia | #00F0A9 com parcimônia, como reflexo ou indicação de conexão |
| Verde profundo | Material do módulo conforme referência e ativo oficial; não transformar todas as seções em fundos verdes |
| Tipo | Stack Sans; Headline para impacto e Text para leitura, como proposta de aplicação dos arquivos disponíveis |
| Material | Vidro refrativo, prata/lilás e superfície fosca com sombra plausível |
| Formas | Módulos com encaixe e conexões visíveis; função antes de repetição decorativa |
| Movimento | Conectar, revelar relação e registrar uma mudança; transições funcionais de 180–260 ms |

O token de texto secundário #6F7777 precisa de contraste conferido no fundo efetivo; para informação essencial, preferir o texto principal. Não assumir que um token é acessível em qualquer combinação.

### Gradiente como assinatura obrigatória

Caroline reforçou que o gradiente é um dos elementos mais importantes do design. Ele deve ser reconhecível na primeira dobra, na atmosfera do acoplamento e em momentos de continuidade. Usar **assets/gradientes/MATA-gradiente-oficial.png**, a referência oficial do sistema, junto das duas capas. A neutralidade da interface protege a leitura; não deve apagar a assinatura cromática. O arquivo 07 define aplicações, token oficial e critérios de comparação visual.

### Tipografia e densidade

Proposta local para este site: títulos de destaque em torno de 56–80 px no desktop, adaptados ao comprimento real; 34–44 px no celular; corpo de 18 px quando possível; medidas confortáveis para leitura. São pontos de partida para inspeção, não obrigação de caber em duas linhas.

Evitar capitalização integral e espaçamento excessivo nas frases longas dos botões. A marca admite títulos grandes e cortes deliberados, mas os termos essenciais do hero, as ações e o conteúdo funcional devem permanecer legíveis.

### Um momento memorável, explicado

Demonstração proposta, explicitamente ilustrativa até ser substituída por um caso real:

1. Comercial identifica uma dúvida recorrente: o comprador não entende uma diferença importante da solução.
2. O time MATA investiga a dúvida e reúne o contexto necessário.
3. Pessoas e IA organizam materiais e alternativas; a pessoa responsável decide a resposta e os limites de aprovação.
4. A decisão chega à página, à proposta e ao conteúdo relevante.
5. O uso dos materiais gera retorno para a próxima revisão.

Mostrar uma transformação por vez. O elemento visual principal é o contexto atravessando conexões; não uma interface fictícia com números de produtividade ou agentes trabalhando sozinhos. A versão estática deve explicar a mesma sequência.

### Mobile

Texto e CTA antes da composição secundária. A imagem pode virar um recorte específico ou uma sequência vertical de dois/três estados. Não reduzir um diagrama desktop inteiro até os rótulos ficarem ilegíveis. Não exigir arrastar, passar o mouse ou assistir a uma animação para entender a oferta. Evitar hero com altura fixa que empurre a explicação para fora da primeira tela.

## 8. Como tornar AI-oriented compreensível

É importante aparecer em vários lugares, mas cada aparição deve acrescentar informação:

| Lugar | Mensagem | O que acrescenta |
|---|---|---|
| Hero | Um time de pessoas e um time de IA | Composição da infraestrutura |
| Demonstração | IA organiza contexto e prepara trabalho; pessoas conduzem decisões | Funcionamento |
| Como funciona | Responsáveis, revisão, acesso e atualização de contexto | Confiança operacional |
| Sobre | A MATA constrói seu modelo com IA participando do trabalho | Visão da empresa |
| Blog | Discussão fundamentada sobre produção, coordenação e capacidade | Profundidade de pensamento |

“AI-oriented” pode aparecer como assinatura secundária, imediatamente explicado em português. Evitar encher páginas com variações de “powered by AI”. O visitante deve saber por que a IA melhora o trabalho que está contratando.

A distinção entre software interno e produto vendido é essencial. A MATA pode desenvolver componentes e métodos reutilizáveis e usar ferramentas de terceiros. Não chamar todo uso de IA de tecnologia proprietária, nem descrever acesso a documentos como treinamento de um modelo exclusivo.

## 9. Prova: de/para das marcas

O de/para deve tornar visível uma evolução em três níveis:

1. **Percepção:** o que a comunicação permitia entender antes e o que passou a explicar.
2. **Capacidade:** o que a empresa passou a conseguir fazer em marketing.
3. **Operação:** como essa capacidade passou a ter continuidade.

Uma comparação de logos pode ser um detalhe da prova. O principal é explicar a mudança e mostrar os materiais, decisões ou efeitos que a sustentam.

### Estrutura de caso

Contexto da empresa → situação anterior → mandato da MATA → decisões → execução em uso → mudança observada → evidências → continuidade → contribuição de outros envolvidos.

Cada métrica precisa de período, definição, fonte e limite de atribuição. Diferenciar alcance de demanda, produção de uso e receita de sinais anteriores à venda. A presença de um resultado no site atual é uma fonte de alegação, não sua validação independente.

### Marcas citadas nesta conversa

Lista corrigida e confirmada por Caroline: **Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF**. As grafias estão resolvidas. Completar marca/grupo, período e escopo de cada relação. Não associar um case anônimo a uma marca por aproximação.

A autorização inicial para usar logos foi seguida da decisão de deixar esse detalhe para depois. Portanto, preparar o componente, mas manter a seleção pública em aberto. Não escrever “já trabalhamos com” para todas as marcas, pois algumas relações podem estar em curso. Caroline quer uma assinatura de infraestrutura incorporada, desenvolvida no arquivo 07. Recomendação: **MATA built in.**, descritor **Infraestrutura de Brand Marketing**. A seção passa a ser **A infraestrutura MATA, incorporada a negócios reais.** O selo distingue operação atual e ciclo histórico; projetos pontuais não recebem automaticamente o selo integral.

### O que pedir para cada caso

- Nome e grafia de exibição; relação atual ou concluída; datas.
- Situação anterior em palavras de quem viveu o problema.
- O que a MATA assumiu e o que ficou com a empresa/outros parceiros.
- Materiais anteriores e posteriores comparáveis, com contexto de uso.
- Decisões de posicionamento/marketing que explicam as diferenças.
- Evidência de uso, resultado ou mudança operacional.
- Números com denominador, janela temporal e fonte.
- Depoimento literal, nome, cargo e condições de uso.
- Logo oficial atual e materiais que podem aparecer publicamente.
- O que permanece confidencial.

O formulário completo para essa coleta está no arquivo 06. A documentação dos cases não precisa impedir a arquitetura e a primeira implementação do site.

## 10. Blog conectado à MATA: endereço em avaliação

Caroline inicialmente considerou um domínio separado e depois perguntou sobre subdomínio versus /blog. A recomendação atual é **wearemata.co/blog**, ou **/pt/blog** conforme idiomas, pela continuidade da experiência e da manutenção. O endereço final ainda não foi confirmado. O arquivo 07 compara opções; blog.wearemata.co permanece alternativa se uma plataforma editorial separada justificar. Preparar configuração única e links contextuais.

/pt/blog pode funcionar como índice definitivo dos textos disponíveis se for adotada a recomendação de subdiretório. Se os artigos ainda não forem publicados, não criar links para endereços que não existem. O Blog pode entrar em uma etapa de publicação coordenada com o site. Evitar um menu com destino quebrado ou um feed inventado.

Caso Caroline escolha uma publicação em subdomínio: Blog no cabeçalho aponta para a publicação; artigos retornam à MATA por links contextuais; identidade e autoria permanecem consistentes; cada artigo tem um endereço principal; não carregar o blog inteiro dentro de iframe.

Se houver migração de artigos já publicados, mapear cada URL antiga para a correspondente e testar os redirecionamentos. O Google recomenda mapeamento e redirecionamentos para mudanças de URL; a preferência de canonical ajuda a consolidar duplicatas, mas não garante a escolha pelo buscador. [Migrações](https://developers.google.com/search/docs/crawling-indexing/site-move-with-url-changes), [canonical](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls).

### Organização editorial inicial

Três trilhas: **Estruturar marketing**, **Marca em movimento**, **Pessoas + IA**. Começar com os três artigos disponíveis. Não criar múltiplas categorias vazias nem vinte artigos artificiais para dar volume.

| Artigo existente | Link comercial natural | Próxima leitura |
|---|---|---|
| Como estruturar a área de marketing quando a empresa já cresceu | Estruturar marketing | Produzir marketing não é conduzir marketing |
| O reposicionamento foi aprovado? Sim. E agora? | Implantar o posicionamento | Como funciona |
| Produzir marketing não é conduzir marketing | Como funciona | Guia de estruturação |

Pautas seguintes sugeridas: quando reposicionar; quem assume marketing quando tudo volta para o CEO; o que muda quando a empresa já tem uma estratégia de marca; como comparar estruturas pelo trabalho necessário. São prioridades editoriais, não conteúdo já produzido.

### Modelo de artigo

Título → resposta ou situação de abertura → autoria real → publicação/atualização reais → corpo com subtítulos → exemplos e fontes → leituras relacionadas → CTA contextual. Tempo de leitura pode ser calculado. Datas não devem ser inventadas a partir da modificação de um arquivo no Drive.

A voz de Caroline e a autoria Time da MATA precisam permanecer distintas. Não transformar o artigo institucional em texto pessoal da fundadora. As cópias de texto incluídas no pacote são referências editoriais; revisar links e formatação na publicação.

## 11. Conversão e qualificação

Objetivo principal proposto: **conversas com empresas aderentes**, não o maior volume possível de formulários. Caroline confirmou dois caminhos independentes: “Conversar sobre minha empresa”, levando a um formulário curto, e “Agendar uma conversa”, levando à agenda real. O formulário não é pré-requisito para agendar. A agenda foi fornecida por Caroline: https://calendar.google.com/appointments/schedules/AcZssZ2mbnnNbCOIvfty8TeDhOueBDAYeIjqqyuDf16dZyBYqkR8oSKqVH97n98S2dkUBPtKZ9L_w7_C .

Campos essenciais sugeridos: nome, e-mail, empresa/site e situação principal. Campo livre: “O que precisa mudar?”. Não pedir uma anamnese completa na primeira interação. Perguntas de orçamento, acessos e prioridades podem ser aprofundadas na conversa.

O contexto escolhido na home deve chegar ao contato como informação editável. O visitante não deve preencher tudo novamente depois de selecionar uma entrada. Manter alternativas de e-mail e WhatsApp visíveis.

Não prometer diagnóstico gratuito, prazo de resposta, proposta imediata ou reunião com Caroline sem confirmação. Não informar que uma mensagem foi recebida enquanto o destino não confirmar o envio.

### Eventos úteis

`primary_cta_click`, `entry_route_click`, `contact_form_start`, `contact_form_success`, `contact_form_error`, `whatsapp_click`, `blog_outbound_click`, `case_view`.

Anexar rota, idioma, posição do CTA e situação selecionada. Evitar incluir nome, e-mail e mensagem livre nos eventos. Um clique no WhatsApp não é lead confirmado. A qualidade da conversa, o avanço comercial e a adequação da empresa devem ser acompanhados separadamente.

Medida inicial: linha de base após publicação, origem das conversas, aderência por entrada e motivos de perda. Só depois fazer testes de mensagem com uma hipótese por vez. Não prometer significância estatística ou taxas de conversão sem amostra e tráfego conhecidos.

## 12. Requisitos para o Lovable

Trabalhar no projeto existente. Inspecionar rotas, componentes, integrações, conteúdo e forma de publicação antes de alterar. O fato de ser Lovable não permite inferir a stack: sua documentação distingue projetos atuais com SSR de projetos anteriores com pré-renderização para crawlers. Verificar o projeto real. [SEO no Lovable](https://docs.lovable.dev/features/seo-aeo).

As instruções permanentes da MATA devem ficar no conhecimento deste projeto. O dossiê completo fica como referência de trabalho. O campo de Project knowledge admite até 10.000 caracteres segundo a documentação consultada; o arquivo 04 é uma síntese própria para esse uso. [Knowledge](https://docs.lovable.dev/features/knowledge).

Requisitos principais: rotas acessíveis diretamente; conteúdo textual e links rastreáveis; títulos e descrições por página; canonical e idioma coerentes; metadados sociais; imagens otimizadas com dimensões; formulário real; estados de erro/sucesso; teclado e foco; alternativa a movimento; página 404; verificação mobile.

Para busca e respostas com IA, não é necessário inventar uma camada especial de marcação. O Google mantém as bases de SEO, conteúdo útil, acesso ao texto e consistência entre marcação e conteúdo. Não há garantia de indexação ou citação em IA. [Google: AI features](https://developers.google.com/search/docs/appearance/ai-features).

## 13. Decisões firmes, recomendações e pendências

| Tema | Estado | Tratamento |
|---|---|---|
| Acoplamento como lógica verbal e visual | Confirmado por Caroline | Obrigatório |
| Um time de pessoas e um time de IA | Confirmado por Caroline | Visível desde a home |
| Percepção de martech | Confirmado por Caroline | Demonstrar composição, operação e tecnologia |
| Público principal sem marketing e negócio relevante | Confirmado por Caroline | Prioridade da narrativa |
| Reposicionamento e implantação | Confirmado por Caroline | Entradas distintas |
| Blog no menu | Confirmado por Caroline | Obrigatório |
| Endereço do Blog | Em avaliação após nova pergunta | Recomendação: /blog ou /pt/blog; subdomínio como alternativa |
| Gradiente oficial central | Confirmado por Caroline | Obrigatório no hero e na continuidade visual |
| MATA como selo de infraestrutura | Intenção confirmada; nome proposto | Desenvolver MATA built in. conforme arquivo 07 |
| Infraestrutura de Marketing Acoplável como nome principal | Recomendação deste dossiê | Usar como base para revisão |
| Formulação alternativa com Brand Marketing | Em avaliação | Manter como explicação aprofundada |
| Formato do contato | Confirmado por Caroline | Formulário curto + botão independente para agendar |
| Cases e logos | Deliberadamente pendentes | Componentes preparados; publicação com materiais válidos |
| Valores, mínimos, aviso prévio e prazos | Divergentes ou não confirmados | Não publicar números |
| Tecnologia proprietária e produtos internos específicos | Maturidade não comprovada nesta pesquisa | Não apresentar como catálogo disponível |
| Entregáveis e conhecimento na saída | Fontes com formulações conflitantes | Fechar texto comercial antes de prometer posse ampla |
| Inglês | Adiado por Caroline até PT estar afinado | Site e Blog novos primeiro em PT; inventariar legado e traduzir integralmente depois |

## 14. O que faria antes da publicação

1. Teste de compreensão com cinco pessoas próximas do público: o que a MATA é, para quem serve, o que se contrata, quem usa a tecnologia e qual seria o próximo passo. Amostra qualitativa, sem pretensão estatística.
2. Documentar ao menos um caso com de/para, mandato e evidência.
3. Validar condições comerciais, direitos sobre materiais e limites da autonomia para as FAQs.
4. Conferir o recebimento real do formulário e os links de contato com dados de teste autorizados.
5. Revisar o website implementado em desktop e mobile; uma boa especificação não substitui esse exame.

Essas etapas refinam uma proposta concreta. A primeira implementação pode avançar com os elementos disponíveis e os componentes pendentes em rascunho.

## 15. Fontes e alcance da pesquisa

Fontes internas lidas:

- [MATA — Positioning](https://docs.google.com/document/d/1s27tNF7xeywvKAVykik25c7qHVdjvlQYlpkBbNc7aRA/edit): princípios, discussões, seção website e modelo acoplável.
- [SITE — Diagnóstico vs. positioning](https://docs.google.com/document/d/1hNfGzGn37AOOpmlIUVyCMupbBSoTV7TQuovMkvWIJbc/edit).
- [SITE — Arquitetura e copy](https://docs.google.com/document/d/1MaVoJfhqI-tW7ODrGPh2ApTFzcv0cwUGWzvEQOqAYGQ/edit).
- [POSICIONAMENTO — Presença digital](https://docs.google.com/document/d/1awBnLfLyZnPx8Fcpv4kIZfdv0QzoJcUndS__zDkVeTI/edit).
- [TESE — Produtos internos + IA](https://docs.google.com/document/d/1W2-5nZgeJSKopWTxe9c90LmtPyuUYqpf/edit).
- [BLOG — Estratégia editorial](https://docs.google.com/document/d/1-pbKE-3IeJ5Ld8st9J41--HppRkrauJYoH-99xQD_G8/edit).
- [BLOG — Mapa de demanda e pautas](https://docs.google.com/document/d/1Fid78TlSCIyAmurcgeovYBucJWL2fEfnqtktdJDPOGE/edit).
- [Artigo — Produzir marketing não é conduzir marketing](https://docs.google.com/document/d/1_cFuMzRxNUot1TJ1XBcPKH8KOByhiV-D/edit).
- [Artigo — Como estruturar a área de marketing](https://docs.google.com/document/d/1JHlgb6KuTjxplUbLg2UKp6_YCXfQOKmf-qPkgRSZm0A/edit).
- [Artigo — O reposicionamento foi aprovado?](https://docs.google.com/document/d/1zE21XafQ9e0_8S0MY-fYxYbsXe8w9p8eu7E22U-e5U0/edit).
- [Design Master — Instrução completa](https://docs.google.com/document/d/1s-RKL66PNVuZWDBZhq-qsQ6Dd_Oei9mr3X7aHoGvmXg/edit).
- [Web Design Master — pacote oficial](https://drive.google.com/drive/folders/12skkvn2q0_3n__OjnpsD2V_IhB3Lp63A).
- [MATA Design System — pacote oficial](https://drive.google.com/drive/folders/1fxxhlKVSn5EoB-tVJevWP4gPJwIYHLMX).
- Duas imagens enviadas por Caroline nesta conversa, incorporadas ao pacote como referências.

Site observado: [Home](https://wearemata.co/pt), [Como funciona](https://wearemata.co/pt/how-it-works), [Resultados](https://wearemata.co/pt/results), [Sobre atual](https://wearemata.co/pt/story), [Princípios](https://wearemata.co/pt/principles), [Contato](https://wearemata.co/pt/contact).

Cobertura: a pasta SITE retornou dois documentos; a pasta Blog e Artigos retornou três artigos, dois estudos editoriais e uma pasta de assets. A busca também incluiu materiais de posicionamento e as skills oficiais. Esse é o conjunto localizado e estudado, não uma garantia de exaustividade sobre todo arquivo existente no Drive. Referências externas mencionadas nos documentos internos não foram todas reavaliadas; não são tratadas aqui como novos estudos independentes.

Não foram realizados: entrevistas com compradores, análise de tráfego, pesquisa quantitativa de palavras-chave, auditoria técnica completa, confirmação de resultados de clientes, teste de envio e implementação do site. As recomendações de estrutura e copy são síntese autoral desta pesquisa.
