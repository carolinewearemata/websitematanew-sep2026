# Evoluções, de/para e informações a completar

Instrumento de coleta para Caroline. Não é copy pública. Não preencher lacunas por inferência. A escolha de logos e dos casos ficou deliberadamente para uma etapa posterior; a implementação pode preparar os componentes agora.

## 1. Escolher os primeiros casos

Priorizar um caso que mostre estruturação de marketing, um de reposicionamento conectado ao negócio e um de implantação de posicionamento. Não é obrigatório encontrar um caso diferente para cada categoria: um caso forte e verificável vale mais do que três exemplos frágeis.

Critérios: proximidade com o comprador prioritário, clareza do problema, participação real da MATA, mudança demonstrável e materiais disponíveis. Uma imagem bonita ajuda a leitura, mas não prova sozinha que a operação mudou.

## 2. Ficha para cada marca

| Pergunta | Resposta a preencher |
|---|---|
| Nome público exato da marca e eventual grupo | |
| Website da marca | |
| Relação atual ou projeto concluído? Período? | |
| Momento do negócio quando a MATA entrou | |
| O que já funcionava e deveria ser preservado? | |
| Qual problema a liderança enfrentava? | |
| O que a MATA assumiu? | |
| Quem mais participou e com qual responsabilidade? | |
| Qual decisão mudou o rumo do trabalho? | |
| Que materiais, canais ou rotinas foram implantados? | |
| O que passou a funcionar de maneira diferente? | |
| Como sabemos? Fonte, data, métrica ou observação verificável | |
| Limite de atribuição: o que não decorre apenas da MATA? | |
| O que pode aparecer publicamente? Nome, logo, imagens, números, depoimento | |
| Pessoa responsável por validar os fatos | |
| Arquivos de antes e depois disponíveis | |

Não é necessário divulgar dados sensíveis para fazer um caso útil. Se números não puderem aparecer, descrever mudanças concretas e apresentar evidência permitida. Caso anônimo precisa ser verdadeiro e suficientemente contextualizado, sem criar uma identificação indireta indesejada.

## 3. De/para que demonstra negócio

| Dimensão | Antes | Decisão/intervenção da MATA | Depois | Evidência possível |
|---|---|---|---|---|
| Clareza da oferta | Como a oferta era explicada? | Qual narrativa/prioridade foi revista? | O que passou a ser entendido? | Páginas e materiais datados; retorno documentado |
| Marca e negócio | O que ficou para trás? | O que foi preservado e atualizado? | Onde a nova leitura aparece? | Identidade aplicada, apresentação, website |
| Condução | Quem precisava coordenar tudo? | Qual responsabilidade foi assumida? | Como decisões e execução passaram a ocorrer? | Plano, cadência e responsáveis, com dados internos omitidos |
| Implantação | O que estava aprovado mas sem uso? | Quais pontos de contato foram priorizados? | O que entrou em operação? | Propostas, site, conteúdos, materiais comerciais |
| Continuidade | Onde o trabalho se interrompia? | Que rotina foi estabelecida? | O que passou a ser acompanhado? | Sequência de entregas e decisões verificáveis |
| Efeito observado | Qual situação inicial? | Qual contribuição específica? | Qual sinal ou resultado ocorreu, em que período? | Relatório com definição e fonte |

Se usar comparação visual, mostrar peças equivalentes e contexto: mesma função, período e objetivo. Um slider pode ser complemento; não deve esconder explicação, ser a única forma de comparação ou prejudicar uso por teclado. Em mobile, imagens empilhadas com legendas costumam preservar melhor a leitura.

## 4. Marcas confirmadas por Caroline

**Touch Health, AURINOVA, Nexland, EatSimply, Barte, Aromax e OBF.**

As grafias estão confirmadas. Para cada marca, completar período, relação atual/histórica, escopo, evidências e arquivos oficiais. A seleção de logos segue para etapa posterior, como solicitado.

Caroline quer que a presença da MATA seja uma assinatura de infraestrutura incorporada. A proposta **MATA built in.** e suas versões atual/histórica estão no arquivo 07. A seção passa a ser **A infraestrutura MATA, incorporada a negócios reais.** Não usar uma faixa genérica de clientes como conceito principal. Um projeto pontual não recebe automaticamente selo de infraestrutura completa.

Adicionar à ficha de coleta: esta relação correspondeu a infraestrutura acoplada? Em qual escopo e período? O que o selo pode afirmar com precisão? Ter trabalhado com uma marca não permite atribuir todo o seu desempenho à MATA.

## 5. Alegações observadas no site atual

São pontos de partida para apuração, não resultados revalidados nesta pesquisa. Não associar os casos anônimos abaixo às marcas acima por semelhança.

| Caso descrito publicamente | Alegação observada | Conferir antes de reutilizar |
|---|---|---|
| Software de saúde com cerca de 25 anos | Relançamento em 3 meses em comparação com plano de 12 meses | Datas, escopo, origem do plano, o que entrou em produção e contribuição de outros envolvidos |
| Fintech | 35 inserções; detalhamento de 6 tier 1 + 24 tier 2 + 1 TV | O detalhamento soma 31. Conciliar as quatro ocorrências restantes e definir inserção, veículo, período e duplicações |
| Incorporadora de alto padrão | Aquisição em aproximadamente um mês | O que significa aquisição nesse contexto, sequência temporal e limite de atribuição |
| Holding com três marcas | Aproximadamente US$ 80 milhões de ARR | Definição, moeda, período, fonte e relação com atuação MATA; porte do cliente não equivale a receita gerada pela MATA |
| Produto D2C de proteína | 100 mil visualizações em duas semanas, sem mídia paga | Plataforma, publicação, período, agregação, definição de visualização e o que se sabe além do alcance |

## 6. Modelo de texto após a coleta

**Título:** uma mudança concreta, em linguagem simples.

**Contexto:** o que a empresa fazia e qual era seu momento.

**Antes:** problema específico e consequência para negócio ou liderança.

**O que assumimos:** responsabilidade da MATA e colaboração com cliente/parceiros.

**Decisões e implantação:** duas ou três escolhas relevantes e como entraram em uso.

**Depois:** mudança observável, período e evidência. Se for resultado parcial, dizer isso.

**O que esse caso ajuda a entender:** conexão com estruturação, reposicionamento ou implantação, sem transformar um resultado particular em promessa universal.

**Contato:** “Sua empresa vive um momento parecido?” com formulário e agenda independentes.

## 7. Outras informações a completar

| Item | Situação | Como avançar |
|---|---|---|
| Categoria principal | Recomendação: Infraestrutura de Marketing Acoplável | Testar compreensão na prévia; alternativa Brand Marketing explicada no dossiê |
| Dois caminhos de contato | Confirmados | Implementar formulário curto e agenda independentes |
| URL da agenda | Fornecida por Caroline | Usar a URL do arquivo 05 e conferir abertura pública |
| Destino do formulário | Ainda não verificado | Reutilizar integração válida ou definir destino; testar recebimento |
| Endereço do Blog | Em avaliação; recomendação /blog ou /pt/blog | Conferir plataforma de edição e fechar endereço antes da publicação |
| Cases e logos | Seleção adiada pela usuária | Preparar em rascunho e preencher com esta ficha |
| Termos de operação e comerciais | Há divergências nos documentos históricos | Conferir documento vigente; omitir números e condições específicas até então |
| Foto e bio da fundadora | Complementar | Usar nome Caroline Miranda Martha; conferir texto e imagem antes de publicar |
| Versão em inglês | Caroline adiou até o site PT estar afinado | Primeiro site e Blog em PT, publicação manual; inglês depois |

Nenhuma dessas pendências exige refazer a pesquisa ou a arquitetura. Elas completam componentes e condições que já estão definidos no briefing.
